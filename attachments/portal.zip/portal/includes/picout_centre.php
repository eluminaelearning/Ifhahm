<?php
/**
* JoomDragDrop component for Joomla
* @version $Id: picout_centre.php 2009-11-16 17:30:15
* @package JoomDragDrop
* @subpackage picout_centre.php
* @author JoomPlace Team
* @Copyright Copyright (C) JoomPlace, www.joomplace.com
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

define( '_JEXEC', 1 );
define( 'DS', DIRECTORY_SEPARATOR );
define('JPATH_BASE', dirname( str_replace(DS.'includes','',__FILE__)));

require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

$mainframe =& JFactory::getApplication('site');
$mainframe->initialise();

JPluginHelper::importPlugin('system');
$mainframe->triggerEvent('onAfterInitialise');

$mosConfig_absolute_path=JPATH_SITE;
//get image name with path 
//if image not found gets '/images/no_image.jpg' image instead
$pict_inline=JArrayHelper::getValue($_REQUEST, "picout", $mosConfig_absolute_path."/images/no_image.jpg", 'string');

$prefix="";
$picout=$mosConfig_absolute_path.$pict_inline;
if ( (!(file_exists($picout)))||(!(is_file($picout))) )
$picout=$mosConfig_absolute_path."/images/no_image.jpg";

//get all params
list($im_width, $im_height, $im_ext, $attr) = getimagesize($prefix.$picout);
$canv_width = JArrayHelper::getValue($_REQUEST, 'pic_width', $im_width);
$canv_height = JArrayHelper::getValue($_REQUEST, 'pic_height', $im_height);
$max_width = JArrayHelper::getValue($_REQUEST, 'max_width', $canv_width);
$max_height = JArrayHelper::getValue($_REQUEST, 'max_height', $canv_height);
$min_width = JArrayHelper::getValue($_REQUEST, 'min_width', $canv_width);
$min_height = JArrayHelper::getValue($_REQUEST, 'min_height', $canv_height);
$bg_color = JArrayHelper::getValue($_REQUEST, 'bg_color', 'ffffff');

//convert background color from hexademical to decimal

$canv_color['red'] = hexdec(substr($bg_color, 0, 2));
$canv_color['green'] = hexdec(substr($bg_color, 2, 2));
$canv_color['blue'] = hexdec(substr($bg_color, 4, 2));




//resize if canvas/image dimensions don't go into min/max
//only if min/max params are set
if ($canv_width < $min_width && isset($_REQUEST['min_width'])) { 
	$canv_height = intval($canv_height * $min_width / $canv_width); 
	$canv_width = $min_width; 
}
if ($canv_width > $max_width && isset($_REQUEST['max_width'])) { 
	$canv_height = intval($canv_height * $max_width / $canv_width); 
	$canv_width = $max_width; 
}
if ($canv_height < $min_height && isset($_REQUEST['min_height'])) { 
	$canv_width = intval($canv_width * $min_height / $canv_height); 
	$canv_height = $min_height; 
}
if ($canv_height > $max_height && isset($_REQUEST['max_height'])) { 
	$canv_width = intval($canv_width * $max_height / $canv_height); 
	$canv_height = $max_height; 
}

//calculate resample factor
$factor_x = $im_width / $canv_width;
$factor_y = $im_height / $canv_height;
if (isset($_REQUEST['no_resample'])) {
	$factor = 1; //not resampled
}
else $factor = max($factor_x, $factor_y);

//resample
$im_width = intval($im_width / $factor);
$im_height = intval($im_height / $factor);

//add paddings
$padding_width = intval(($canv_width - $im_width) / 2);
$padding_height = intval(($canv_height - $im_height) / 2);

//check source image extension and create needed canvas
switch ($im_ext)
{
	case 1:
	$im=imagecreatefromgif($prefix.$picout);
	$im_blank=imagecreate($canv_width,$canv_height);
	break;

	case 2:
	$im=imagecreatefromjpeg($prefix.$picout);
	$im_blank=imagecreatetruecolor($canv_width,$canv_height);
	break;

	case 3:
	$im=imagecreatefrompng($prefix.$picout);
	$im_blank=imagecreate($canv_width,$canv_height);
	break;

	default:
	$im=imagecreatefromjpeg($prefix."images/no_pic.jpg");
	$im_blank=imagecreate($canv_width,$canv_height);
}

//fill background
$color = imagecolorallocate($im_blank, $canv_color['red'], $canv_color['green'], $canv_color['blue']);
imagefill($im_blank, 0, 0, $color);

//copy resampled image to canvas
imagecopyresampled($im_blank,$im,$padding_width,$padding_height,0,0,$im_width,$im_height,imagesx($im),imagesy($im));

//return resulting image
header("Content-type: image/pjpeg");
imagejpeg($im_blank);
?>