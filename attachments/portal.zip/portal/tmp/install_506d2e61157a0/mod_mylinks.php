<?php
//My Links//
// $Id: mod_mylinks.php, v1.4 (2008.03.21) DJesus Exp $
#########################################################
# MyLinks                                               #
# Copyright (C) 2005 by TEG Design - Djesus             #
#########################################################
# Desccription : Allow to store user's favorites links. #
# Company      : TEG Design                             #
# Homepage     : www.tegdesign.ch                       #
# License      : Released under GPL                     #
#########################################################

/*

Change log
----------
1.4 (21.03.2008) By DJesus
- Fixed and issue with Delete action in Front-end ($cid variable was not correctly retrieved - Joomla is now more strict with _REQUEST variable - Security feature)
- Added trick to avoid "%" in URL, on certain site this may be miss interpretted as "Injection hacking". which is not...

1.3c (19.10.2006) By DJesus
- Added a trick to remove the Site name of the page tile (Remove text before the first "-")...

1.3b (02.01.2006) By DJesus
- Fixed issue with link to be open in a "blank/new" page...

1.3a (29.11.2005) By DJesus
- Reviewed Fox's great enhancement !
- Replaced hardcoded text to language file
- Removed Table, as it may cause a duplicate module footer !

1.3 (20.11.2005) By Fox
- Added combobox display support
- Added vertical/horizontal display mode
- Added display modes for actions (icon + text, icon only or text only)

1.2  (02.10.2005) by DJesus
- Added Counter to count MyLinks
- Added parameter to display/hide Links list or Links Counter
- Removed the Table to correctly display the module (style), the table may cause a duplicate footer...

1.1  (15.04.2005) by DJesus
- Changed the redirection to url when adding a new Link, now the redirection is preformed only when Add is pressed - no more for New.

1.0 (14.04.2005) by DJesus
- Original version

*/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

global $database, $my, $_SERVER;

$content = "";  // Security : clear module content...

// *** Get language files
if (file_exists($mosConfig_absolute_path.'/components/com_mylinks/language/' . $mosConfig_lang . '.php')) {
   include_once($mosConfig_absolute_path.'/components/com_mylinks/language/' . $mosConfig_lang . '.php');
} else {
   include_once($mosConfig_absolute_path.'/components/com_mylinks/language/english.php');
}

$prms->version = "v1.4 (2008.03.21)";

$prms->title     = $params->get( 'title' ,'');
$prms->viewlist  = intval( $params->get( 'viewlist','1') );

$prms->viewcount = intval( $params->get( 'viewcount','0') );

$prms->displaycombo   = intval( $params->get( 'displaycombo','0') );
$prms->displaymode    = intval( $params->get( 'displaymode','0') );
$prms->displayaction  = intval( $params->get( 'displayaction','0') );

$cache           = $params->get( 'cache', '0' );
$moduleclass_sfx = $params->get( 'moduleclass_sfx', '' );


// *****************
//      M A I N
// *****************


$content .= "\n".'<!-- START ModMyLinks (c) www.TEGDesign.ch  '.$prms->version.' -->'."\n";

if ($my->id) {  // Only for registered users

   if ($prms->title) {
     $content .= '        <div><b>'.$prms->title.'</b></div>'."\n";
   }

   // *** Get Users' MyLinks
   $Query = "SELECT m.*"
       . "\n FROM #__mylinks AS m"
       . "\n WHERE m.userid = $my->id"
       . "\n ORDER BY m.ordering"
   ;

   $database->setQuery($Query);
   $rows = $database->loadObjectList();

   $prms->count = count($rows);

   if ($prms->viewlist) {
      if ( ($prms->count) && ($prms->displaycombo == '0') ) {   // *** Display list
         // *** Display MyLinks
         $content .= '        <ul>'."\n";
         foreach ($rows as $row) {
            $content .= '          <li>';
            $content .= '<a href="' .$row->URL. '"';
            if ($row->openwin) {  // open url in a blank page or in the parent page ?
               $content .= ' target="_blank"';
            } else {
               $content .= ' target="_parent"';
            }
            $content .= '>' .$row->title. '</a>';
            $content .= '</li>'."\n";
         }
         $content .= '        </ul>'."\n";

      } else if ( ($prms->count) && ($prms->displaycombo == '1') ) {  // *** Display Combobox

         // *** Add javascript code to jump to another page
         $content .= '        <script language="javascript" type="text/javascript">'."\n";
         $content .= '          function jumpLink(selObj) {'."\n";
         $content .= '            openmode = selObj.options[selObj.selectedIndex].value.substr(0,1);'."\n";
         $content .= '            url = selObj.options[selObj.selectedIndex].value.substr(2);'."\n";
         $content .= '            if ( openmode == "1" ) {'."\n";  // Open in a New Page
         $content .= '               selObj.selectedIndex=0;'."\n";   // Reset the Drop Box as we open a blank page...
         $content .= '               search = window.open(url, null);'."\n";
         $content .= '            } else {'."\n";               // Open in Parent Page
         $content .= '               location.href=url;'."\n";
         $content .= '            }'."\n";
         $content .= '          }'."\n";
         $content .= '        </script>'."\n";

         // *** Display My Links in a combobox
         $content .= '        <select name="MYLCombobox" align="left" class="inputbox" onChange="jumpLink(this)">'."\n";
         $content .= '          <option>'._MYL_MOD_ACCESSING_TO;

/*
         if ($prms->viewcount) {
               // display number of links in the combobox
               $content .=  ' ('. _MYL_MOD_COUNT_BEFORE . $prms->count . _MYL_MOD_COUNT_AFTER . ')';
         }
*/

         $content .= '        </option>'."\n";
         foreach ($rows as $row) {
            $content .= '          <option value="'.$row->openwin .'|'. $row->URL. '"';
            $content .= '>' .$row->title. '</option>'."\n";
         }
         $content .= '        </select>'."\n";


      } else {  // *** Empty - No link stored

         $content .= '        <i>' ._MYL_MOD_NOLINK. '</i><br />'."\n";

      }
   }

   // *** Display mode: 0:Vertical / 1:Horizontal
   if ( ($prms->displaycombo == '1') && ($prms->displaymode == '0') ) {       // Combo & Vertical => New line
       $content .=  '        <br clear="all" />'."\n";
   }


   // *** Display Actions => Scramble myTitle and myURL into myInfo to avoid problem with URL containing "%" as my false-detected as script injection on filtered site (.htaccess)
   $content .= '
        <script language="javascript" type="text/javascript">
        function additem () {
          myTitle = document.title;
          if ( myTitle.indexOf(\' - \') > 0 ) {         // Remove the Website name (left text to the first "-")
             myTitle = myTitle.substring(myTitle.indexOf(\' - \')+3);
          }
          myTitle = escape(myTitle);
          myUrl = escape(location.href);

          myInfo = "&info="+myTitle+"(|)"+myUrl;
          res = myInfo.match(/%/g);
          for (i=0;i<res.length;i++) {
             myInfo = myInfo.replace(/%/,"|");
          }

          document.location = "index.php?option=com_mylinks&Itemid=' .$Itemid. '&task=add"+myInfo;
        }
        </script>
';

   // *** Display actions with the choosen mode  (0:text only / 1:text + icon / 2:icon only)
   $content .= '        <a href="javascript:additem();" title="'._MYL_MOD_ADD.'">';
   if ($prms->displayaction) {                // *** display icon (1 or 2)
      $content .= '<img border="0" src="'.$mosConfig_live_site.'/modules/mod_mylinks/add_favorite.gif" alt="'._MYL_MOD_ADD.'" />';
   }
   if ($prms->displayaction != 2) {           // *** display text (0 or 1)
      $content .= _MYL_MOD_ADD;
   }
   $content .= '</a>';
   $content .= (_MYL_MOD_SEPARATOR) ? _MYL_MOD_SEPARATOR : '&nbsp;';
   $content .= "\n";
   $content .= '        <a href="index.php?option=com_mylinks&Itemid=' .$Itemid. '" title="'._MYL_MOD_MANAGE.'">';
   if ($prms->displayaction) {                // *** display icon (1 or 2)
      $content .= '<img border="0" src="'.$mosConfig_live_site.'/modules/mod_mylinks/edit_favorites.gif" alt="'._MYL_MOD_MANAGE.'" />';
   }
   if ($prms->displayaction != 2) {           // *** display text (0 or 1)
      $content .= _MYL_MOD_MANAGE;
   }
   $content .=  '</a>';

   // *** Display MyLinks Count
//   if (($prms->viewcount) && ($prms->displaycombo == '0')) {
   if ($prms->viewcount) {
      $content .= (_MYL_MOD_SEPARATOR) ? _MYL_MOD_SEPARATOR : '&nbsp;';
      $content .= _MYL_MOD_COUNT_BEFORE . $prms->count . _MYL_MOD_COUNT_AFTER;
   }

   $content .=  "\n";

} else {
   $content .= _MYL_MOD_MUST_REGISTER;
}

$content .= '<!-- END ModMyLinks (c) www.TEGDesign.ch  '.$prms->version.' -->'."\n";

?>