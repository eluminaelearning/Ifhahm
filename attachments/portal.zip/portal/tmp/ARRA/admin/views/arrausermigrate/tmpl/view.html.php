<?php
/**
 * ARRA User Export Import component for Joomla! 1.6
 * @version 1.6.0
 * @author ARRA (joomlarra@gmail.com)
 * @link http://www.joomlarra.com
 * @Copyright (C) 2010 - 2011 joomlarra.com. All Rights Reserved.
 * @license GNU General Public License version 2, see LICENSE.txt or http://www.gnu.org/licenses/gpl-2.0.html
 * PHP code files are distributed under the GPL license. All icons, images, and JavaScript code are NOT GPL (unless specified), and are released under the joomlarra Proprietary License, http://www.joomlarra.com/licenses.html
 *
 * file: view.html.php
 *
 **** class 
     ArrausermigrateViewArrausermigrate 
	 
 **** functions
     display();
     setCriteriaUsers();
     setAbout();
	 countUsers(); 
     setListUsers();
     getPicture();
	 
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

/**
 * ArrausermigrateViewArrausermigrate
 * 
 * Class for displaing view for arra_user control panel.
 */
class ArrausermigrateViewArrausermigrate extends JView{
	/**
	 * Method for display default view. 
	 * @return void
	 **/
	function display($tpl = null) {	     		 
		// make ToolBarHelper with name of component.		
		JToolBarHelper::title(   JText::_( 'ARRA_USER_EXPORT' ), 'generic.png' );
				
		// set users statistix slide
		$list = $this->setListUsers();		
		$this->assignRef('listUsers', $list);
		
		// set users criterias display
		$criteria = $this->setCriteriaUsers();		
		$this->assignRef('criteria', $criteria);
		
		// set about slide
		$about = $this->setAbout();		
		$this->assignRef('about', $about);				
		
		parent::display($tpl);
	}
	
	// set criteria display users
	function setCriteriaUsers(){
		$criteria = "";
		//complet the heder om radio box
		$criteria .= "<div class=\"row_criteria\">" .
						"<div class=\"left_radio_content\">" . 
							JText::_("ARRA_ACTIVE_USERS") . 
						"</div>" .
						"<div class=\"right_radio_content\">" . 
							JText::_("ARRA_AT_LEAST_ONE_VISIT") . 
						"</div>".
					"</div><br/>";
		
		// make radio box		
		$criteria .= "<div class=\"row_criteria\">".	
						"<div class=\"left_radio_content\">
							<input type=\"radio\" name=\"all_active_users\" value=\"all_active_users\" onclick=\"javascript:showAllActiveUsers()\"> 
						</div>".
						"<div class=\"right_radio_content\">
							<input type=\"radio\" name=\"at_least_one_visit\" value=\"at_least_one_visit\" onclick=\"javascript:showAtLeastOneVisit()\"> 
						</div>".
					"</div>";
		
		// zones for changes with ajax
		$criteria .= "<div class=\"row_criteria\">".
						"<div class=\"left_radio_content\" id=\"active_counts\">" . "" . 
						"</div>".
						"<div class=\"right_radio_content\" id=\"at_least_one_visit\">" . "" . 
						"</div>".
					 "</div><br/><br/><br/>"; 
		
		return $criteria;
	}
	
	//set dates about component
	function setAbout(){
	    $last_version = $this->get('LatestVersion');
	    $actual_version = $this->get('ActualVersion');
		$about = "";
		$msg = "";
		
		$about .= "<table width=\"100%\">";
		$about .= 		"<tr>";
		$about .= 			"<td align=\"center\">";
		if($actual_version == $last_version){
			$about .= '<img src="components/com_arrausermigrate/images/icons/checked.png" title="Latest Version" alt="Latest Version" />';
			$msg = JText::_("ARRA_LATEST_VERSION_MSG");
		}
		else{
			$about .= '<img src="components/com_arrausermigrate/images/icons/unchecked.png" title="Old Version" alt="Old Version" />';
			$msg = JText::_("ARRA_OLD_VERSION_MSG");
		}
		$about .= 			"</td>";
		$about .= 			"<td align=\"left\">";
		$about .= 				"<b style=\"color:#666666; font-size:15px;\">".$msg."</b>";
		$about .= 			"</td>";
		$about .= 		"</tr>";
		$about .= "</table>";
		
		$about .= "<table width=\"100%\">";
		$about .=	"<tr>";		
		$about .=		"<td>";		
		$about .=			"<table class=\"adminlist_about\">";
		$about .=              "<tr>";
		$about .=                 "<td>";
		$about .=                     "<b>Installed version</b>";
		$about .=                 "</td>";
		$about .=                 "<td>";
		$about .=                     $actual_version;
		$about .=                 "</td>";
		$about .=              "</tr>";
		
		//if(($actual_version != $last_version) && ($last_version != "ERROR")){
		if($last_version != "ERROR"){
			$about .=              "<tr>";
			$about .=                 "<td>";
			$about .=                     "<b>Latest Version</b>";
			$about .=                 "</td>";
			$about .=                 "<td>";
			$about .=                     "<a href=\"http://www.joomlarra.com/downloads/free-joomla-extensions.html\" target=\"_blank\">".$last_version."</a>";
			$about .=                 "</td>";
			$about .=              "</tr>";
		}
		elseif($last_version == "ERROR"){
			$about .=              "<tr>";
			$about .=                 "<td>";
			$about .=                     "<b>Latest Version</b>";
			$about .=                 "</td>";
			$about .=                 "<td>";
			$about .=                     JText::_("ARRA_NO_CONNECTION_TO_LAST_VERSION");
			$about .=                 "</td>";
			$about .=              "</tr>";
		}
				
		$about .=              "<tr>";
		$about .=                 "<td>";
		$about .=                     "<b>Copyright</b>";
		$about .=                 "</td>";
		$about .=                 "<td>";
		$about .=                     "2010-2011 www.joomlarra.com";
		$about .=                 "</td>";
		$about .=              "</tr>";
		$about .=              "<tr>";
		$about .=                 "<td>";
		$about .=                     "<b>Licence</b>";
		$about .=                 "</td>";
		$about .=                 "<td>";
		$about .=                     "<a href=\"http://www.gnu.org/licenses/gpl-2.0.txt\" target=\"_blank\">GPL v2</a>";
		$about .=                 "</td>";
		$about .=              "</tr>";				
		$about .=           "</table>";		
		$about .=        "</td>";
		$about .=     "<td align=\"center\" colspan=\"2\">";
		$about .=            "<img src=\"components/com_arrausermigrate/images/icons/logo_thumb.png\" title=\"ARRA User Export Import\" alt=\"ARRA User Export Import\" height=\"100\" />";
		$about .=     "</td>";		
		$about .=     "</tr>";		
		$about .= "</table>";
		
		return $about;
	}
	
	//count all users where usertype is input parameter
	function countUsers($usertype){
		if($usertype == "deprecated"){
			$usertype = "Super Users";
		}
		$db =& JFactory::getDBO();
		$sql = "select count(*) from #__user_usergroup_map where group_id in (select id from #__usergroups where title='".$usertype."')";				
		$db->setQuery($sql);
		$content = $db->loadResult();		
		return $content;
	}
	
	// set users statistix
	function setListUsers(){	
	    // get user count
		$users_count = $this->get('UsersCount');				
		$list = "";				
		$array_user_type = $this->get('UserType');
		$count = "";
		$const = 0;
		$no_type_count = 0;
		if(isset($array_user_type) && is_array($array_user_type) && count($array_user_type)>0){
			foreach($array_user_type as $key=>$value){
				if($value['usertype'] == "deprecated"){
					$value['usertype'] = "Super Users";
				}		    
				$count = $this->countUsers($value['usertype']);			
				if($count != 0){
					$list .= "<div class=\"user_row\">
								<div class=\"user_type\">" .
									$value['usertype'] . 
							   "</div>" . 
							   "<div class=\"user_count\" >" . 
									$count . 
							   "</div>" . 
							   "<div class=\"user_percent\" >" . 
									number_format( (($count * 100) / $users_count), 2, '.', '') . "%" . 
							   "</div>" . 
							   "<div class=\"grafic_statistic\">" . 
									$this->getPicture(number_format( (($count * 100) / $users_count), 2, '.', '')) . 
							   "</div>" . 
							"</div><br/><br/>";
				} 
			}	
		}
        // no user type
		$no_type_count = $this->get('NoTypeCount');
		if($no_type_count != 0){
	        $list .= "<div class=\"user_row\">
						<div class=\"no_user_type\">" .
							JText::_("ARRA_NO_USER_TYPE") . 
						"</div>" . 
						"<div class=\"no_user_count\" >" . 
							$no_type_count . 
						"</div>" . 
						"<div class=\"no_user_percent\" >" . 
							number_format( (($no_type_count * 100) / $users_count), 2, '.', '') . "%" . 
						"</div>" .
						"<div class=\"grafic_statistic\">" . 
							$this->getPicture(number_format( (($no_type_count * 100) / $users_count), 2, '.', '')) . 
					   "</div>" . 						    
					 "</div><br/><br/>";
		}			   		
		return $list;		 
	}
	
	// function generate count bar
	function getPicture($value){	
	    $picture = "";
		$picture .= "<div class=\"all_users\"> ";
		$picture .= 	"<div class=\"calculate_users\" style=\"width:" . $value . "px; \"> &nbsp; ";
		$picture .= 	"</div>";
		$picture .= "</div>";
		return $picture;
	}			
}

?>