<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');
class KalturaModelBrowser extends JModel
{
    var $_data;
    var $_page;
    var $_total;
    var $_edb; // external database connection
    var $_instance;
    var $_step = 10;
    
    var $_notInstanceFilter = false;
    
    function __construct() {
        parent::__construct();
        $mainframe = JFactory::getApplication();
        
        $limit = $mainframe->getUserStateFromRequest('global.list.limit','limit',$mainframe->getCfg('list_limit'), 'int');
		$limitstart = JRequest::getVar('limitstart', 0, '', 'int');
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);
    }
    
    function getInstanceMetadata() {
        $query = 'select * from #__Kaltura_instances where id='.$this->_id;
        $this->_db->setQuery($query);
        $this->_instance = $this->_db->loadObject();
        return $this->_instance;
    }
    function selectDefaultInstance()
    {
    	$query = 'select min(id) from #__Kaltura_instances';
        $this->_db->setQuery($query);
        $id = $this->_db->loadResult();
        return $id;
    }
    
    function getDescription() //provisional
    {
    	$query = 'select details_freehtml from #__Kaltura_configuration';
        $this->_db->setQuery($query);
        $description = $this->_db->loadResult();
        return $description;
    }
    
    function setId($id) {
   
        if ($id == 0) {
            $this->_id = $this->selectDefaultInstance();;
            $this->_notInstanceFilter = true;
        } else $this->_id = $id;
        $this->_page = 1;
        $this->_data = null;
        $this->_instance = $this->getInstanceMetadata();
        
        $this->_edb =& ExternalDatabase::getDatabaseInstance($this->_id);
    }
    
    function setItemId($itemid) {
        $this->_item_id = $itemid;
        $this->_object = null;
    }

    
    function getItem() {
        if (empty($this->_object)) {
            //Get database kaltura
            $query = 'select * from entry where id="'.$this->_item_id.'"';
            $this->_edb->setQuery($query);
            $this->_object = $this->_edb->loadObject();
            $this->_object->instance_id = $this->_instance->userid;
            
            
            //Get Database Joomla
            $query = 'select * from #__Kaltura_entry_cdata where kentry_id = "'.$this->_item_id.'"';
       		$this->_db->setQuery($query);
            $this->_object->joomladb = $this->_db->loadObject();

        }
        return $this->_object;
    }
    
    function getFieldsList() {
        $query = 'select * from #__Kaltura_fields where field_visible=1';
        $this->_db->setQuery($query);

        
        return $this->_db->loadObjectList();
    }
    
    function getFieldValue($field_id) {
        $query = 'select * from #__Kaltura_entry_field_value';
        $query .= ' where kentry_id="'.$this->_item_id.'" and field_id='.$field_id;
        
        $this->_db->setQuery($query);
        return $this->_db->loadObject();
    }
    
    function _buildQuery() {
        $query = 'SELECT i.instance_name as partner,a.kentry_visible as kentry_visible, a.kentry_created_at as kentry_created_at,a.priority as kentry_priority, a.kentry_id as kentry_id, a.kentry_name as kentry_name, a.kentry_type as kentry_type, a.kentry_views as kentry_views, a.kentry_description as kentry_description,a.kentry_partner_id, ';
        $query .= 'date_format(a.kentry_created_at, "%d/%m/%y %H:%i") as kentry_created_at, ';
        $query .= 'a.kentry_length_in_msecs as kentry_length_in_msecs, ';
        $query .= 'a.kentry_status kentry_status, ';
        $query .= 'a.kentry_categories kentry_categories ';
        $query .= 'FROM #__Kaltura_entry_cdata a ';
        
        $query .= 'inner join #__Kaltura_instances i on a.kentry_partner_id=i.userid ';
        $query .= 'left join #__Kaltura_entry_field_value f on f.kentry_id=a.kentry_id ';
        
        $query .= 'WHERE a.kentry_type <> 5 and a.kentry_status = 2 ';
        $query .= 'AND a.kentry_visible = 1 ';
        if (!$this->_notInstanceFilter) {
            $query .= 'and (a.kentry_partner_id = '.($this->_instance->userid).')';
        }
        $query .= ' and i.public = true and kentry_visible=1 ';
        return $query;
    }
    
    function _buildFilter() {
        $query = "";
        
        // load created between
        $init_date = JRequest::getVar('init_date');
        $end_date = JRequest::getVar('end_date');
        if ($init_date) {
            $query .= ' and (a.kentry_created_at > str_to_date('.$init_date.'))';
        } else if ($init_date && $end_date) {
            $query .= ' and ((a.kentry_created_at > str_to_date('.$init_date.')) or ';
            $query .= '(a.kentry_created_at < str_to_date('.$end_date.')))';
        }
    
        // load search field data
        $searchfield = JRequest::getVar('q');
        if ($searchfield) {
            $query .= ' and a.kentry_name like "%'.$searchfield.'%"';
        }
        
        // load media type filter
        $mediafilters = JRequest::getVar('mediafilters');
        if ($mediafilters) {
            $mediafilters = implode(",", $mediafilters);
            $query .= ' and (';
            $query .= 'a.kentry_media_type in ('.$mediafilters.')';
            $query .= ')';
        }
        
        // load duration filter
        $durationfilters = JRequest::getVar('durationfilters');
        if ($durationfilters) {
            //$durationfilters = explode(',', $durationfilters);
            $query .= ' and (';
            foreach ($durationfilters as $k => $filter) {
                if ($filter == 1) {
                    $query .= ' (a.kentry_length_in_msecs < '.(4*60*1000).')';
                } else if ($filter == 2) {
                    $query .= ' ((a.kentry_length_in_msecs > '.(4*60*1000).') and';
                    $query .= ' (a.kentry_length_in_msecs < '.(20*60*1000).'))';
                } else if ($filter == 3) {
                    $query .= ' (a.kentry_length_in_msecs > '.(20*60*1000).')';
                }
                if ($k < (count($durationfilters)-1)) $query .= ' or';
            }
            $query .= ')';
        }
  	
    	
        $query .= $this->getFilteredQuery();
        
        return $query;
    }
    
    function getFilteredQuery()
    //Build the query for custom filters
    {
    	if(count($this->dataCustFilter())>0):
    		
    		$filtdata = $this->dataCustFilter();
    		
    		$i = 0;
    		foreach ($filtdata as $d):
    			$filtdata[$i] = '"'.$d.'"';
    		$i++;	
    		endforeach;
    	
    		$ids = join(',',$filtdata); 
    		$query = ' and a.kentry_id IN('.$ids.')';
    	
    	else:
    		$query = '';
    	endif;	
    	
    	return $query;
    	
    	
    }
    
    function dataCustFilter()
    //Get in an array all the kentry ids that must be filtered
    {
    	$filters = $this->getFilters();
    	
    	$query = 'SELECT distinct kentry_id FROM `#__Kaltura_entry_field_value`';
		$query .= 'WHERE';
		
		$i = 0;
		foreach ($filters as $filter) {
			$filter_val = JRequest::getVar($filter->field_name);
			if ($filter_val and ($filter_val != 'ALL')):
				if($i==0):
					$query .= ' kentry_id IN (SELECT kentry_id FROM `#__Kaltura_entry_field_value` WHERE value = "'.$filter_val.'")';
				else:
					$query .= ' AND kentry_id IN (SELECT kentry_id FROM `#__Kaltura_entry_field_value` WHERE value = "'.$filter_val.'")';
				endif;
			$i++;
			endif;
		}
		$this->_db->setQuery($query);
        $filtered = $this->_db->loadResultArray();
			
    	return $filtered;

    }

    function getFilterNumber()
    //Check number of filters without ALL
    {
    	$filters = $this->getFilters();
    	$i=0;
        foreach ($filters as $filter) {
            $filter_val = JRequest::getVar($filter->field_name);
            	if ($filter_val and ($filter_val != 'ALL'))
                $i++;
        }
        return $i;
    }
    
    function checkDataFilters()
    //Check if there are results she using filters
    {    
	    $go = true;	
		if($this->getFilterNumber()>0):
			if(count($this->dataCustFilter())==0):
				$go = false;
			endif;
		endif;
		
		return $go;
    }
    
    
    
    function setPage($page) {
        $this->_page = $page;
        $this->_data = null;
    }
    
    function getTotal() {
        if (empty($this->_total)) {
		    $query = $this->_buildQuery();
		    $query .= $this->_buildFilter();
		    $query .= ' group by a.kentry_id';
		    $query .= ' order by i.priority, a.priority';
		    
		    
		    $this->_db->setQuery($query);
		    $this->_db->query();
		    $this->_total = $this->_db->getNumRows();
		}
		
		if($this->checkDataFilters()):
			return $this->_total;
		else:
			return $this->_total = 0;
		endif;	
    }
    
    function getMaxPages($step=10) {
        $this->_step = $step;
        $total = $this->getTotal();
        $pages = floor($total / $step)+1;
        return $pages;
    }
    
    function getData() {


        if (empty($this->_data)) {
            $query = $this->_buildQuery();
            $query .= $this->_buildFilter();
            $query .= ' group by kentry_id';
            $query .= $this->getOrder();
            if ($this->_step)
                $query .= ' limit '.((JRequest::getVar('page')-1)*10).', '.$this->_step;
            
            $this->_db->setQuery($query);
            $this->_data = $this->_db->loadObjectList();
         
  
        }
     	if($this->checkDataFilters()):
        	return $this->_data;
        else:
        	return $this->_data = array();
        endif;
    }
    
    function getOrder()
    {
    
  
	  $params = &JComponentHelper::getParams( 'com_kaltura' );
	  $order = $params->get( 'order' );
	  
	    switch ($order) {
		    case 'titleasc':
		        $orderby = "kentry_name";
		        break;
		    case 'titledesc':
		        $orderby = "kentry_name desc";
		        break;
		    case 'manual':
		        $orderby = "kentry_priority";
		        break;
		    case 'mostrecent':
		        $orderby = "kentry_created_at";
		        break;
		    case 'oldestfirst':
		        $orderby = "kentry_created_at desc";
		        break;
		    case 'random':
		        $orderby = "RAND()";
		        break;                
		    default:
		        $orderby = "kentry_priority";
		}
			    

    	$query = ' order by '.$orderby;
    	
    	return $query;
    }
    
    function getFlavors() {
        $query = 'select flavor_params_ids from entry where id="'.$this->_item_id.'"';
        $this->_edb->setQuery($query);
        $flavors = $this->_edb->loadResult();
        $flavors_ids = explode(",", $flavors);
        
        $query = 'select name from flavor_params where id in (';
        foreach ($flavors_ids as $k => $id) { 
            $query .= $id.(($k < (count($flavors_ids)-1))?',':'');
        }
        $query .= ')';
        
        $this->_edb->setQuery($query);
        return $this->_edb->loadResultArray();
    }
    
    function getCategories(&$root=null, $parent=null) {
        $query = 'select * from category';
        
        if ($parent) $query .= ' where parent_id='.$parent->id;
        else $query .= ' where parent_id=0';
        
        $query .= ' and partner_id='.$this->_instance->userid;
        $query .= ' and deleted_at is null';
        
        $this->_edb->setQuery($query);
        $cat_bulk = $this->_edb->loadObjectList();
        
        foreach ($cat_bulk as &$cat) {
            if ($parent) $cat->parent = $parent->id;
            else $cat->parent = 0;
            $cat->children = array();
            $this->getCategories($cat->children, $cat);
        }
        
        if (!$parent) return $cat_bulk;
        else $root = $cat_bulk;
    }
    
    function getCustomFilters() {
        $query = 'select * from ';
    }
    
    function getInstances() {
        $query = 'select * from #__Kaltura_instances where public = 1 order by priority';
        $this->_db->setQuery($query);
        return $this->_db->loadObjectList();
    }
    
    function getFilters() {
        $query = 'select * from #__Kaltura_fields where field_filtrable = 1';
        $this->_db->setQuery($query);
        $objs = $this->_db->loadObjectList();

        foreach ($objs as $obj) {
           
            if ($obj->field_type == 1) {
                $query = 'select * from #__Kaltura_fields_values ';
                $query .= 'where field_id='.$obj->id;
                $query .= ' ORDER BY field_order';
                $this->_db->setQuery($query);
                $obj->values = $this->_db->loadObjectList();
       
            }
            else{
            	$obj->values = '';
            }
            
        }

	
        foreach ($objs as $ko => $obj):
       
        		if(is_array($obj->values)):
	        		foreach ($obj->values as $kv => $value):
		        		
		        		$query = 'select v.*,d.*  from #__Kaltura_entry_field_value v';
		        		$query .= ' INNER JOIN `#__Kaltura_entry_cdata` d ON d.kentry_id = v.kentry_id';
		        		$query .= ' INNER JOIN `#__Kaltura_instances` i ON i.userid = d.kentry_partner_id';
		                $query .= ' WHERE v.value="'.$value->field_value.'"';
		                $query .= ' AND v.field_id='.$value->field_id;
		                
		                $this->_db->setQuery($query);
		                $number = $this->_db->loadResult();
	        			
	        			if($number > 0):
	        				$objs[$ko]->values_filtered[] = $value;
	        			endif;
	        			        		
	        		endforeach;
				endif;	        	
        endforeach;

        return $objs;
    }
    
}
?>
