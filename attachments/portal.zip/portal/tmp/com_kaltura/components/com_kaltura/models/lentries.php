<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');
class KalturaModelLentries extends JModel
{
    var $_data;
    var $_page;
    var $_step;
    
    var $_id;
    var $_entry;
    
    var $_query;
    
    var $_tableid;

    function __construct() {
        if (JRequest::getVar('page')) {
            $this->_data = JRequest::getVar('page');
            $this->_step = JRequest::getVar('step');
        }
        
        parent::__construct();
    }
    
    function setId($id) {
        $this->_id = $id;
    }
    
    function _buildQuery() {
        $this->_query = 'select * from #__Kaltura_entry_cdata e';
        $this->_query .= ' inner join #__Kaltura_instances i ';
        $this->_query .= 'on e.kentry_partner_id=i.userid where i.id='.$this->_tableid;
        return $this->_query;
    }
    
    function _buildFilter() {
    
    }
    
    function _buildLimits() {
        $this->_query = ' limit '.($this->_page*$this->_step).', '.$this->_step;
    }
    
    function getData() {
        $this->_buildQuery();
        $this->_buildFilter();
        if ($this->_page) $this->_buildLimits();
        $this->_db->setQuery($this->_query);
        $this->_data = $this->_db->loadObjectList();
        return $this->_data;
    }
    
    function getElement() {
        $query = 'select * from #__Kaltura_entry_cdata where id='.$this->_id;
        $this->_db->setQuery($query);
        return $this->_db->loadObject();
    }
    
    function getMaxPages() {
        $this->_buildQuery();
        $this->_buildFilter();
        $this->_db->setQuery($this->_query);
        $total = $this->_db->getNumRows();
        return floor($total / $step)+1;
    }
    
    function setTableId($tableid) {
        $this->_tableid = $tableid;
    }
}
?>
