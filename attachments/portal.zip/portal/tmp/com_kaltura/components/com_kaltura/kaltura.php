<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.mootools');
JHTML::_('behavior.modal');
$document =& JFactory::getDocument();
$document->addScript('components'.DS.'com_kaltura'.DS.'assets'.DS.'js'.DS.'datepicker.js');
$document->addStyleSheet('components'.DS.'com_kaltura'.DS.'assets'.DS.'css'.DS.'kaltura.css');

// loading front-end required helpers
require_once('administrator'.DS.'components'.DS.'com_kaltura'.DS.'helpers'.DS.'externaldatabase.php');

// Require the base controller
require_once JPATH_COMPONENT.DS.'controller.php';
    
// Initialize the dedicated controller
if ($controller = JRequest::getWord('controller')) {
    // determine path
    $path = JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php';
    if (file_exists($path)) {
        require_once $path;
    } else $controller = '';
}

$classname = 'KalturaController'.$controller;
$controller = new $classname();

// Perform the Request task
$controller->execute(JRequest::getVar('task'));
$controller->redirect();
?>
