<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');
class KalturaControllerBrowser extends JController
{
    function __construct()
    {
        if (JRequest::getCmd('view') == '') {
            JRequest::getVar('view', 'default');
        }
        
        $this->item_type = 'Default';
        parent::__construct();        
    }
    
    function simpleTest()
    {
        $kaltura = $this->getModel('browser');
        
        $kaltura->setId(JRequest::getVar('tableid'));
        
        $view =& $this->getView('Browser', 'html');
        $view->setModel($kaltura, true);
        $view->display();
    }
    
    function showBrowser()
    {
        $kaltura = $this->getModel('browser');
        $model = $this->getModel('lentries');
        
        $table_id = JRequest::getVar('tableid');
        $kaltura->setId($table_id);
        $model->setTableId($table_id);
        
        $view =& $this->getView('newbrowser', 'html');
        $view->setModel($model, true);
        $view->setModel($kaltura);
        
        $view->display();
    }
    
    function loadTable()
    {
        $kaltura = $this->getModel('browser');
        
        $kaltura->setId(JRequest::getVar('tableid'));
        $kaltura->setPage(JRequest::getVar('page'));
        
        $view =& $this->getView('Table', 'raw');
        $view->setModel($kaltura, true);
        $view->display();
    }
    
    function loadNewTable()
    {
        $model = $this->getModel('lentries');
        $kaltura = $this->getModel('browser');
        
        $kaltura->setId(JRequest::getVar('tableid'));
        $model->setTableId(JRequest::getVar('tableid'));
        
        $view =& $this->getView('newtable', 'raw');
        $view->setModel($model, true);
        $view->setModel($kaltura);
        
        $view->display();
    }
}
?>
