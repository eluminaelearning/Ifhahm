<?php 
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');
class KalturaControllerContact extends JController
{
    function __construct() {
        if (JRequest::getCmd('view') == '') {
            JRequest::getVar('view', 'contact');
        }
        
        $this->item_type = 'Default';
        parent::__construct();
    }
    function sendMail()
    {
    		$params = &JComponentHelper::getParams( 'com_kaltura' );
			$mailcontactform =  $params->get( 'mailcontactform','gisele.burnett@freeband.tv');
			
			$data = JRequest::get( 'post' );
			$partner_id = JRequest::getVar('partner_id', '', 'post');
			$id = JRequest::getVar('id', '', 'post');
			
			$mailer =& JFactory::getMailer();
			$config =& JFactory::getConfig();
			$sender = array( 
			    $config->getValue( 'config.mailfrom' ),
			    $config->getValue( 'config.fromname' ) );
			 
			$mailer->setSender($sender);
			
			
			$recipient = array($mailcontactform);
			$mailer->addRecipient($recipient);
			
			$body   = '<h1>New contact form</h1>';
			$body  .= '<h2 style="font-size:14px;">From: '.JURI::base().'</h2>';
			$body .= '<div>It contains the following details:</div>';
			$body .= '<ul>';
			foreach ($data as $key => $d):
				
				if($key == 'titleprog')
					$key = 'Title requested';
				$body .= '<li><strong style="text-transform:uppercase;padding-right:6px;">'.$key.': </strong>'.$d.'</li>';
			
			endforeach;
			$body .= '</ul>';
	
	
			$mailer->isHTML(true);
			$mailer->Encoding = 'base64';
			$mailer->setBody($body);
	
			$link = 'index.php?option=com_kaltura&task=showDetails&controller=details&itemid='.$id.'&partner_id='.$partner_id.'&tmpl=component';
			$send =& $mailer->Send();
			if ( $send !== true ) {
				$msg = 'Error sending the mail';
			  	$app->redirect($link, $msg); 
			   	
			} else {
			  $app = JFactory::getApplication();
			  $msg = JText::_('FORMRECEIVED');
			  $app->redirect($link, $msg); 
			}
		

    }
    function sendcontact()
    { 
    
		      $params = &JComponentHelper::getParams( 'com_kaltura' );
			  $key_priv_recaptcha =  $params->get( 'recaptcha_private','');
		      $showcaptcha=  $params->get( 'showcaptcha',0);
			
			if($showcaptcha==1):
			
		      require_once( JPATH_COMPONENT.DS.'helpers'.DS.'recaptchalib.php' );	
			  $privatekey = $key_priv_recaptcha;
			  $resp = recaptcha_check_answer ($privatekey,
			                                $_SERVER["REMOTE_ADDR"],
			                                $_POST["recaptcha_challenge_field"],
			                                $_POST["recaptcha_response_field"]);
			
			  if (!$resp->is_valid) {
			    // What happens when the CAPTCHA was entered incorrectly
			    die ("<strong>".JText::_('ERRORCAPTCHA')."<br /></strong>" .
			         "(reCAPTCHA said: " . $resp->error . ")");
			  } else {
			    // Your code here to handle a successful verification	 			  
	
				  $this->sendMail();	
						
		 	  }//recaptcha
		
			else:
				 $this->sendMail();	
			endif;
    }
    function showDetails() {
        $kaltura = $this->getModel('browser');
        
        $id = JRequest::getVar('tableid');
        $itemid = JRequest::getVar('itemid');
        
        $kaltura->setId($id);
        $kaltura->setItemId($itemid);
    
        $view =& $this->getView('Details', 'raw');
        $view->setModel($kaltura, true);
        
        $view->display();
    }
}
?>
