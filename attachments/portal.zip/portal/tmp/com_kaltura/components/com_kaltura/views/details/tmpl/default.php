<?php
/**
 *   Kaltura Browser - components/com_kaltura/views/details/tmpl/default.php
 *   Author: Miguel Puig García (miguel@bittingbits.com)
 *   Author: Juan Dapena Paz (juan@bittingbits.com)
 *   Copyright (C) 2011 Bitting Bits S.L.
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


function formatMilliseconds($milliseconds) {
    $seconds = floor($milliseconds / 1000);
    $minutes = floor($seconds / 60);
    $hours = floor($minutes / 60);
    $milliseconds = $milliseconds % 1000;
    $seconds = $seconds % 60;
    $minutes = $minutes % 60;

    $format = '%u:%02u:%02u';
    $time = sprintf($format, $hours, $minutes, $seconds, $milliseconds);
    return rtrim($time, '0');
}


$params = &JComponentHelper::getParams( 'com_kaltura' );
$ServiceUrl =  $params->get( 'kalturacdn','http://streamservice.eurotvguild.com');
$height =  $params->get( 'heightvideo',320);
$width =  $params->get( 'widthvideo',400);
$uiconfig =  $params->get( 'uiconfig','4421625');
$playerid =  $params->get( 'playerid','1332090702');

?>

<div class="video_box_container">
	
	<div class="video_container">

<script type="text/javascript" src="http://html5.kaltura.org/js" ></script>
   
                <script type="text/javascript">
                        mw.setConfig( 'Kaltura.ServiceUrl' , '<?php echo $ServiceUrl;?>' );
                        mw.setConfig( 'Kaltura.CdnUrl' , 'http://streamservice.eurotvguild.com' );
                        mw.setConfig('EmbedPlayer.EnableIpadHTMLControls', false );
                </script>
                

	<object id="kaltura_player_<?php echo $playerid;?>" name="kaltura_player_<?php echo $playerid;?>" type="application/x-shockwave-flash" allowFullScreen="true" allowNetworking="all" allowScriptAccess="always" height="<?php echo $height;?>" width="<?php echo $width;?>" bgcolor="#000000" xmlns:dc="http://purl.org/dc/terms/" xmlns:media="http://search.yahoo.com/searchmonkey/media/" rel="media:video" resource="<?php echo $ServiceUrl;?>/index.php/kwidget/cache_st/<?php echo $playerid;?>/wid/_<?php echo $this->item->partner_id;?>/uiconf_id/<?php echo $uiconfig;?>/entry_id/<?php echo $this->item->id;?>" data="<?php echo $ServiceUrl;?>/index.php/kwidget/cache_st/<?php echo $playerid;?>/wid/_<?php echo $this->item->partner_id;?>/uiconf_id/<?php echo $uiconfig;?>/entry_id/<?php echo $this->item->id;?>"><param name="allowFullScreen" value="true" /><param name="allowNetworking" value="all" /><param name="allowScriptAccess" value="always" /><param name="bgcolor" value="#000000" /><param name="flashVars" value="&" /><param name="movie" value="<?php echo $ServiceUrl;?>/index.php/kwidget/cache_st/<?php echo $playerid;?>/wid/_<?php echo $this->item->partner_id;?>/uiconf_id/<?php echo $uiconfig;?>/entry_id/<?php echo $this->item->id;?>" /><a href="http://corp.kaltura.com">video platform</a> <a href="http://corp.kaltura.com/video_platform/video_management">video management</a> <a href="http://corp.kaltura.com/solutions/video_solution">video solutions</a> <a href="http://corp.kaltura.com/video_platform/video_publishing">video player</a> <a rel="media:thumbnail" href="<?php echo $ServiceUrl;?>/p/<?php echo $this->item->partner_id;?>/sp/10200/thumbnail/entry_id/<?php echo $this->item->id;?>/width/120/height/90/bgcolor/000000/type/2"></a> <span property="dc:description" content=""></span><span property="media:title" content=""></span> <span property="media:width" content="<?php echo $width;?>"></span><span property="media:height" content="<?php echo $height;?>"></span> <span property="media:type" content="application/x-shockwave-flash"></span> </object>
	


	</div>
	
	
	<div class="info_container">
	<div class="free_html_area">  
	  <a href="index.php?option=com_kaltura&view=contact&controller=contact&tmpl=component&itemname=<?php echo $this->item->name; ?>&itemid=<?php echo $this->item->id; ?>&partner_id=<?php echo $this->item->partner_id; ?>" class="contact_button"><?php echo JText::_('CONTACTFREEBAND'); ?></a>

	   
	</div>
	<?php if(isset($this->item->id)): ?>
		<h1><?php echo $this->item->joomladb->kentry_name; ?></h1>
				
		<div class="info_msecs custom_field">
		<span>Length:</span> 
		<?php 
echo formatMilliseconds($this->item->length_in_msecs);
		?>
		</div>
		<?php foreach ($this->fields as $field) {
		    $val = $this->kaltura->getFieldValue($field->id);

		    if ($val) {
		    
		    
		?>
		        <div class="custom_field">
		            <span><?php echo $field->field_label; ?>: </span>
		            <?php echo $val->value; ?>
		        </div>    
		<?php } } ?>
		<div class="info_description"><?php echo $this->item->joomladb->kentry_description; ?></div>
		
	<?php else: ?>
	
	Invalid Video
	<?php endif;  ?> 
	</div>
	
	<div class="clear"></div>

</div>

