<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

require_once( JPATH_COMPONENT.DS.'helpers'.DS.'Mobile_Detect.php' );
$detect = new Mobile_Detect();

$params = &JComponentHelper::getParams( 'com_kaltura' );
$showpartner =  $params->get( 'showpartner',1);
$widthmodal =  $params->get( 'widthmodal','920');
$heightmodal =  $params->get( 'heightmodal','500');



$tableid = JRequest::getVar('tableid');
?>

<?php
$k = 0; 


foreach($this->results as $r) { ?>

    <tr class="r<?php echo $k; ?>">
        <td class="image_ka">
        <div class="img_container imgteaser">
			
<?php if ($detect->isMobile()==1):?>
	<a href="index.php?option=com_kaltura&controller=details&task=showDetails&itemid=<?php echo $r->kentry_id; ?>&partner_id=<?php echo $r->kentry_partner_id;?>" id="id_<?php echo $r->kentry_id; ?>">
<?php else: ?>
	<a href="index.php?option=com_kaltura&controller=details&task=showDetails&tmpl=component&itemid=<?php echo $r->kentry_id; ?>&partner_id=<?php echo $r->kentry_partner_id;?>" id="id_<?php echo $r->kentry_id; ?>" class="boxed" rel="{handler:'iframe',size:{x:<?php echo $widthmodal;?>,y:<?php echo $heightmodal;?>}}">
<?php endif; ?>  
 <?php
			
			//CHECK if file exists
			if (@GetImageSize($this->kaltura_url."/p/100/sp/10000/thumbnail/entry_id/".$r->kentry_id."/width/120/height/90/bgcolor/ffffff")) {
				$default_image =$this->kaltura_url."/p/100/sp/10000/thumbnail/entry_id/".$r->kentry_id."/width/120/height/90/bgcolor/ffffff";
			} else {
				$url = JUri::base();
				$path_image = $url.'components/com_kaltura/assets/images/default_thumb1.png';
				$default_image =$path_image;
			}

		    ?>
		     
		        <img src="<?php echo $default_image;?>" alt="<?php echo $r->kentry_id; ?>"/>
		        <span class="more">&raquo; <?php echo JText::_('KALTURA_VIEWDETAILS'); ?></span>
	        </a>        	

        </div>
        </td>
        <td class="details_ka">
        	<div class="details_ka_container">
<?php

?>
        	
 <div class="entrytitle">

<?php if ($detect->isMobile()==1):?>
	<a href="index.php?option=com_kaltura&controller=details&task=showDetails&itemid=<?php echo $r->kentry_id; ?>&partner_id=<?php echo $r->kentry_partner_id;?>" id="id_<?php echo $r->kentry_id; ?>">
<?php else: ?>
	<a href="index.php?option=com_kaltura&controller=details&task=showDetails&tmpl=component&itemid=<?php echo $r->kentry_id; ?>&partner_id=<?php echo $r->kentry_partner_id;?>" id="id_<?php echo $r->kentry_id; ?>" class="boxed" rel="{handler:'iframe',size:{x:<?php echo $widthmodal;?>,y:<?php echo $heightmodal;?>}}">
<?php endif; ?>  

	<?php echo $r->kentry_name; ?>
</a>

<?php 

?>

</div>
		        <div class="categories_kal"><?php echo $r->kentry_categories; ?></div>
		        <div class="entrydescription"><?php print(neat_trim($r->kentry_description, 140)); ?></div>
            </div>
        </td>
        <td class="details_extra_ka"><?php 
            $minutes = floor(($r->kentry_length_in_msecs)/60000);
            $minutes_mod = ($r->kentry_length_in_msecs) % 60000;
            $seconds = floor($minutes_mod/1000);
            
            ?>
            <?php if($showpartner==1): ?>
            <div class="line_info">
	            <span class="kaltu_label partner"><?php echo JText::_('PARTNERPUBLISHER'); ?>:</span>
	            <span class="kaltu_value"><?php echo $r->partner; ?></span>
			</div>  
			<?php endif;?>
			
            <div class="line_info">
	            <span class="kaltu_label"><?php echo JText::_('LENGTH'); ?>:</span> 
	            <span class="kaltu_value"><?php echo (($minutes<10)?'0'.$minutes:$minutes).':'.(($seconds<10)?'0'.$seconds:$seconds); ?></span>
			</div>     
           
            
        </td>
    </tr>
<?php $k = 1 - $k; } ?>
<input type="hidden" name="rpage" id="rpage" value="<?php echo $this->page; ?>" />
<input type="hidden" name="rtpage" id="rtpage" value="<?php echo $this->tpages; ?>" />
<?php
function neat_trim($str, $n, $delim='...') {
   $len = strlen($str);
   if ($len > $n) {
       preg_match('/(.{' . $n . '}.*?)\b/', $str, $matches);
       return rtrim($matches[1]) . $delim;
   }
   else {
       return $str;
   }
}

?>
<tr>
	<td colspan="3">
	
	       <div class="clear"></div>
						        <div class="pagination_numbers">
							       <span class="gotopage"><?php echo JText::_('KALTURA_GOTOPAGE'); ?>: </span>
							       <?php		       	
							       	for ($i = 1; $i <= $this->tpages; $i++):
							       		?>
							       		<span class="pagenumber" id="<?php echo $i;?>"><a href="javascript:void(0);" id="<?php echo $i;?>" class="pagenumcall act<?php echo $i;?>"><?php echo $i;?></a></span>
							       		<?php
							       	endfor;
							       ?> 
						       </div>
	
	</td>
</tr>
						 
