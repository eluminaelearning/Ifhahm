<?php 
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access'); 
jimport('joomla.utilities.date');

$params = &JComponentHelper::getParams( 'com_kaltura' );
$showpublishers =  $params->get( 'showpublishers',1);
$showdurations =  $params->get( 'showdurations',1);
$showmediatypes =  $params->get( 'showmediatypes',1);
$showcustomfilters =  $params->get( 'showcustomfilters',1);
$showsearch=  $params->get( 'showsearch',1);
$searchtext =  $params->get( 'searchtext','Title search');
$positionfilters =  $params->get( 'positionfilters','left');
$description =  $params->get( 'description','');



if(($showpublishers==0) AND ($showdurations==0) AND ($showmediatypes==0) AND ($showcustomfilters==0)):
	$wide = ' widekaltura';
else:
	$wide = '';
endif;

?>
<div id="kaltura">
    <form name="mainForm" id="mainForm" method="post">

    <div id="kalturabrowser">
        
        
        <div class="kaltura_description" id="desckaltura">
        	<?php echo $description; ?>
        </div>
        
        <?php if($positionfilters=='left'):?>
        <div id="filtersarea" style="float:<?php echo $positionfilters;?> ;margin-right:10px;">
        <?php else: ?>
        <div id="filtersarea" style="float:<?php echo $positionfilters;?> ;margin-left:15px;">
        <?php endif;?>
        
        
        		<?php if($showsearch==1): ?>
        	    <div id="kalturasearch">
        	    <?php else: ?>
        	    <div id="kalturasearch" style="display:none">
        	    <?php endif;?>
        	    
        	    	<label for="searchfield"><?php echo $searchtext; ?></label>
			        <span class="searchbox"><input type="text" name="searchfield" id="searchfield" /></span>
			        <div class="clear"></div>
			        <span id="searchstart" class="input_special"><?php echo JText::_('KALTURA_SEARCH'); ?></span>
			        <span id="reset" class="input_special"><?php echo JText::_('KALTURA_RESET'); ?></span>
			    </div>
        		
        		
        
        	<?php if($showpublishers==1): ?>
            <div class="filter_artem">
            <?php else: ?>
            <div class="filter_artem" style="display:none;">
            <?php endif; ?>
                <label for="tableid"><?php echo JText::_('PUBLISHERS'); ?></label>
                <select id="tableid" name="tableid" value="<?php echo $this->instance_id; ?>">
                    <option value="0"><?php echo JText::_('ALL'); ?></option>
                    <?php foreach ($this->instances as $publisher) { ?>
                        <option value="<?php echo $publisher->id; ?>"
                                <?php echo (($publisher->id==$this->instance_id)?'selected="selected"':''); ?>>
                            <?php echo $publisher->instance_name; ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
            
            <?php if($showcustomfilters==1): ?>
            <div id="boxtab2" class="boxtab">
            <?php else: ?>
            <div id="boxtab2" class="boxtab nodisplay">
             <?php endif; ?>

                <div id="boxtab2-content" class="boxtab-content">
                    <?php foreach ($this->filters as $filter) { ?><div class="filter_item">
                        <label for="<?php echo $filter->field_name; ?>">
                            <?php echo $filter->field_label; ?>
                        </label>
                        <?php if ($filter->field_type == 0) { ?>
                            <input type="text" class="customfiltertext" name="<?php echo $filter->field_name; ?>" 
                                   id="<?php echo $filter->field_name; ?>" value="" />
                        <?php } else { ?>
                            <select class="customfiltersel" name="<?php echo $filter->field_name; ?>"
                                    id="<?php echo $filter->field_name; ?>">
                                <option value="ALL"><?php echo JText::_('ALL'); ?></option>
                                <?php foreach ($filter->values_filtered as $val) { ?>
                                    <option value="<?php echo $val->field_value; ?>">
                                        <?php echo $val->field_value; ?>
                                    </option>
                                <?php } ?>
                            </select>
                        <?php } ?>
                    </div><?php } ?>
                </div>
            </div>
            
            
            <?php if(($showdurations==1)OR($showmediatypes==1)): ?>
            <div id="boxtab1" class="boxtab">
            <?php else: ?>
            <div id="boxtab1" class="boxtab nodisplay">
            <?php endif;?>

                <div id="boxtab1-content" class="boxtab-content">
                    
                    <?php if($showdurations==1): ?>
                    <div class="durations">
                    <?php else: ?>
                    <div class="durations nodisplay">
                    <?php endif; ?>
                    
                        <div class="filter_all selected" id="durationall">
                            <?php echo JText::_('KALTURA_DURATIONS'); ?>
                        </div>
                        <ul class="filtcont">
                            <li class="duration" id="durationshort"><?php echo JText::_('KALTURA_SHORT'); ?></li>
                            <li class="duration" id="durationmedium"><?php echo JText::_('KALTURA_MEDIUM'); ?></li>
                            <li class="duration" id="durationlong"><?php echo JText::_('KALTURA_LONG'); ?></li>
                        </ul>
                    </div>
                  
                    
                    <?php if($showmediatypes==1): ?>
                    <div class="mediatypes">
                    <?php else: ?>
                    <div class="mediatypes nodisplay">
                    <?php endif; ?>
                    
                        <div class="filter_all selected" id="mediatypeall">
                            <?php echo JText::_('KALTURA_ALL_MEDIA_TYPES'); ?>
                        </div>
                        <ul class="filtcont">
                            <li class="mediatype" id="video"><?php echo JText::_('KALTURA_VIDEO'); ?></li>
                            <li class="mediatype" id="audio"><?php echo JText::_('KALTURA_AUDIO'); ?></li>
                        </ul>
                    </div>
                   
                </div>
            </div>
           
            
            

           
        </div>
        
        
        
        <div id="resultsarea" class="<?php echo $wide;?>">

                <table>
                    <!--<thead>
                        <th width="32"><?php echo JText::_('KALTURA_THUMB'); ?></th>
                        <th><?php echo JText::_('KALTURA_NAME'); ?></th>
                        <th><?php echo JText::_('KALTURA_DURATION'); ?></th>
                    </thead>-->
            
					<tfoot>
					    <tr>
					      <td colspan="3" class="pagination">
					      
					      
						 		<span class="paginator" id="first"><?php echo JText::_('KALTURA_FIRST'); ?></span>
						        <span class="paginator" id="prev"><?php echo JText::_('KALTURA_PREV'); ?></span>
						        
						        
						        <span id="actualpage" value="1">1</span> /
						        <span id="totalpages" value="<?php echo $this->totalpages; ?>" >
						            <?php echo $this->totalpages; ?>
						        </span>
						       
						        <span class="paginator <?php echo ((1<$this->totalpages)?'enabled':''); ?>" id="next">
						            <?php echo JText::_('KALTURA_NEXT'); ?>
						        </span>
						        <span class="paginator <?php echo ((1<$this->totalpages)?'enabled':''); ?>" id="last">
						            <?php echo JText::_('KALTURA_LAST'); ?>
						        </span>   
						        

						        
					      </td>
					    </tr>
					  </tfoot>
					                    
                    <tbody id="table_tbody">
                    
                    </tbody>
                </table>

        </div>
    </div>
  
    <input type="hidden" name="page" id="page" value="1" />
    <input type="hidden" name="tpages" id="tpages" value="<?php echo $this->totalpages; ?>" />
    <input type="hidden" name="controller" id="controller" value="browser" />
    <input type="hidden" name="task" id="task" value="simpleTest" />
    <input type="hidden" name="option" id="option" value="com_kaltura" />
    
    <div style="display:none;">
    <div id="sqbox" class="modal"></div>
    </div>
    <div class="msgcont">
        <div id="loadingbox" class="notvisible"><?php echo JText::_('KALTURA_LOADING'); ?></div>
    </div>
    </form>
</div>

<?php
function print_categories($categories, $level=0) {
    if ($level==0) echo '<div class="category selected" id="categoriesall">All</div>';
    foreach ($categories as $cat) {
        echo '<div class="category level'.$level.'" id="'.$cat->id.'">';
        for ($i = 0; $i < $level+1; $i++) echo "&nbsp;&nbsp;&nbsp";
        if (!empty($cat->children)) echo '<b>';
        echo $cat->name;
        echo '<input type="hidden" name="parent" id="parent'.$cat->id.'" value="'.$cat->parent.'" />';
        echo '</div>';
        if (!empty($cat->children)) echo '</b>';
        
        if (!empty($cat->children)) {
            echo '<div class="childrenbox" id="children'.$cat->id.'">';
            print_categories($cat->children, $level+1);
            echo '</div>';
        }
    }
}
?>
