<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
$k = 0; 
foreach($this->results as $r) { ?>
    <tr class="r<?php echo $k; ?>">
        <td class="image_ka">
        <div class="img_container imgteaser">
	        <a href="javascript:void(0);" id="id_<?php echo $r->id; ?>" class="clickrow">
		        <img src="<?php echo $this->kaltura_url;?>/p/100/sp/10000/thumbnail/entry_id/<?php echo $r->id; ?>/width/120/height/90/bgcolor/000000/type/2" alt="<?php echo $r->id; ?>"/>
		        <span class="more">&raquo; <?php echo JText::_('KALTURA_VIEWDETAILS'); ?></span>
	        </a>
	        

	        
        </div>
        </td>
        <td class="details_ka">
        	<div class="details_ka_container">
		        <div class="entrytitle"><a href="javascript:void(0);" id="id_<?php echo $r->id; ?>" class="clickrow entrytitlelink" alt="<?php echo JText::_('KALTURA_VIEWDETAILS'); ?>"><?php echo $r->name; ?></a></div>
		        <div class="categories_kal"><?php echo $r->categories; ?></div>
		        <div class="entrydescription"><?php echo short_desc($r->description); ?></div>
            </div>
        </td>
        <td class="details_extra_ka"><?php 
            $minutes = floor(($r->length_in_msecs)/60000);
            $minutes_mod = ($r->length_in_msecs) % 60000;
            $seconds = floor($minutes_mod/1000);
            
            ?>
            <div class="line_info">
	            <span class="kaltu_label"><?php echo JText::_('LENGTH'); ?>:</span> 
	            <span class="kaltu_value"><?php echo (($minutes<10)?'0'.$minutes:$minutes).':'.(($seconds<10)?'0'.$seconds:$seconds); ?></span>
			</div>     
			
			<div class="line_info">
	            <span class="kaltu_label"><?php echo JText::_('KALTURA_CREATED_ON'); ?>:</span> 
	            <span class="kaltu_value"><?php echo $r->created_at; ?></span>
			</div>               
            
            
            
        </td>
    </tr>
<?php $k = 1 - $k; } ?>
<input type="hidden" name="rpage" id="rpage" value="<?php echo $this->page; ?>" />
<input type="hidden" name="rtpage" id="rtpage" value="<?php echo $this->tpages; ?>" />
<?php
    function short_desc($desc) {
        if (strlen($desc) > 140) {
            return substr($desc, 0, 140).'...';
        } else return $desc;
    }
?>
