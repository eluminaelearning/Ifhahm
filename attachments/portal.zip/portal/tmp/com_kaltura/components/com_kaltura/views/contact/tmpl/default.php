<?php
/*
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
?>
<div class="contact_form">
	<?php
	
	$params = &JComponentHelper::getParams( 'com_kaltura' );
	$key_publ_recaptcha =  $params->get( 'recaptcha_public','');
	$langcaptcha=  $params->get( 'langcaptcha','en');
	$showcaptcha=  $params->get( 'showcaptcha',0);
	
	
	 $link = 'index.php?option=com_kaltura&task=showDetails&controller=details&itemid='.$this->id.'&partner_id='.$this->partner_id.'&tmpl=component';
	?>
	<div class="getbackbt">
		<a class="contact_button" href="<?php echo $link;?>">< <?php echo JText::_('GETBACK'); ?></a> 
	</div>
	<form name="contact" id="contactform" action="index.php?option=com_kaltura&view=contact&controller=contact&task=sendcontact&tmpl=component" method="post">
	
		<div class="item_contact_form">
			<label for="name"><?php echo JText::_('NAME'); ?> <span class="required">*</span></label>
			<input class="input_contact required" name="name" value="" type="text">
		</div>
		
		<div class="item_contact_form">
			<label for="company"><?php echo JText::_('COMPANY'); ?> <span class="required">*</span></label>
			<input class="input_contact required" name="company" value="" type="text">
		</div>
		
		<div class="item_contact_form">
			<label for="position"><?php echo JText::_('POSITION'); ?></label>
			<input class="input_contact" name="position" value="" type="text">
		</div>
		
		<div class="item_contact_form">
			<label for="email"><?php echo JText::_('EMAIL'); ?> <span class="required">*</span></label>
			<input class="input_contact required email" name="email" value="" type="text">
		</div>
		
		<div class="item_contact_form">
			<label for="phone"><?php echo JText::_('PHONE'); ?></label>
			<input class="input_contact" name="phone" value="" type="text">
		</div>
		
		<div class="item_contact_form">
			<label for="mobile"><?php echo JText::_('MOBILE'); ?></label>
			<input class="input_contact" name="mobile" value="" type="text">
		</div>
		
		
		<div class="item_contact_form">
			<label for="comments"><?php echo JText::_('COMMENTS'); ?></label>
			<textarea class="input_contact" name="comments"></textarea>
		</div>
		
<?php 

if($showcaptcha==1): ?>
		 <script type="text/javascript">
		 var RecaptchaOptions = {
		    theme : 'clean',
		    lang: '<?php echo $langcaptcha;?>'
		 };
		 </script>
		<div class="recaptcha_cont">
		<?php
		  require_once( JPATH_COMPONENT.DS.'helpers'.DS.'recaptchalib.php' );	
          $publickey = $key_publ_recaptcha; // you got this from the signup page
          echo recaptcha_get_html($publickey);
        ?>
        </div>
        
<?php endif; ?>        



		<input type="hidden" name="titleprog" value="<?php echo $this->titleprog;?>">	
		<input type="hidden" name="partner_id" value="<?php echo $this->partner_id;?>">	
		<input type="hidden" name="id" value="<?php echo $this->id;?>">	
		
		<input type="submit" value="<?php echo JText::_('SUBMITFORM'); ?>" class="submitbutton">
	
	</form>

</div>