<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.controller' );
class KalturaControllerValidate extends JController
{
    function __construct() {
        if (JRequest::getCmd('view') == '') {
            JRequest::getVar('view', 'default');
        }
        $this->item_type = 'Default';
        parent::__construct();
    }
    
    function validateLicense()
    {
    	$url = JURI::base(); 
		$url_ar = parse_url($url);

	
	    	$license_number = JRequest::getVar('license_number', '', 'post');
	    	$key = JRequest::getVar('key', '', 'post');
	
			$m = substr($license_number,0,2);
			$y = substr($key,7,2);
			$d = '01';		
			$df = '20'.$y.'-'.$m.'-'.$d.' 00:00:00';
			$df_form = strtotime($df);


		$date =& JFactory::getDate();
		$datenow = $date->toFormat();
		$datenow_form = strtotime($datenow);
		
		
	
		$url_ar = preg_replace('#^www\.(.+\.)#i', '$1', $url_ar['host']);
		
		
		$hash = substr(md5($license_number.$url_ar),0,7);
		
		$database =& JFactory::getDBO();
		$query = "SELECT * FROM `#__extensions` WHERE `element` = 'com_kaltura' AND `type` = 'component'";
		$database->setQuery( $query );
		$result = $database->loadObject();
		
		
		if($result){
				$newparams = new JParameter($result->params);
			
			if($hash === substr($key,0,7)):
				
				if($datenow_form > $df_form):
					
					$newparams->set('licensevalid', 3);									
		    		$msg = JText::_('VALIDATIONEXPIRED');
		    		$newparams->set('validdate', $df);
		    		$type = 'error';
									
				else:
				
					$newparams->set('licensevalid', 1);
					$newparams->set('validdate', $df);										
		    		$msg = JText::_('VALIDATIONOK');
		    		$type = '';
		    		
	    		endif;
	    		
	    	else:
	    		$newparams->set('licensevalid', 0);	
	    		$msg = JText::_('VALIDATIONFAILED');
	    		$type = 'error';
	    		
	    	endif;
	    	
				$newparams->set('license_number', $license_number);
				$newparams->set('key', $key);
				$newparams->set('urllicense', $url_ar);
				$newparams = $newparams->toString();
				
	    		$database->setQuery( "UPDATE `#__extensions` SET params='".$newparams."' WHERE extension_id='".$result->extension_id."'");
    			if (!$database->query()) {
					JError::raiseWarning(100, $database->getErrorMsg());
					$mainframe->redirect( "index.php?option=com_kaltura&task=validate" );
				}	
		}		

    		$link 	= 'index.php?option=com_kaltura&task=validate';
			$this->setRedirect($link, $msg, $type);
		
		
    }

}
?>
