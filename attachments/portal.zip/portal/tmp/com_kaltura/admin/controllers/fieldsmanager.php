<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');
class KalturaControllerFieldsmanager extends JController
{
    
    function __construct() {
        if (JRequest::getCmd('view') == '') {
            JRequest::getVar('view', 'default');
        }
        $this->item_type = 'Default';
        parent::__construct();
        $this->registerTask('addfield', 'editfield');
    }
    
    function editField() {
        
    }
    
    function removeField() {
        $id = JRequest::getVar('id');
        $model = $this->getModel('fields');
        $model->setId($id);
        $model->removeField();
    }
    
    function addItem() {
        $fid = JRequest::getVar('id');
        $value = JRequest::getVar('value');
        
        $model = $this->getModel('fields');
        $id = $model->addItem($fid, $value);
        
        echo '<input type="hidden" name="eventid" id="eventid" value="'.$id.'" />';
        
        $fielditemtable = $this->getView('fielditemtable', 'raw');
        $fielditemtable->setModel($model, true);
        $fielditemtable->setId($id);
        $fielditemtable->display();
    }
    
    function removeItem() {
        $fid = JRequest::getVar('id');
        $value = JRequest::getVar('value');
        
        $model = $this->getModel('fields');
        $id = $model->removeItem($fid, $value);
        
        echo '<input type="hidden" name="eventid" id="eventid" value="'.$id.'" />';
        
        $fielditemtable = $this->getView('fielditemtable', 'raw');
        $fielditemtable->setModel($model, true);
        $fielditemtable->setId($id);
        $fielditemtable->display();
    }
    
    function saveItem() {
        $fid = JRequest::getVar('id');
        $fname = JRequest::getVar('fname');
        $fkey = JRequest::getVar('fkey');
        $ftype = JRequest::getVar('ftype');
        $fvisible = JRequest::getVar('fvisible');
        $fafiltrable = JRequest::getVar('fafiltrable');
        $ffiltrable = JRequest::getVar('ffiltrable');
        
        $model = $this->getModel('fields');
             
       
        if ($fid == 0) {
       	    if(ValidationHelper::fieldManager()): 
            $model->addField($fname, $fkey, $ftype, $fvisible, $fafiltrable,
                             $ffiltrable);
            
            else:
            
    
            endif;
                             
        } else $model->saveField($fid, $fname, $fkey, $ftype, $fvisible,
                                 $fafiltrable, $ffiltrable);
    }
    
    function getItem() {
        $view = $this->getView('fieldservices', 'raw');
        $model = $this->getModel('fields');
        $view->setModel($model, true);
        $view->display();
    }
    
    function getFieldValues() {
        $id = JRequest::getVar('id');
        
        $model = $this->getModel('fields');
        
        echo '<input type="hidden" name="eventid" id="eventid" value="'.$id.'" />';
        $fielditemtable = $this->getView('fielditemtable', 'raw');
        $fielditemtable->setModel($model, true);
        $fielditemtable->setId($id);
        $fielditemtable->display();
    }
    
    function changeOrder() {
        $id = JRequest::getVar('id');
        $field_id = JRequest::getVar('field_id');
        $go_up = JRequest::getVar('go_up');
        
        $model = $this->getModel('fields');
        $model->changeOrder($field_id, $id, $go_up);
        
        echo '<input type="hidden" name="eventid" id="eventid" value="'.$field_id.'" />';
        $fielditemtable = $this->getView('fielditemtable', 'raw');
        $fielditemtable->setModel($model, true);
        $fielditemtable->setId($field_id);
        $fielditemtable->display();
    }
}
