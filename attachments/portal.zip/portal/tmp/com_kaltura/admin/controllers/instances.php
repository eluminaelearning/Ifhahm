<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');
jimport( 'joomla.application.component.controller' );
class KalturaControllerinstances extends JController {
	function __construct() {
		if(JRequest::getCmd('view') == '') {
			JRequest::setVar('view', 'default');
		}
		$this->item_type = 'Default';
		parent::__construct();
		$this->registerTask('addinstances', 'editinstances');
	}
	function editinstances() {

		    if(!ValidationHelper::singlePartner())
				$this->setRedirect('index.php?option=com_kaltura&task=validate', JText::_( 'CANNOTADDMOREPARTNERS' ), 'error');
	
	
		$view =& $this->getView('editinstances', 'html');
		JRequest::setVar('hidemainmenu', 1);
		
		$model = $this->getModel('instances');
		$user =& JFactory::getUser();
		$view->setModel($model, true);
		
		$view->display();
	}
	function save() {
	
		$model = $this->getModel('instances');
		if ($model->store()) {
			$msg = JText::_('KALTURA_SAVED');
		} else {
			$msg = JText::_('KALTURA_ERROR_SAVED');
		}
		$link 	= 'index.php?option=com_kaltura&view=instances';
		$this->setRedirect($link, $msg);
	}
	function delete() {
		$model = $this->getModel('instances');
		$cid = JRequest::getVar( 'cid', array(0));
		if (!is_array($cid) || count($cid) < 1) {
			$msg = '';
			JError::raiseWarning(500, JText::_( 'SELECT_DELETE' ) );
		} else {
			foreach ($cid as $id) {
		        if (!$model->delete($id)) {
			        JError::raiseError(500, JText::_('DELETE_FAILED').'<pre>'.print_r($cid, true).'</pre>');
		        }
	        }
            $msg = count($cid).' '.JText::_( 'SELECTED_DELETE' );
            $cache = &JFactory::getCache('com_kaltura');
            $cache->clean();
	    }
		$this->setRedirect( 'index.php?option=com_kaltura&view=instances', $msg );
	}
	
	function newclone() {
		if(!ValidationHelper::singlePartner())
			$this->setRedirect('index.php?option=com_kaltura&task=validate', JText::_( 'CANNOTADDMOREPARTNERS' ), 'error');
			
	    $view =& $this->getView('editinstances', 'html');
		JRequest::setVar('hidemainmenu', 1);
		
		$model = $this->getModel('instances');
		$user =& JFactory::getUser();
		$view->setModel($model, true);
		$view->setClone(true);
		
		$view->display();
	}
	
	function saveorder() {
        
        $db = JFactory::getDBO();
        $cid = JRequest::getVar( 'cid', array(), 'post', 'array' );
        $total = count($cid);
        $order= JRequest::getVar( 'order', array(0), 'post', 'array' );
    	JArrayHelper::toInteger($order, array(0));
    	
    	foreach ($cid as $i => $id) {
    	

    	    $query = 'update #__Kaltura_instances set priority='.$order[$i];
    	    $query .= ' where id='.$id;
    	    $db->setQuery($query);
    	    $db->query();
    	    

    	}

    	    $query = 'select * from #__Kaltura_instances ORDER BY priority asc';
    	    $db->setQuery($query);
    	  	$instances_k = $db->loadAssocList();
		
		for($i=0; $i < count($instances_k); $i++):
			
			$query = 'update #__Kaltura_instances set priority='.$i;
    	    $query .= ' where id='.$instances_k[$i]['id'];
    	    $db->setQuery($query);
    	    $db->query();
		
		endfor;
		
   	$link 	= 'index.php?option=com_kaltura&view=instances';
        
        $this->setRedirect($link);
    }


    function orderup() {
        $cid = JRequest::getVar('cid', array(0), 'post', 'array');
        $db = JFactory::getDBO();
        $id = $cid[0];
        
        $query = 'select priority from #__Kaltura_instances where id='.$id;
        $db->setQuery($query);
        $priority = $db->loadResult();
        
        $query = 'select priority from #__Kaltura_instances where priority='.($priority-1);
        $db->setQuery($query);
        $newpriority = $db->loadResult();
        
        $query = 'update #__Kaltura_instances set priority='.$priority.' where priority='.$newpriority;
        $db->setQuery($query);
        $db->query();
        
        $query = 'update #__Kaltura_instances set priority='.$newpriority.' where id='.$id;
        $db->setQuery($query);
        $db->query();
        
        $link 	= 'index.php?option=com_kaltura&view=instances';
        
        $this->setRedirect($link);
    }
    
    function orderdown() {
        $cid = JRequest::getVar('cid', array(0), 'post', 'array');
        $db = JFactory::getDBO();
        $id = $cid[0];
        
        $query = 'select priority from #__Kaltura_instances where id='.$id;
        $db->setQuery($query);
        $priority = $db->loadResult();
        
        $query = 'select priority from #__Kaltura_instances where priority='.($priority+1);
        $db->setQuery($query);
        $newpriority = $db->loadResult();
        
        $query = 'update #__Kaltura_instances set priority='.$priority.' where priority='.$newpriority;
        $db->setQuery($query);
        $db->query();
        
        $query = 'update #__Kaltura_instances set priority='.$newpriority.' where id='.$id;
        $db->setQuery($query);
        $db->query();
        
        $link 	= 'index.php?option=com_kaltura&view=instances';
        
        $this->setRedirect($link);
    }
}
?>
