<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.controller' );
class KalturaControllerNotes extends JController
{
    function __construct() {
        if (JRequest::getCmd('view') == '') {
            JRequest::getVar('view', 'default');
        }
        $this->item_type = 'Default';
        parent::__construct();
        $this->registerTask('addnote', 'editnote');
    }
    
    function editnote() {
        $model =& $this->getModel('notes');
        $view =& $this->getView('editnote', 'html');
        $view->setModel($model, true);
        $view->setModel($this->getModel('fields'));
        $view->setModel($this->getModel('localentries'));
        $view->setModel($this->getModel('instances'));
        $view->display();
    }
    
    function save() {
        $model =& $this->getModel('notes');
        if ($model->store()) {
			$msg = JText::_('KALTURA_SAVED');
		} else {
			$msg = JText::_('KALTURA_ERROR_SAVED');
		}
		$link 	= 'index.php?option=com_kaltura&view=notes';
		$this->setRedirect($link, $msg);
    }
    
    function deletenote() {
        $model = $this->getModel('notes');
		$cid = JRequest::getVar( 'cid', array(0));
		if (!is_array($cid) || count($cid) < 1) {
			$msg = '';
			JError::raiseWarning(500, JText::_( 'SELECT_DELETE' ) );
		} else {
			foreach ($cid as $id) {
		        if (!$model->delete($id)) {
			        JError::raiseError(500, JText::_('DELETE_FAILED').'<pre>'.print_r($cid, true).'</pre>');
		        }
	        }
            $msg = count($cid).' '.JText::_( 'SELECTED_DELETE' );
            $cache = &JFactory::getCache('com_kaltura');
            $cache->clean();
	    }
		$this->setRedirect( 'index.php?option=com_kaltura&view=notes', $msg );
    }
}
?>
