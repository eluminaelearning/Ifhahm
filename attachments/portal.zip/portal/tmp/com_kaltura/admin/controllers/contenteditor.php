<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');
class KalturaControllerContenteditor extends JController
{
    function __construct() {
        if (JRequest::getCmd('view') == '') {
            JRequest::getVar('view', 'default');
        }
        $this->item_type = 'Default';
        parent::__construct();
    }
    
    function update() {
        $entry_id = JRequest::getVar('entryid');
        $field_id = JRequest::getVar('fieldid');
        $value = JRequest::getVar('value');
        
        $model = $this->getModel('entries');
        if ($field_id == 'name') {
            echo $model->setName($entry_id, $value);
        } else if ($field_id == 'description') {
            echo $model->setDescription($entry_id, $value);
        } else echo $model->setValue($entry_id, $field_id, $value);
    }
    
    function toggleVisible() {
        $entry_id = JRequest::getVar('entryid');
        
        $model = $this->getModel('entries');
        
        $result = $model->toggleVisible($entry_id);
        
        if ($result) {
            echo '<img src="components/com_kaltura/assets/yes.png" alt="yes" />';
        } else {
            echo '<img src="components/com_kaltura/assets/no.png" alt="no" />';
        }
    }
    
    function toggleSoldStatus() {
        $entry_id = JRequest::getVar('entryid');
        
        $model = $this->getModel('entries');
        
        $result = $model->toggleSoldStatus($entry_id);
        if ($result == 0) {
            echo '<img src="components/com_kaltura/assets/unsold.png" alt="unsold" />';
        } else if ($result == 1){
            echo '<img src="components/com_kaltura/assets/soldprocess.png" alt="soldprocess" />';
        } else echo '<img src="components/com_kaltura/assets/sold.png" alt="sold" />';
    }
}
?>
