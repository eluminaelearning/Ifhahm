<?php
/*
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
defined('_JEXEC') or die('Restricted access');
define( 'com_kaltura_DIR', 'images'.DS.'Kaltura'.DS );
define( 'com_kaltura_BASE', JPATH_ROOT.DS.com_kaltura_DIR );
define( 'com_kaltura_BASEURL', JURI::root().str_replace( DS, '/', com_kaltura_DIR ));
JTable::addIncludePath(JPATH_COMPONENT_ADMINISTRATOR.DS.'tables');

require_once JPATH_COMPONENT.DS.'controller.php';

require_once JPATH_COMPONENT.DS.'helpers'.DS.'kaltura'.DS.'KalturaClient.php';
require_once JPATH_COMPONENT.DS.'helpers'.DS.'kaltura'.DS.'plg'.DS.'kaltura_accp.php';
require_once JPATH_COMPONENT.DS.'helpers'.DS.'kaltura'.DS.'plg'.DS.'kaltura_acp.php';
require_once JPATH_COMPONENT.DS.'helpers'.DS.'kaltura'.DS.'plg'.DS.'kaltura_audit.php';
require_once JPATH_COMPONENT.DS.'helpers'.DS.'kaltura'.DS.'plg'.DS.'kaltura_cdp.php';
require_once JPATH_COMPONENT.DS.'helpers'.DS.'kaltura'.DS.'plg'.DS.'kaltura_dcp.php';
require_once JPATH_COMPONENT.DS.'helpers'.DS.'kaltura'.DS.'plg'.DS.'kaltura_ddcp.php';
require_once JPATH_COMPONENT.DS.'helpers'.DS.'kaltura'.DS.'plg'.DS.'kaltura_dfcp.php';
require_once JPATH_COMPONENT.DS.'helpers'.DS.'kaltura'.DS.'plg'.DS.'kaltura_itcp.php';
require_once JPATH_COMPONENT.DS.'helpers'.DS.'kaltura'.DS.'plg'.DS.'kaltura_mcp.php';
require_once JPATH_COMPONENT.DS.'helpers'.DS.'kaltura'.DS.'plg'.DS.'kaltura_podcast.php';
require_once JPATH_COMPONENT.DS.'helpers'.DS.'kaltura'.DS.'plg'.DS.'kaltura_sfcp.php';
require_once JPATH_COMPONENT.DS.'helpers'.DS.'kaltura'.DS.'plg'.DS.'kaltura_shortlink.php';
require_once JPATH_COMPONENT.DS.'helpers'.DS.'kaltura'.DS.'plg'.DS.'kaltura_spartner.php';
require_once JPATH_COMPONENT.DS.'helpers'.DS.'kaltura'.DS.'plg'.DS.'kaltura_tv.php';
require_once JPATH_COMPONENT.DS.'helpers'.DS.'kaltura'.DS.'plg'.DS.'kaltura_virus.php';
require_once JPATH_COMPONENT.DS.'helpers'.DS.'kaltura'.DS.'plg'.DS.'kaltura_xmlcp.php';
require_once JPATH_COMPONENT.DS.'helpers'.DS.'kaltura'.DS.'plg'.DS.'kaltura_youtube.php';
require_once JPATH_COMPONENT.DS.'helpers'.DS.'kaltura'.DS.'plg'.DS.'kaltura_youtubeapi.php';

require_once JPATH_COMPONENT.DS.'helpers'.DS.'externaldatabase.php';
require_once JPATH_COMPONENT.DS.'helpers'.DS.'submenu.php';
require_once JPATH_COMPONENT.DS.'helpers'.DS.'validation.php';


JHtml::_('behavior.framework', true);
$document =& JFactory::getDocument();
$document->addScript('components'.DS.'com_kaltura'.DS.'assets'.DS.'admin.js');
$document->addStyleSheet('components'.DS.'com_kaltura'.DS.'assets'.DS.'admin.css');

if ($controller = JRequest::getWord('controller')) {
	$path = JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php';
	if (file_exists($path)) {
		require_once $path;
	} else $controller = '';
}
$classname = 'KalturaController'.$controller;
$controller = new $classname();
$controller->execute( JRequest::getVar('task'));
$controller->redirect();
?>
