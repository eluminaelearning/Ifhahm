<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access'); ?>
<form action="index.php" method="post" name="adminForm">
<div id="editcell" class="select_it" style="float:none;">
<h2><?php echo JText::_('KALTURA_NOTES'); ?></h2>
	<table class="adminlist">
	    <thead>
	        <tr>
	            <th width="20">
	                <input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->data ); ?>);" />
	            </th>
	            <th>
	                <?php echo JText::_('KALTURA_NOTE_TITLE'); ?>
	            </th>
	            <th>
	                <?php echo JText::_('KALTURA_CONTACT_PERSON'); ?>
	            </th>
	            <th>
	                <?php echo JText::_('KALTURA_EMAIL'); ?>
	            </th>
	            <th>
	                <?php echo JText::_('KALTURA_NUMBER'); ?>
	            </th>
	            <th>
	                <?php echo JText::_('KALTURA_DATE'); ?>
	            </th>
	            <th>
	                <?php echo JText::_('KALTURA_MEETING_PLACE'); ?>
	            </th>
	
	        </tr>
	    </thead>
	    <tfoot>
	        <tr>
	    		<td colspan="8"><?php echo $this->pagination->getListFooter(); ?></td>
    		</tr>
	    </tfoot>
	    <tbody>
	        <?php
	        $k = 0;
	        $i = 0;
	        foreach ($this->data as $note) {
	            $checked = JHTML::_('grid.id', $i, $note->note_id);
	            $link = JRoute::_('index.php?option=com_kaltura&controller=notes&task=editnote&fromlist=1&cid[]='.$note->note_id); 
        		$delete_link = JRoute::_('index.php?option=com_kaltura&controller=notes&task=deletenote&cid[]='.$note->note_id); ?>
            <tr class="row<?php echo $k; ?>">
                <td>
                    <?php echo $checked; ?>
                </td>
                <td>
                    <a href="<?php echo $link; ?>">
                        <?php echo $note->note_title; ?>
                    </a>
                </td>
                <td>
                    <?php echo $note->note_contact; ?>
                </td>
                <td>
                    <?php echo $note->note_email; ?>
                </td>
                <td>
                    <?php echo $note->note_phone; ?>
                </td>
                <td>
                    <?php echo $note->note_time; ?>
                </td>
                <td>
                    <?php echo $note->note_meeting_place; ?>
                </td>
   
            </tr>
            <?php $k = 1 - $k; $i++; } ?>
	    </tbody>
	</table>
</div>

<input type="hidden" name="controller" value="notes" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="option" value="com_kaltura" />
<input type="hidden" name="view" value="notes" />
<input type="hidden" name="boxchecked" value="0" />

<input type="hidden" name="fromlist" value="1" />

</form>
