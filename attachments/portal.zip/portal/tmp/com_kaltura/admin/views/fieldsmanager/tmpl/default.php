<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access'); ?>
<form action="index.php" method="post" name="adminForm">
<div id="editcellitems" class="select_it">
	<h2><?php echo JText::_('KALTURA_FIELDS_MANAGER'); ?></h2>
    <table class="adminlist">
        <thead><tr>
            <th width="5"><?php echo JText::_('ID'); ?></th>
 			<th width="10"><?php echo JText::_('EDIT'); ?></th>
            <th width="50"><?php echo JText::_('FIELD_NAME'); ?></th>
            <th width="25"><?php echo JText::_('FIELD_VISIBLE'); ?></th>
            <th width="25"><?php echo JText::_('FIELD_ADM_FILTRABLE'); ?></th>
            <th width="25"><?php echo JText::_('FIELD_FILTRABLE'); ?></th>
        </tr></thead>
        <tfoot><tr>
            <td colspan="6">
                <?php echo $this->pagination->getListFooter() ?>
            </td>
        </tr></tfoot>
        <tbody>
            <?php
            $k = 0;
            foreach ($this->fields as $i => $field) { ?>
                <tr class="row<?php echo $k; ?> rowtable" id="row<?php echo $field->id;?>">
                    <td><?php echo $field->id; ?></td>
                    
                     <td class="selectablefield" id="field_<?php echo $field->id; ?>">
                        <img src="components/com_kaltura/assets/gear18.png" 
                                 alt="<?php echo JText::_('EDIT'); ?>" />
                    </td>
                    
                    <td class="selectablefield" id="field_<?php echo $field->id; ?>">
                        <?php echo $field->field_name; ?>
                    </td>
                    <td>
                        <?php if ($field->field_visible) { ?>
                            <img src="components/com_kaltura/assets/yes.png" 
                                 alt="<?php echo JText::_('FIELD_YES'); ?>" />
                        <?php } else { ?>
                            <img src="components/com_kaltura/assets/no.png"
                                 alt="<?php echo JText::_('FIELD_NO'); ?>" />
                        <?php } ?>
                    </td>
                    <td>
                        <?php if ($field->field_adm_filtrable) { ?>
                            <img src="components/com_kaltura/assets/yes.png" 
                                 alt="<?php echo JText::_('FIELD_YES'); ?>" />
                        <?php } else { ?>
                            <img src="components/com_kaltura/assets/no.png"
                                 alt="<?php echo JText::_('FIELD_NO'); ?>" />
                        <?php } ?>
                    </td>
                    <td>
                        <?php if ($field->field_filtrable) { ?>
                            <img src="components/com_kaltura/assets/yes.png" 
                                 alt="<?php echo JText::_('FIELD_YES'); ?>" />
                        <?php } else { ?>
                            <img src="components/com_kaltura/assets/no.png"
                                 alt="<?php echo JText::_('FIELD_NO'); ?>" />
                        <?php } ?>
                    </td>
                </tr>
            <?php $k = 1 - $k; } ?>
        </tbody>
    </table>
    <div id="debug">
    </div>
</div>
<div id="editdetails" class="select_it">
	
            <h2><?php echo JText::_('FIELD_BASE_FIELDS'); ?></h2>


    <div id="edittoolbar">
        <table class="toolbar" id="generaltoolbar">
        <tbody><tr>
        <td class="button" id="toolbar-new">
            <a href="#" onclick="javascript:void(0);" id="newbutton">
                <span class="icon-32-list-add" title="<?php echo JText::_('NEW'); ?>"></span>
                <?php echo JText::_('NEW'); ?>
            </a>
        </td>
        <td class="button" id="toolbar-delete">
            <a href="#" onclick="javascript:void(0);" id="deletebutton">
                <span class="icon-32-list-remove" title="<?php echo JText::_('DELETE'); ?>"></span>
                <?php echo JText::_('DELETE'); ?>
            </a>
        </td>
        </tr></tbody>
        </table>
        <table class="toolbar" id="spectoolbar">
        <tbody><tr>
        <td class="button" id="toolbar-save">
            <a href="#" onclick="javascript:void(0);" id="savebutton">
                <span class="icon-32-document-save" title="<?php echo JText::_('SAVE'); ?>"></span>
                <?php echo JText::_('SAVE'); ?>
            </a>
        </td>
        <td class="button" id="toolbar-cancel">
            <a href="#" onclick="javascript:void(0);" id="cancelbutton">
                <span class="icon-32-dialog-cancel" title="<?php echo JText::_('CANCEL'); ?>"></span>
                <?php echo JText::_('cancel'); ?>
            </a>
        </td>
        </tr></tbody>
        </table>
    </div>
    <div class="clear"></div>
    <div id="editdetailsform">
        <div id="editbaseform">
            <div class="fieldname">
                <label for="field_name"><?php echo JText::_('FIELD_NAME'); ?></label>
                <input type="text" name="field_name" id="field_name" value="" />
            </div>
            <div class="fieldname">
                <label for="field_key"><?php echo JText::_('FIELD_KEY'); ?></label>
                <input type="text" name="field_key" id="field_key" value="" />
            </div>
            <div class="fieldname">
                <label for="field_type"><?php echo JText::_('FIELD_TYPE'); ?></label>
                <select name="field_type" id="field_type">
                    <option value="0"><?php echo JText::_('FIELD_TEXT_TYPE'); ?></option>
                    <option value="1"><?php echo JText::_('FIELD_LIST_TYPE'); ?></option>
                </select>
            </div>
            <div class="fieldname">
                <label for="field_visible"><?php echo JText::_('FIELD_VISIBLE'); ?></label>
                <input type="checkbox" name="field_visible" id="field_visible" value="0" />

            </div>
            <div class="fieldname">
                <label for="field_adm_filtrable"><?php echo JText::_('FIELD_ADM_FILTRABLE'); ?></label>
                <input type="checkbox" name="field_adm_filtrable" id="field_adm_filtrable" value="0" />

            </div>
            <div class="fieldname">
                <label for="field_filtrable"><?php echo JText::_('FIELD_FILTRABLE'); ?></label>
                <input type="checkbox" name="field_filtrable" id="field_filtrable" value="0" />
               
            </div>
        </div>
        <div id="editlistform">
            <h4><?php echo JText::_('LIST_FIELD_EDITOR'); ?></h4>
            <div class="field_kal0">
                <label for="list_item"><?php echo JText::_('FIELD_LIST_ITEM'); ?></label>
                <input type="text" name="list_item" id="list_item" value="" />
                <span class="add-button" id="add-button"><?php echo JText::_('ADD'); ?></span>
            </div>
            <div class="field_kal1">
                <table>
                    <tbody id="field_list">
                        <tr><td></td>
                        </tr>
                    </tbody>                   
                </table>
            </div>
            
            <div class="field_footdel">
	            <input type="hidden" name="selecteditemid" id="selecteditemid" value="0" />
	            <a class="delete-button" id="delete-button" href="javascript:void(0);">
	                <?php echo JText::_('DELETE'); ?>
	            </a>
            </div>
            
        </div>
        <input type="hidden" name="selectedval" id="selectedval" value="0" />
    </div>
</div>
<div class="clear"></div>

<input type="hidden" name="option" value="com_kaltura" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="fieldsmanager" />
<input type="hidden" name="view" value="fieldsmanager" />

</form>
