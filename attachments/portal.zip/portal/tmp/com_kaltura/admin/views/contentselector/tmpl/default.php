<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');
?>
<form action="index.php" method="post" name="adminForm">
<div id="editcell" class="select_it" style="float:none;">
<h2><?php echo JText::_('COM_KALTURA_CONTENT_EDITOR'); ?></h2>
    <table class="adminlist">
    <thead>
        <tr>
            <th width="20">
                <input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->instances ); ?>)" />
            </th>
            <th width="200">
                <?php echo JText::_('KALTURA_INSTANCE_NAME'); ?>
            </th>
            <th>
                <?php echo JText::_('KALTURA_DESCRIPTION'); ?>
            </th>
        </tr>
    </thead>
    <tfoot>
        <tr><td colspan="3"><?php echo $this->pagination->getListFooter(); ?></td></tr>
    </tfoot>
    <tbody>
        <?php 
        $k = 0;
        foreach($this->instances as $i => $instance) { 
            $checked = JHTML::_('grid.id', $i, $instance->id);
        ?>
        <tr class="row<?php echo $k; ?>">
            <td><?php echo $checked; ?></td>
            <td><a href="index.php?option=com_kaltura&controller=contentselector&task=showcontent&iid=<?php echo $instance->id; ?>"><?php echo $instance->instance_name; ?></a></td>
            <td><?php echo $instance->desc; ?></td>
        </tr>
        <?php } ?>
    </tbody>
    </table>
    
    <input type="hidden" name="option" value="com_kaltura" />
    <input type="hidden" name="task" value="" />
    <input type="hidden" name="boxchecked" value="0" />
    <input type="hidden" name="controller" value="contentselector" />
    <input type="hidden" name="view" value="contentselector" />
</div>
</form>

