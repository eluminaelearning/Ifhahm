<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');
?>
<form action="index.php" method="post" name="adminForm">

<div class="config">
    <div class="sync_field cfield">
        <input type="checkbox" name="sync_field" id="sync_field" 
               value="<?php echo ($this->configuration->remote_sync?'ON':'OFF'); ?>"
               class="hasTip"
               title="<?php echo JText::_('KALTURA_SYNC_TOOLTIP'); ?>" 
               <?php echo ($this->configuration->remote_sync?'checked="checked"':''); ?> />
        <label for="sync_field" class="hasTip"
               title="<?php echo JText::_('KALTURA_SYNC_TOOLTIP'); ?>">
            <?php echo JText::_('KALTURA_SYNC'); ?>
        </label>
    </div>
    <div class="details_freehtml cfield">
        <label for="details_freehtml" class="hasTip"
               title="<?php echo JText::_('KALTURA_FREEHTML_TOOLTIP'); ?>">
            <?php echo JText::_('KALTURA_FREEHTML'); ?>
        </label>
        <?php
            $editor =& JFactory::getEditor();
            $params = array('smilies' => '0',
                            'style' => '1',
                            'layer' => '0',
                            'table' => '0',
                            'clear_entities' => '0');
            echo $editor->display('details_freehtml', 
                                  $this->configuration->details_freehtml, 
                                  '600', '400', '40', '20', false, $params);
        ?>
    </div>
</div>

<input type="hidden" name="option" value="com_kaltura" />
<input type="hidden" name="task" value="" />

</form>
