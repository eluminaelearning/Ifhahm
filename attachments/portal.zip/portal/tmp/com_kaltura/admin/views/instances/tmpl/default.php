<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access'); ?>
<form action="index.php" method="post" name="adminForm">
<div id="editcell" class="select_it" style="float:none;">
<h2><?php echo JText::_('INSTANCES_TITLE'); ?></h2>
	<table class="adminlist">
	<thead>
		<tr>
			<th width="20">
				<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->items ); ?>);" />
			</th>
			<th width="5">
				<?php echo JText::_('ID'); ?>
			</th>
			<th>
				<?php echo JText::_('KALTURA_INSTANCE_NAME'); ?>
			</th>
			<th>
				<?php echo JText::_('KALTURA_DESC'); ?>
			</th>
			<th>
				<?php echo JText::_('KALTURA_DBHOST'); ?>
			</th>
			<th width="120">
				<?php echo JText::_('KALTURA_DBUSER'); ?>
			</th>

			<th width="120">
			    <?php echo JText::_('KALTURA_PUBLIC'); ?>
			</th>
			<th width="8%">
			    <?php echo JHTML::_('grid.order',  $this->items ); ?>
			</th>
			<th>
			    <?php echo JText::_('KALTURA_DELETE'); ?>
			</th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<td colspan="10"><?php echo $this->pagination->getListFooter(); ?></td>
		</tr>
	</tfoot>
	<tbody>
		<?php
		$k = 0;
		$i = 0;
		$n = count($this->items);
		foreach ($this->items as &$row) { 
		$checked = JHTML::_('grid.id', $i, $row->id); 
		$link = JRoute::_('index.php?option=com_kaltura&controller=instances&task=editinstances&cid[]='.$row->id); 
		$delete_link = JRoute::_('index.php?option=com_kaltura&controller=instances&task=delete&cid[]='.$row->id); ?>
		<tr class="<?php echo 'row'.$k; ?>">
			<td>
				<?php echo $checked; ?>
			</td>
			<td>
				<?php echo $row->id; ?>
			</td>
			<td>
			    <a href="<?php echo $link; ?>">
				    <?php echo $row->instance_name; ?>
				</a>
			</td>
			<td>
				<?php echo $row->desc; ?>
			</td>
			<td>
				<?php echo $row->dbhost; ?>
			</td>
			<td>
				<?php echo $row->dbuser; ?>
			</td>

			<td>
			    <?php echo ($row->public?'<span class="yesb">yes</span>':'<span class="nob">no</span>'); ?>
			</td>
			<td class="order">
                <span><?php echo $this->pagination->orderUpIcon( $i, ($i > 0), 'orderup', 'Move Up'); ?></span>
                <span><?php echo $this->pagination->orderDownIcon( $i, $n, ($i < $n ), 'orderdown', 'Move Down'); ?></span>
                <input type="text" name="order[]" size="5" value="<?php echo $row->priority; ?>" class="text_area" style="text-align: center" />
            </td>
			<td>
			    <a href="<?php echo $delete_link; ?>">
			        <img src="components/com_kaltura/assets/delete.png" 
			             alt="<?php echo JText::_('KALTURA_DELETE'); ?>" />
			    </a>
			</td>
		</tr>
		<?php $k = 1 - $k; $i++; } ?>
	</tbody>
	</table>
</div>
<input type="hidden" name="option" value="com_kaltura" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="instances" />
<input type="hidden" name="view" value="instances" />
</form>
