<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access'); ?>

<?php
	$url = JURI::base(); 
	$url_ar = parse_url($url);
	$domain = $url_ar['host'];
	
	$params = &JComponentHelper::getParams( 'com_kaltura' );
	$license_number = $params->get( 'license_number','' );
	$key = $params->get( 'key','' );
	$licensevalid = $params->get( 'licensevalid',4 );
	$datevalid = $params->get( 'validdate','' );
	$date =& JFactory::getDate($datevalid);
?>

<?php if($licensevalid==1): ?>
	<div class="license_ok">
		<?php echo JText::sprintf('LICENSEOKMESSAGE', $date->toFormat('%Y-%m-%d') ); ?>
	</div>

<?php elseif($licensevalid==3): ?>
	<div class="license_ok expired">
		<?php echo JText::sprintf('LICENSEEXPIRED', $date->toFormat('%Y-%m-%d') ); ?>
	</div>

<?php elseif($licensevalid==0): ?>
	<div class="license_ok expired">
		<?php echo JText::sprintf('LICENSEWRONG'); ?>
	</div>


<?php elseif($licensevalid==4): ?>


<?php endif;?>

<form action="index.php?option=com_kaltura" method="post" name="adminForm" id="adminForm">
<table class="adminlist validate">
<thead>
	<th width="120" align="left" class='title' style="text-align: left;"></th>
	<td align="left" class='title' style="text-align: left;"></th>
</thead>
<tr>
	<td width="120" class='title'><?php echo JText::_( 'DOMAIN' );?></td>
	<td class='title'><?php echo $domain; ?></td>
</tr>

<tr>
	<td width="120" class='title'><?php echo JText::_( 'VALIDATIONKEY' );?></td>
	<td class='title'>
		<input type="text" name="license_number" size="30" value="<?php echo $license_number;?>" /> 
		
		<?php if($licensevalid==1): ?>
			<span class="tick yes"></span>
		<?php else: ?>
			<span class="tick no"></span>
		<?php endif; ?>
		
		
		<?php
		/*	if($params->get('license code', '')){
				echo $params->get('license code', '');
			}
	*/	?>
	</td>
</tr>
<tr>
	<td width="120" class='title'><?php echo JText::_( 'INSTANTKEY' );?></td>
	<td class='title'>
		<input type="text" name="key" size="30" value="<?php echo $key;?>"/>
		
		<?php if($licensevalid==1): ?>
			<span class="tick yes"></span>
		<?php else: ?>
			<span class="tick no"></span>
		<?php endif; ?>

	</td>
</tr>
<tr>
	<td width="120" class='title'><?php echo JText::_( 'JOOMTURAVERSION' );?></td>
	<?php
	$filename = JPATH_SITE.DS."administrator".DS."components".DS."com_kaltura".DS."kaltura.xml";
	$handle = fopen($filename, "r");
	$xml_content = fread($handle, filesize($filename));
	fclose($handle);
	preg_match('/<version>(.*?)<\/version>/i', $xml_content, $matches);
	if(isset($matches[1])){
		$version = $matches[1];
	}else{
		$version = 'NOT FOUND!';
	}
	?>
	<td class='title'><?php echo $version; ?>
	</td>
</tr>
<tr>
	<td></td>
	<td><input type="submit" value="<?php echo JText::_( 'VALIDATELICENSE' );?>"></td>
</tr>
</table>
<div class="upgrade">
	<?php 
	if($licensevalid==1): ?>
	<div class="logo enterprise"></div>
	<?php else: ?>
	<div class="logo basic"></div>
	<div class="message">
		<?php echo JText::_( 'UPGRDMESSAGE' );?>
	</div>
	<?php endif; ?>	
	
</div>
<input type="hidden" name="box checked" value="" />
<input type="hidden" name="controller" value="validate" />
<input type="hidden" name="task" value="validateLicense" />
<input type="hidden" name="option" value="com_kaltura" />
</form>