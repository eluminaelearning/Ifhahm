<?php 
/*
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
    $k = 0;
    foreach($this->data as $i => $item) { ?>
<tr class="row<?php echo $k;?>">
    <td>
        <div  class="selectable"  id="item_<?php echo $item->id; ?>">
            <?php echo $item->field_value; ?>
        </div>
    </td>
    <td width="20">
        <?php if ($item->field_order > 1) { ?>
            <div class="go_up" id="up_<?php echo $item->id; ?>">
                <img src="components/com_kaltura/assets/go-up.png" alt="<?php echo JText::_('GO_UP'); ?>" />
            </div>
        <?php } ?>
    </td>
    <td width="20">
        <?php if ($i < (count($this->data)-1)) { ?>
            <div class="go_down" id="down_<?php echo $item->id; ?>">
                <img src="components/com_kaltura/assets/go-down.png" alt="<?php echo JText::_('GO_DOWN'); ?>" />
            </div>
        <?php } ?>
    </td>
</tr>
<?php $k = 1 - $k; } ?>
