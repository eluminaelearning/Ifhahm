<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');

$document = JFactory::getDocument();
$document->addScript(JURI::base() . 'components/com_kaltura/assets/jquery/jquery-1.7.1.min.js');
$document->addScript(JURI::base() . 'components/com_kaltura/assets/jquery/script.jquery.js');
$script = 'baseurl = "'.JURI::base().'";';
$document-> addScriptDeclaration ($script);

?>
<h1<?php echo JText::_('EXPORTREPORTSTOOL'); ?></h1>

<form action="index.php" method="post" name="adminForm">


		<div class="filters_reports">	
				
							<input type="radio" name="type" value="pdf" class="radio1" checked="checked"> PDF
						<!--	<input type="radio" name="type" value="csv" class="radio1"> CSV | -->
						<input type="submit" value="<?php echo JText::_('GENERATEREPORT'); ?>" class="generate_button">		
						
						
		<span id="generating">
		<?php echo JText::_('GENERATINGREPORT'); ?>
		</span>
						
				<div class="clear"></div>
				
				

				
				<div class="select_it">
					<h2><?php echo JText::_('EXTRAINFO'); ?></h2>
					<div class="searchlive1">
						
						<div class="inputdetails">
							<label for="name"><?php echo JText::_('INCLIMAGETHUMBN'); ?></label>
							<input type="radio" name="showthumb" value="1" class="radio1" checked="checked"> <?php echo JText::_('YES'); ?><br />
							<input type="radio" name="showthumb" value="0" class="radio1"> <?php echo JText::_('NO'); ?><br />
							<div class="expl_expo">
								<?php echo JText::_('IMAGSPENDMORE'); ?>
							</div>
						</div>
						
						<div class="inputdetails">
							<label for="name"><?php echo JText::_('TOPNAME'); ?></label>
							<input type="text" name="name" class="name" value="Freeband.tv - Programme Catalogue">
						</div>
						<div class="inputdetails">					
							<label for="name"><?php echo JText::_('CONTACTNAME'); ?></label>
							<input type="text" value="Gisele Burnett" name="contactname">
						</div>
						
						<div class="inputdetails">					
							<label for="name"><?php echo JText::_('CONTACTDETAILS'); ?></label>
							<textarea name="contactdetails">Commercial Development Manager T: +44 (0) 7557 261 285 | E: Gisele.Burnett@freeband.tv</textarea>
						</div>
						
					</div>
					
				</div>
					
				<div class="select_it partnerssel">
					<h2><?php echo JText::_('PARTNERSSEC'); ?></h2>
					<select name="partners[]" multiple="multiple" size="10">
						<?php foreach ($this->instances as $instance): ?>
							<option value="<?php echo $instance->id;?>" selected="selected"><?php echo $instance->instance_name;?></option>
						<?php endforeach;?>
					</select>
				</div>
				
				<?php if(count($this->fields)>0):?>
				<div class="select_it">
					<h2><?php echo JText::_('3FIELDS'); ?></h2>
					
					<?php foreach ($this->fields as $field): ?>
					
						<div class="field_it">
						
						<h3><?php echo $field->field_label; ?></h3>	
							<div class="checked_show">
								<input type="checkbox" name="fieldshow[]" value="<?php echo $field->id;?>" checked="checked"> <label for="show"><?php echo JText::_('SHOWKALT'); ?></label>
								<br />
								<input type="radio" name="orderfilter" value="<?php echo $field->id;?>" class="radio1" > <label><?php echo JText::_('ORDERKALT'); ?></label>
							
							</div>				
							<select name="fields[<?php echo $field->id;?>][]" multiple="multiple" size="5">
									<option id="<?php echo $field->id;?>" class="allselector" value="all" selected="selected">All</option>
								<?php foreach ($field->values as $value): ?>
									<option class="current" id="selector<?php echo $field->id;?>" value="<?php echo $value->id;?>"><?php echo $value->field_value;?></option>
							<?php endforeach;?>
							</select>
							
						</div>	
					<?php endforeach;?>
					<div class="clear"></div>
				</div>
				<?php endif;?>
				<div class="clear"></div>
				
				<div class="select_it">
					<h2><?php echo JText::_('EXTRAPROGRAMMES'); ?></h2>
					<div class="searchlive1">
		
						
						<input type="text" name="search" class="keywords">
						<button id="searchextra" class="search"><?php echo JText::_('SEARCH'); ?></button>
						<a href="javascript:void(0);" id="clearextra" class="searchclear"><?php echo JText::_('CLEAR'); ?></a>
						<div id="content">
							<span id="loading"></span>
							<div class="searchcontent">
								<ul id="add"></ul>
							</div>
						</div>
					</div>
					
				</div>
				
				<div class="select_it titlesad">
					<h2><?php echo JText::_('EXTRAADDED'); ?></h2>
					<div class="expl_expo">
						<?php echo JText::_('PROGINCEXP'); ?>
					</div>
					<div class="expl_expo">
						<?php echo JText::_('CLICKTODELETE'); ?>
					</div>
					<div class="searchlive1">
							
								<ul id="added">
							
								</ul>
							
				
					</div>
					
				</div>
				<div class="select_it titlesad">
					<h2><?php echo JText::_('EXTRADELETED'); ?></h2>
					<div class="expl_expo">
						<?php echo JText::_('WONTINCLUDEEXP'); ?>
					</div>
					<div class="expl_expo">
						<?php echo JText::_('CLICKTODELETE'); ?>
					</div>
					
					<div class="searchlive1">

							<ul id="deleted">
							
							</ul>
				
					</div>
					
				</div>
				

				
				
				<div class="clear"></div>
				
		</div>

<input type="hidden" name="option" value="com_kaltura" />
<input type="hidden" name="controller" value="exporttool" />
<input type="hidden" name="view" value="exportpdf" />
<input type="hidden" name="format" value="raw" />

</form>
