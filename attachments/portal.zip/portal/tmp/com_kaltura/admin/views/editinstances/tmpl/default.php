<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');?>
<form action="index.php" method="post" name="adminForm">
    <div id="col100">
		<table cellspacing="0" cellpading="0" border="0" width="100%">
			<tr>
				<td valign="top">
					<fieldset class="adminForm">
						<legend><?php echo JText::_('KALTURA_INSTANCES'); ?></legend>
						<table class="adminForm">
							<tbody>
							<tr>
							    <td width="100" align="right" class="key">
							        <label for="public"><?php echo JText::_('KALTURA_CHECKED'); ?></label>
							    </td>
							    <td>
							        <input type="checkbox" value="1" name="public" id="public" 
							               <?php echo (($this->instances->public)?'checked="checked"':''); ?>/>
							    </td>
							</tr>
							<tr>
								<td width="100" align="right" class="key">
									<label for="instance_name"><?php echo JText::_('KALTURA_NAME'); ?></label>
								</td>
								<td>
									<input class="text_area required" type="text" name="instances_instance_name" id="instances_instance_name" size="32" maxlength="255" value="<?php echo $this->instances->instance_name; ?>" />
								</td>
							</tr>
							<tr>
							    <td width="100" align="right" class="key">
							        <label for="instance_name">
							            <?php echo JText::_('KALTURA_PARTNER_ID'); ?>
							        </label>
							    </td>
							    <td>
							        <input class="text_area required" type="text" name="partner_id"
							               id="partner_id" size="32" maxlength="255"
							               value="<?php echo $this->instances->userid; ?>" />
							    </td>
							</tr>
							<tr>
							    <td width="100" align="right" class="key">
							        <label for="instance_url">
							            <?php echo JText::_('KALTURA_URL'); ?>
							        </label>
							    </td>
							    <td>
							        <input class="text_area required" type="text" name="kaltura_url"
							               id="kaltura_url" size="32" maxlength="255"
							               value="<?php echo $this->instances->kalturaurl; ?>" />
							    </td>
							</tr>
							<tr>
								<td width="100" align="right" class="key">
									<label for="desc"><?php echo JText::_('KALTURA_DESCRIPTION'); ?></label>
								</td>
								<td>
									<div>
										<?php
											$editor =& JFactory::getEditor();
											$params = array('smilies' => '0',
													'style' => '1',
													'layer' => '0',
													'table' => '0',
													'clear_entities' => '0');
											echo $editor->display('instances_desc', $this->instances->desc, '600', '400', '40', '20', false, $params);
										?>
									</div>
								</td>
							</tr>
							<tr>
								<td width="100" align="right" class="key">
									<label for="dbhost"><?php echo JText::_('KALTURA_DATABASE_HOST'); ?></label>
								</td>
								<td>
									<input class="text_area required" type="text" name="instances_dbhost" id="instances_dbhost" size="32", maxlength="255", value="<?php echo $this->instances->dbhost; ?>" />
								</td>
							</tr>
							<tr>
								<td width="100" align="right" class="key">
									<label for="dbuser"><?php echo JText::_('KALTURA_DATABASE_USER'); ?></label>
								</td>
								<td>
									<input class="text_area required" type="text" name="instances_dbuser" id="instances_dbuser" size="32", maxlength="255", value="<?php echo $this->instances->dbuser; ?>" />
								</td>
							</tr>
							<tr>
								<td width="100" align="right" class="key">
									<label for="dbpasswd"><?php echo JText::_('KALTURA_DATABASE_PASSWORD'); ?></label>
								</td>
								<td>
									<input class="text_area required" type="text" name="instances_dbpasswd" id="instances_dbpasswd" size="32", maxlength="255", value="<?php echo $this->instances->dbpasswd; ?>" />
								</td>
							</tr>
							<tr>
							    <td width="100" align="right" class="key">
							        <label for="secretkey">
							            <?php echo JText::_('KALTURA_SECRET_KEY'); ?>
							        </label>
							    </td>
							    <td>
							        <div>
							        <div class="fieldwt">
							            <input class="text_area required" 
							                   type="text" name="secretkey" 
							                   id="secretkey" size="42" 
							                   maxlength="255" 
							                   value="<?php echo $this->instances->secretkey; ?>" />
							        </div>
							        <div class="hasTip tooltip" title="<?php echo JText::_('SECRET_KEY_HELP'); ?>">
							            
							        </div>
							        </div>
							    </td>
							</tr>
							</tbody>
						</table>
					</fieldset>
				</td>
			</tr>
		</table>
	</div>

	<input type="hidden" name="check" value="post" />
	<input type="hidden" name="option" value="com_kaltura" />
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="controller" value="instances" />
	<input type="hidden" name="instances_id" value="<?php echo $this->instances->id; ?>" />
</form>
