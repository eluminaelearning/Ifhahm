<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

class KalturaViewContenteditor extends JView
{
    function display($tpl=null) {
        JHTML::_('behavior.tooltip');
    	$model =& $this->getModel('entries');
        
        $fields = $model->getFieldsList();
        $entries = $model->getEntries();
        $instances_model = $this->getModel('instances');
        $instances_model->setId(JRequest::getVar('iid'));
        $instance = $instances_model->getObject();
        $instances = $instances_model->getInstances();
        
        $filters = $model->getAdminFiltrableFields();
        
        JToolBarHelper::title($instance->instance_name,'mainlogo');
        JToolBarHelper::custom('sync', 'sync',
                               'Sync entries from kaltura',
                               'Sync', false, false);
        JToolBarHelper::deleteList();
        JToolBarHelper::preferences('com_kaltura');
        $this->assignRef('fields', $fields);
        $this->assignRef('entries', $entries);
        $this->assignRef('kmodel', $model);
        $this->assignRef('instance_id', JRequest::getVar('iid'));
        $this->assignRef('pagination', $model->getPagination());
        $this->assignRef('publishers', $instances);
        $this->assignRef('filters', $filters);
        SubmenuHelper::submenu();
        parent::display($tpl);
    }
}
?>
