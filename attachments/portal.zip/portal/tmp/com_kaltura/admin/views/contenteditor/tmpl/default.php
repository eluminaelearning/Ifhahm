<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');
$syncstatus = true;
?>
<div id="warningarea">
    <?php echo JText::_('KALTURA_SYNC_WARNING'); ?>
</div>
<form action="index.php" method="post" name="adminForm">
<div id="filterarea">
    <span>
        <?php echo JText::_('KALTURA_PUBLISHER'); ?>: 
        <select name="publisher" id="publisherselector">
            <?php foreach ($this->publishers as $publisher) { ?>
                <option value="<?php echo $publisher->id; ?>"
                    <?php echo (($publisher->id==$this->instance_id)?'selected="selected"':''); ?>>
                    <?php echo $publisher->instance_name; ?>
                </option>
            <?php } ?>
        </select>
    </span>
    <span><?php echo JText::_('KALTURA_SEARCH'); ?>
    <input type="text" name="freesearch" id="freesearch" value="" />
    </span>
    <?php foreach($this->filters as $filter) { ?>
        <span>
            <?php echo $filter->field_label; ?>
            <?php if ($filter->field_type) { 
                $values = $this->kmodel->getFilterValues($filter->id); ?>
                <select class="filterselector" name="<?php echo $filter->field_name; ?>">
                    <option value=""><?php echo JText::_('ALL'); ?></option>
                    <?php foreach ($values as $val) { ?>
                        <option value="<?php echo $val->field_value; ?>">
                            <?php echo $val->field_value; ?>
                        </option>
                    <?php } ?>
                </select>
            <?php } else { ?>
                <input type="text" class="filtertext" name="<?php echo $field->field_name; ?>"
                       id="<?php echo $field->field_name; ?>" value="" />
            <?php } ?>
        </span>
    <?php } ?>
    <span>
        <button name="submitsearch" value="submitsearch" id="submitsearch">
            <?php echo JText::_('SEARCH'); ?>
        </button>
    </span>
    <span>
        <button name="submitclean" value="submitclean" id="submitclean">
            <?php echo JText::_('KALTURA_CLEAN'); ?>
        </button>
    </span>
</div>
<div id="editcell" style="overflow:auto; height:100%;">
    <table class="adminlist">
        <thead><tr>
            <th width="2"><input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->entries ); ?>);" /></th>
            <th width="2"><?php echo JText::_('ID'); ?></th>
            <th width="100"><?php echo JText::_('KALTURA_NAME_LIT'); ?></th>
            <th width="100"><?php echo JText::_('KALTURA_DESC'); ?></th>

                <?php echo JHTML::_('grid.order',  $this->entries ); ?>
            </th>
            <?php foreach($this->fields as $field) { ?>
                <th width="100"><?php echo $field->field_label; ?></th>
            <?php } ?>
            
            <th width="20"><?php echo JText::_('KALTURA_IS_VISIBLE'); ?></th>
            
            <?php if(ValidationHelper::isValid()): ?>
	            <th width="20"><?php echo JText::_('KALTURA_SOLD_STATUS'); ?></th>
            <?php endif; ?>
            
            <th width="20"><?php echo JText::_('KALTURA_DELETE'); ?></th>
            <th width="8%"><?php echo JText::_('KALTURA_ORDER'); ?>
            
        </tr></thead>
        <tfoot>
		    <tr>
			    <td colspan="100"><?php echo $this->pagination->getListFooter(); ?></td>
		    </tr>
	    </tfoot>
        <tbody>
            <?php
            $k = 0;
            $n = count($this->entries);
            foreach ($this->entries as $i => $entry) {
                if ($entry->id) { 
                    $checked = JHTML::_('grid.id', $i, $entry->id); 
		            $delete_link = JRoute::_('index.php?option=com_kaltura&controller=contentselector&task=remove&cid[]='.$entry->id.'&iid='.JRequest::getVar('iid'));  }?>
		        <tr class="row<?php echo $k; ?>">
                    <td>
				        <?php echo $checked; ?>
			        </td>
                    <td><?php echo $entry->kentry_id; ?></td>
                    <td>
                        <div class="editbutton editlinktup hasTip" 
                             title="<?php echo JText::_('EDIT'); ?>: name::<?php echo $entry->kentry_name; ?>" 
                             id="editbutton_<?php echo $entry->kentry_id.'_name'; ?>">
                        </div>
                        <div class="edittable" id="edit_<?php echo $entry->kentry_id.'_name'; ?>">
                            <div class="label" id="label_<?php echo $entry->kentry_id.'_name'; ?>">
                                <?php echo $entry->kentry_name; ?>
                            </div>
                            <div class="field" id="field_<?php echo $entry->kentry_id.'_name'; ?>">
                                <div class="close_button" id="editbutton_<?php echo $entry->kentry_id.'_name'; ?>"></div>
                                <textarea class="area_field" id="input_<?php echo $entry->kentry_id.'_name'; ?>"><?php echo $entry->kentry_name; ?></textarea>
                                <div class="clear"></div>
                                <button onclick="return false;" 
                                        id="send_<?php echo $entry->kentry_id.'_name'; ?>" 
                                        class="send"><?php echo JText::_('KALTURA_SAVE'); ?></button>
                                <div class="clear"></div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="editbutton editlinktup hasTip" 
                             title="<?php echo JText::_('EDIT'); ?>: description::<?php echo $entry->kentry_name; ?>" 
                             id="editbutton_<?php echo $entry->kentry_id.'_description'; ?>"></div>
                        <div class="edittable" id="edit_<?php echo $entry->kentry_id.'_description'; ?>">
                            <div class="label descriptionhid" 
                                 id="label_<?php echo $entry->kentry_id.'_description'; ?>">
                                 <?php echo neat_trim($entry->kentry_description, 12); ?>
                            </div>
                            <div class="field" id="field_<?php echo $entry->kentry_id.'_description'; ?>">
                                <div class="close_button" 
                                     id="editbutton_<?php echo $entry->kentry_id.'_description'; ?>"></div>
                                <textarea class="area_field" 
                                          id="input_<?php echo $entry->kentry_id.'_description'; ?>"><?php echo $entry->kentry_description; ?></textarea>
                                <div class="clear"></div>
                                <button onclick="return false;" 
                                        id="send_<?php echo $entry->kentry_id.'_description'; ?>" 
                                        class="send"><?php echo JText::_('KALTURA_SAVE'); ?></button>
                                <div class="clear"></div>
                            </div>
                        </div>
                    </td>
                   
                    <?php foreach ($this->fields as $field) {
                        $value = $this->kmodel->getValue($entry->kentry_id, $field->id); ?>
                        <td>
                        	<div class="editbutton editlinktip hasTip" 
                        	     title="<?php echo JText::_('EDIT'); ?>: <?php echo $field->field_label; ?>::<?php echo $entry->kentry_name; ?>" 
                        	     id="editbutton_<?php echo $entry->kentry_id.'_'.$field->id; ?>"></div>
                            <div class="editable" 
                                 id="edit_<?php echo $entry->kentry_id.'_'.$field->id; ?>">
                            <div class="label" 
                                 id="label_<?php echo $entry->kentry_id.'_'.$field->id;?>">
                                 <?php echo $value; ?>
                            </div>
                            <div class="field" 
                                 id="field_<?php echo $entry->kentry_id.'_'.$field->id;?>">
                                <div class="close_button" id="editbutton_<?php echo $entry->kentry_id.'_'.$field->id; ?>"></div>
                                <?php if ($field->field_type == 1) { 
                                    $values = $this->kmodel->getFieldValues($field->id); ?>
                                    <select id="input_<?php echo $entry->kentry_id.'_'.$field->id;?>">
                                        <?php foreach ($values as $val) { ?>
                                            <option value="<?php echo $val->field_value; ?>">
                                                <?php echo $val->field_value; ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                <?php } else { ?>
                                <textarea class="area_field" 
                                          id="input_<?php echo $entry->kentry_id.'_'.$field->id;?>"><?php echo $value; ?></textarea>
                                <?php } ?>
                               
                                <div class="clear"></div>

                                <button onclick="return false;" 
                                        id="send_<?php echo $entry->kentry_id.'_'.$field->id; ?>" 
                                        class="send">
                                    <?php echo JText::_('KALTURA_SEND'); ?>
                                </button>
         						
         						<div class="clear"></div>
         						
                            </div>
                        </div>
                       
                        </td>
                    <?php } ?>
                    
                     <td>
                        <div class="togglevisible hasTip" 
                             title="<?php echo JText::_('TOGGLE_VISIBLE'); ?>" 
                             id="visible_<?php echo $entry->kentry_id; ?>">
                            <?php if (isset($entry->kentry_visible)) { ?>
                                <?php if ($entry->kentry_visible) { ?>
                                    <img src="components/com_kaltura/assets/yes.png" alt="yes" />
                                <?php } else { ?>
                                    <img src="components/com_kaltura/assets/no.png" alt="no" />
                                <?php } 
                            } else { $syncstatus = false; ?>
                                <img src="components/com_kaltura/assets/warn.png" alt="undefined" />
                            <?php } ?>
                        </div>
                    </td>
                    <?php if(ValidationHelper::isValid()): ?>
                    <td>
                        <div class="togglesoldstatus hasTip" 
                             title="<?php echo JText::_('TOGGLE_SOLD_STATUS'); ?>" 
                             id="sold_status_<?php echo $entry->kentry_id; ?>">
                            <?php if (isset($entry->kentry_sold_status)) { ?>
                                <?php if ($entry->kentry_sold_status == 0) { ?>
                                    <img src="components/com_kaltura/assets/unsold.png" alt="unsold" />
                                <?php } else if ($entry->kentry_sold_status == 1) { ?>
                                    <img src="components/com_kaltura/assets/soldprocess.png" alt="soldprocess" />
                                <?php } else { ?>
                                    <img src="components/com_kaltura/assets/sold.png" alt="sold" />
                                <?php } ?>
                            <? } else { $syncstatus = false; ?>
                                <img src="components/com_kaltura/assets/warn.png" alt="undefined" />
                            <?php } ?>
                        </div>
                    </td>
                    <?php endif; ?>
                    
                    <td>
                        <a href="<?php echo $delete_link; ?>">
			                <img src="components/com_kaltura/assets/delete.png" 
			                     alt="<?php echo JText::_('KALTURA_DELETE'); ?>" />
			            </a>
                    </td>
                    <td class="order">
                        <span><?php echo $this->pagination->orderUpIcon( $i, ($i > 0), 'orderup', 'Move Up'); ?></span>
	                    <span><?php echo $this->pagination->orderDownIcon( $i, $n, ($i < $n ), 'orderdown', 'Move Down'); ?></span>
	                    <input type="text" name="order[]" size="5" 
	                           value="<?php echo $entry->priority; ?>" 
	                           class="text_area" style="text-align: center" />
                    </td>
                    
                </tr>
            <?php $k = 1 - $k; } ?>
        </tbody>
    </table>
</div>

    <input type="hidden" name="option" value="com_kaltura" />
    <input type="hidden" name="task" value="showcontent" />
    <input type="hidden" name="boxchecked" value="0" />
    <input type="hidden" name="controller" value="contentselector" />
    <input type="hidden" id="iid" name="iid" value="<?php echo JRequest::getVar('iid'); ?>" />
    <input type="hidden" name="syncstatus" id="syncstatus" value="<?php echo $syncstatus; ?>" />
</form>
<?php
function neat_trim($str, $n, $delim='...') {
   $len = strlen($str);
   if ($len > $n) {
       preg_match('/(.{' . $n . '}.*?)\b/', $str, $matches);
       return rtrim($matches[1]) . $delim;
   }
   else {
       return $str;
   }
}

?>
