<?php
// import JFile
   jimport('joomla.filesystem.file');
   // import JFolder
   jimport('joomla.filesystem.folder');
   // import JPath
   jimport('joomla.filesystem.path');


	
	$errors = array();
	$path = JPATH_ROOT."/tmp/";
	if(!JFolder::exists($path)):
		$errors[] =  "The Folder ".$path." doesn't exists";
	endif;
	
	if(!JFile::exists($path.'index.html')):
		$errors[] =  "The File index.html inside ".$path." doesn't exists";
	endif;



if(count($errors)==0):

	$date =& JFactory::getDate();
	$name_file = 'catalogue_export.csv';



	$MyOpFile = getData($this->data,$this->fieldshow);

	$fh = fopen($path.$name_file, 'w') or die("can't open ".$name_file." file");
	foreach($MyOpFile as $o=>$p){
		fwrite($fh, $p."\n");
	}
	fclose($fh);

	
	// Send file headers
        header("Content-type: text/csv");
        header("Content-Disposition: attachment;filename=".$name_file);
	
	
	  // Send the file contents.
        readfile($path.$name_file);


else:

	foreach ($errors as $error):
		echo '<div class="error">'.$error.'</div>';
	endforeach;

endif;







function getData($datas,$fieldshow) {
		
		$MyOpList = array();
		$MyOpList[0] = '"Title","Partner"';
		
		//Add fields to the header
		$fieldsorder = array();
		if(is_array($fieldshow)):
		foreach ($datas['fields_final'] as $keyfn => $fn):
			if(in_array($fn['field_id'],$fieldshow)):	
				$fieldsorder[] = $fn['field_id'];
				$MyOpList[0] = $MyOpList[0].',"'.$fn['field_label'].'"';
			endif;		
		endforeach;
		endif;
		
		$MyOpList[0] = $MyOpList[0].',"Synopsis"';
		$MyOpList[0] = strtoupper($MyOpList[0]);
		
		//====----
		foreach($datas['programmes'] as $key=>$data){
			//Try to offer a forename/surname split
		
			//Build the OP string
			$ThisRow = '"'.san($data['kentry_name']).'","'.san($data['instance_name']).'"';
			
			

			
			foreach($fieldsorder as $keyor=>$fieldor):
				
				$flag=0;
				foreach ( $data['fields'] as $kv=> $fv):
					
					if($fv['field_id']==$fieldor):
						$ThisRow .= ',"'.san($fv['field_value']).'"';
						$flag=1;
					endif;

				endforeach;
					if($flag==0)
						$ThisRow .= ',""';
			
			endforeach;
			

			$ThisRow = $ThisRow.',"'.san($data['kentry_description']).'"';
			
			array_push($MyOpList,$ThisRow);
		}		
		return $MyOpList;
}


function san($string){

	$sanitize = str_replace("\"", "-", $string);	
	return $sanitize;
}

?>