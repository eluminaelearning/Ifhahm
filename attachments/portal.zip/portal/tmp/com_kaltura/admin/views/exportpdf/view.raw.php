<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.view');

class KalturaViewExportpdf extends JView {


    function display() {  
    

    
    
	$fieldshow = JRequest::getVar('fieldshow', '', 'POST');
	$partners = JRequest::getVar('partners', '', 'POST');
	$fields = JRequest::getVar('fields');
	$added = JRequest::getVar('added');
	$deleted = JRequest::getVar('deleted');
	$orderfilter = JRequest::getVar('orderfilter', '', 'POST');
	$type = JRequest::getVar('type', '', 'POST');

	
	if(is_array($fieldshow))
	$fieldshow_string = implode(",", $fieldshow);


	$all = 1;
	foreach ($fields as $key=>$field):
		if($field[0]!='all'):
		//there are filters
		$all = 0;
		
		endif;
	endforeach;



	$db =& JFactory::getDBO();

	// format partners
	$partner2 = array();
	foreach ($partners as $p):
		$query = "SELECT userid FROM #__Kaltura_instances WHERE id =".$p;
		$db->setQuery($query);
		$result = $db->loadResult();
		$partner2[] = $result;
	endforeach;
	$partner3 = join(',',$partner2);  
	
	
	//INSTANCE FILTER
	$db =& JFactory::getDBO();
	$query  = 'SELECT entry.*, instance.instance_name, instance.kalturaurl,instance.instance_name FROM `#__Kaltura_entry_cdata` entry';
	$query .= ' INNER JOIN `#__Kaltura_instances` instance ON instance.userid = entry.kentry_partner_id';	
	$query .= ' WHERE entry.kentry_partner_id IN ('.$partner3.')';
	
	if(count($deleted)>0):
	foreach ($deleted as $d):
		$query .= ' AND entry.id <> '.$d;
	endforeach;
	endif;
	
	$db->setQuery($query);
	$results = $db->loadAssocList();
	
	
	
	//Get Add fields for single programme
	foreach ($results as $key=>$r):
		if($all==1):
			$results[$key]['add'] = 1;
		else:
			$results[$key]['add'] = 0;
		endif;
		
		if($all==0):
		foreach ($fields as $keyfield=>$field):
			$query  = 'SELECT f.id as field_id, f.field_name, fv.id as value_id,fv.field_value, v.value as value_text FROM `#__Kaltura_entry_field_value` v';
			$query .= ' INNER JOIN `#__Kaltura_fields` f ON v.field_id = f.id';
			$query .= ' INNER JOIN `#__Kaltura_fields_values` fv';
			$query .= ' WHERE v.kentry_id = "'.$r['kentry_id'].'"';
			$query .= ' AND fv.field_value = v.value';
			$db->setQuery($query);
			
			$fieldsresult = $db->loadAssocList();

			foreach ($fieldsresult as $fr):
				if(in_array($fr['value_id'],$fields[$fr['field_id']])):
					//$results[$key]['fields'] = $fieldsresult;
					$results[$key]['add'] = 1;
				
				elseif($fields[$fr['field_id']][0]=='all'):
					
				else:
					$results[$key]['add'] = 0;
					unset($results[$key]['fields']);
				
					break; 

				endif;
			endforeach;

		endforeach;
		endif; //all = 0
		
		
	endforeach;

	if($all==1):
		$results_final = $results;
	else:
		foreach($results as $key=>$value):
			if($value['add']==1):
				$results_final[] = $value;
				unset($results_final[$key]['add']); 			
			endif;
		endforeach;
	endif;
	
	
	//Get ADD records
	if(count($added)>0):
		$added_join = join(',',$added);  
		$query  = 'SELECT c.*, ins.kalturaurl,ins.instance_name FROM `#__Kaltura_entry_cdata` c';
		$query .= ' INNER JOIN `#__Kaltura_instances` ins ON ins.userid = c.kentry_partner_id';
		$query .= ' WHERE c.id IN ('.$added_join.')';
		$db->setQuery($query);
		$rec_added = $db->loadAssocList();
		
		if(count($results_final)>0):
			$results_final = array_merge($results_final, $rec_added);
		else:
			$results_final = $rec_added;
		endif;
		
	endif;	
		
			


	
	//Get fields from filtered results
	foreach ($results_final as $key=>$r):

		foreach ($fields as $keyfield=>$field):
			$query  = 'SELECT f.id as field_id, f.field_name, fv.id as value_id,fv.field_value, v.value as value_text  FROM `#__Kaltura_entry_field_value` v';
			
			$query .= ' INNER JOIN `#__Kaltura_fields` f ON v.field_id = f.id';
			$query .= ' INNER JOIN `#__Kaltura_fields_values` fv';
			$query .= ' WHERE v.kentry_id = "'.$r['kentry_id'].'"';
			$query .= ' AND fv.field_value = v.value';
			$db->setQuery($query);
			
			$fieldsresult = $db->loadAssocList();
			$results_final[$key]['fields'] = $fieldsresult;

		endforeach;

	endforeach;
	

$fields_final = array();
$i = 0;
foreach ($fields as $keyfield=>$field):
	$query = 'SELECT * FROM `#__Kaltura_fields` WHERE id ='.$keyfield;
	$db->setQuery($query);
	$fieldsresult = $db->loadAssoc();

	$fields_final[$keyfield]['field_label'] = $fieldsresult['field_label'];
	$fields_final[$keyfield]['field_name'] = $fieldsresult['field_name'];
	$fields_final[$keyfield]['field_id'] = $keyfield;
$i++;	
endforeach;




	//FIRST ORDER
	foreach ($results_final as $key => $row):
	
		$query  = 'SELECT value FROM `#__Kaltura_entry_field_value`';
		$query .=  ' WHERE kentry_id = "'.$row['kentry_id'].'"';
		$query .=  ' AND field_id = '.$orderfilter;
		$db->setQuery($query);			
		$first_order = $db->loadResult();
		$results_final[$key]['firstorder'] = $first_order;
	
	endforeach;
	foreach ($results_final as $key => $row) {
	    $dates[$key]  = $row['firstorder']; 
	}
	array_multisort($dates, SORT_DESC, $results_final);



// Send
$data = array();
$data['name'] = JRequest::getVar('name', '', 'POST');
$data['contactname'] = JRequest::getVar('contactname', '', 'POST');
$data['contactdetails'] = JRequest::getVar('contactdetails', '', 'POST');
$data['fields_final'] = $fields_final;
$data['programmes'] = $results_final;
$data['showthumb'] = JRequest::getVar('showthumb', '', 'POST');
 


    
    $this->assignRef('data', $data);
    $this->assignRef('fieldshow', $fieldshow);
    
       
        	
        if($type=='csv'):
        	parent::display('csv');
        else:
        	parent::display();
        endif;
        
        
    }
}
?>
