<?php ob_start(); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<style>
@page { margin: 0in 0in 0in 0in;} 
body{
	font-family: Helvetica, sans-serif;
}
#header{
	width: 100%;
	background: #254787;
	color: #fff;
	height: 100px;
	margin-bottom: 15px;
}
#header .logo{
	width: 200px;
	height: 90px;
	position: absolute;
	left:20px;
	top:5px;
}
#header h1{
	font-size: 20px;
	margin-right: 20px;
	margin-bottom: 0px;
	margin-top: 5px;
	position: absolute;
	right:10px;
	top:10px;

	text-align: right;
}
div.contactinfo{
	text-align: right;
	position: absolute;
	right:10px;
	top:45px;
	margin-right: 20px;
	line-height: 150%;
	font-size: 12px;
	font-weight: normal;
}
div.contactinfo strong{
	color: #8FAEE8;
	font-size: 1.4em;
}

div.content_inner{
	padding: 20px;
}
#content {
  margin-bottom:20px;
  height: 305px;
  background-color: #f4f4f4;
  width: 100%;
}
div.prog_image{
	float: left;
}
span.titprog{

	font-weight: bold;
	font-size: 20px;
	color: #254787;
}
div.prog_desc{
	font-size: 12px;
	margin-top: 10px;
	line-height: 145%;

}
table.tableitems td{
	vertical-align: top;
}
div.clear{
	clear: both;
}
td.filters{
	border-left: 1px dotted #ccc;
	color: #222;
	width: 240px;
	padding-left: 18px;
}
td.middle{

	padding-right: 20px;
	width: 400px;
}
td.image{
	width: 200px;
}
tr.field{
	margin-bottom: 10px;
	margin-left: 10px;
	margin-top: 10px;
	text-transform: uppercase;
	font-size: 12px;
	font-weight: bold;
}
td.field_value{
	text-transform:none;
}
span.filters_table{
	margin-left: 20px;
	margin-top: 15px;
	text-transform: uppercase;
	font-size: 12px;
	font-weight: bold;
}
td.field_name{
	text-align: left;
	padding-right: 5px;
}
span.linea{
	display: block;
	margin-right: 15px;
	margin-bottom: 10px;
	text-align: left;


}
span.line_filt{
	font-weight: normal;
	color: #555;
}
span.rownew{
	
	display: block;
}
img.itemimg{
	padding: 3px;
	border: 1px solid #f4f4f4;
	background: #fff;
}

</style>
</head>
<body>
	<div class="main_cover">
	
	</div>
<?php

	
	function neat_trim($str, $n, $delim='...') {
	   $len = strlen($str);
	   if ($len > $n) {
	       preg_match('/(.{' . $n . '}.*?)\b/', $str, $matches);
	       return rtrim($matches[1]) . $delim;
	   }
	   else {
	       return $str;
	   }
	}

	
	
	$data = $this->data;
	
	$name = $data['name'];
	$contactname = $data['contactname'];
	$contactdetails = $data['contactdetails'];
	$fields_final = $data['fields_final'];
	$showthumb = $data['showthumb'];

	$url = JURI::root();
	
	
	
?>
	<?php 
	
	foreach ($data['programmes'] as $key=>$prog):





	if ($key % 2 == 0):
		$divisiblebytwo = 1;
	else:
		$divisiblebytwo = 0;
	endif;
	
if($showthumb==1):

	if (@GetImageSize($prog['kalturaurl']."/p/100/sp/10000/thumbnail/entry_id/".$prog['kentry_id']."/width/220/height/130/bgcolor/000000/type/2")) {
		$default_image = $prog['kalturaurl']."/p/100/sp/10000/thumbnail/entry_id/".$prog['kentry_id']."/width/220/height/130/bgcolor/000000/type/2";
	} else {
		$url = JURI::root();
		$path_image = $url.'components/com_kaltura/assets/images/default_thumb1.png';
		$default_image =$path_image;
	}
else:
	
		$url = JURI::root();
		$path_image = $url.'components/com_kaltura/assets/images/default_thumb1.png';
		$default_image =$path_image;
	
endif;		



	?>
	
	<?php if($divisiblebytwo==1): ?>
		<div id="header">
			<div class="logo">
			
				
				
				</div>
			<h1><?php echo $name;?></h1>
			<div class="contactinfo">
				<strong><?php echo $contactname;?></strong><br /><?php echo $contactdetails;?>
			</div>
		</div>
	<?php endif; ?>

	<div id="content <?php if($divisiblebytwo==1): echo "first"; else: echo "second"; endif;?>">
		<div class="content_inner">
		

			
		
		
<table width="100%" border="0" class="tableitems">
  <tr>
    <td class="image">
		<div class="prog_image"><img src="<?php echo $default_image;?>" width="200" class="itemimg"/></div>		
    </td>
    
    <td class="middle">
    	<span class="titprog"><?php echo $prog['kentry_name'];?></span><br />
    	<div class="prog_desc"><?php echo neat_trim($prog['kentry_description'],940);?></div>
    </td>
    
    <td class="filters">
    	
    	<span class="filters_table">
		
    	<?php 
    	$a=1;
    	
    	if(is_array($this->fieldshow)):
    	foreach ($fields_final as $kf=>$field): 
    	
    	if(in_array($field['field_id'],$this->fieldshow)):
    	?>

			<?php //if ($a < (count($fields_final)/2)): ?>
    		<span class="linea">

    		
    		<?php echo $field['field_label'];?> 
	
    		<?php
    		foreach ($prog['fields'] as $prog_fields):
					if($prog_fields['field_id'] == $kf):
						echo $value[$kf] = '<span class="line_filt">: '.$prog_fields['value_text'].'</span>';
						
					else:
						
					endif;
					endforeach;
			?>	
			</span>
		<?php
		$a++;
		 endif;
		 endforeach;
		 endif;
		  ?>	
    	
    	</span>
    	
    </td>
    
  </tr>
 

  
</table>
				
				


		</div>
	
	</div>
	
	<div class="clear"></div>
	<?php endforeach;?>

	
	
</body>
</html>


<?php   
$date =& JFactory::getDate();
$name_file = 'catalogue_'.$date->toFormat('%d_%m_%Y_%I_%M_%S');

 $htmlexport = ob_get_clean(); ?>




<?php

	require_once (JPATH_COMPONENT_ADMINISTRATOR.DS.'helpers'.DS.'dompdf'.DS.'dompdf_config.inc.php'); 	
    	$dompdf = new DOMPDF();
    	$dompdf->load_html($htmlexport);
    	$dompdf->set_paper('a4', 'landscape');
    	$dompdf->render();
    	$dompdf->stream($name_file.'.pdf');

?>