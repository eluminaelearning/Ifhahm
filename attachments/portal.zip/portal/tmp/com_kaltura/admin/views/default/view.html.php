<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.view');

class KalturaViewDefault extends JView {
    function display($tpl=null) {
        JToolBarHelper::title(JText::_('KALTURA_TITLE'),'mainlogo');
        $this->addToolBar();
        $menu_entries = array();
        $menu_entries[] = $this->_setMenuEntry(JText::_('KALTURA_INSTANCES'),
                                               'instances',
                                               'components/com_kaltura/assets/instances.png');
        $menu_entries[] = $this->_setMenuEntry(JText::_('KALTURA_CONTENT_EDITOR'),
                                               'contentselector',
                                               'components/com_kaltura/assets/contenteditor.png');
        $menu_entries[] = $this->_setMenuEntry(JText::_('KALTURA_NOTES'),
                                               'notes',
                                               'components/com_kaltura/assets/notes.png');
                                                                                      
        $menu_entries[] = $this->_setMenuEntry(JText::_('KALTURA_CUSTOM_FIELDS'),
                                               'fieldsmanager',
                                               'components/com_kaltura/assets/fieldsmanager.png');
        $menu_entries[] = $this->_setMenuEntry(JText::_('KALTURA_EXPORTTOOL'),
                                               'exporttool',
                                               'components/com_kaltura/assets/task.png');
        $menu_entries[] = $this->_setMenuEntry(JText::_('KALTURA_VALIDATEINSTALLATION'),
                                               'validate',
                                               'components/com_kaltura/assets/validate.png');                                       
                                               
        $this->assignRef('menu_entries', $menu_entries);
        
        parent::display($tpl);
    }
    
    function _setMenuEntry($name, $task, $icon=null) {
        $entry = array();
        
        $entry['name'] = $name;
        $entry['task'] = $task;
        $entry['icon'] = $icon;
        
        return $entry;
    }
    protected function addToolBar() 
	{

		JToolBarHelper::preferences('com_kaltura');
	}
}
