<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');
?>
<form action="index.php" method="post" name="adminForm" id="adminForm">
    <div id="col100" class="select_it" style="float:none;">
<h2><?php echo JText::_('KALTURA_NOTE_DATA'); ?></h2>
        <table cellspacing="0" cellpading="0" border="0" width="100%">
            <tr>
                <td valign="top">
                    <fieldset class="adminForm tablenoteedit">
                          <legend for="note_content">
                                            <?php echo JText::_('KALTURA_CONTENT_LIST'); ?>
                                        </legend>
                        <table class="adminForm">
                            <tbody>
                                <tr>
                                    <td width="100" align="right" class="key">
                                        <legend for="note_title">
                                            <?php echo JText::_('KALTURA_NOTE_TITLE'); ?>
                                        </legend>
                                    </td>
                                    <td>
                                        <input class="inputnote" class="inputnote" type="text" name="note_title" id="note_title" 
                                               value="<?php echo $this->note->note_title; ?>" />
                                    </td>
                                </tr>
                                <tr>
                                    <td width="100" align="right" class="key">
                                        <legend for="note_contact">
                                            <?php echo JText::_('KALTURA_NOTE_CONTACT'); ?>
                                        </legend>
                                    </td>
                                    <td>
                                        <input class="inputnote" type="text" name="note_contact" id="note_contact"
                                               value="<?php echo $this->note->note_contact; ?>" />
                                    </td>
                                </tr>
                                <tr>
                                    <td width="100" align="right" class="key">
                                        <legend for="note_phone">
                                            <?php echo JText::_('KALTURA_NOTE_PHONE'); ?>
                                        </legend>
                                    </td>
                                    <td>
                                        <input class="inputnote" type="text" name="note_phone" id="note_phone"
                                               value="<?php echo $this->note->note_phone; ?>" />
                                    </td>
                                </tr>
                                <tr>
                                    <td width="100" align="right" class="key">
                                        <legend for="note_email">
                                            <?php echo JText::_('KALTURA_NOTE_EMAIL'); ?>
                                        </legend>
                                    </td>
                                    <td>
                                        <input class="inputnote" type="text" name="note_email" id="note_email"
                                               value="<?php echo $this->note->note_email; ?>" />
                                    </td>
                                </tr>
       
                                <tr>
                                    <td width="100" align="right" class="key">
                                        <legend for="note_time">
                                            <?php echo JText::_('KALTURA_DATE'); ?>
                                        </legend>
                                    </td>
                                    <td class="inputtd">
                                        <?php echo JHTML::calendar($this->note->note_time, 
                                                                   'note_time', 'note_time'); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="100" align="right" class="key">
                                        <legend for="note_meeting_place">
                                            <?php echo JText::_('KALTURA_MEETING_PLACE'); ?>
                                        </legend>
                                    </td>
                                    <td>
                                        <input class="inputnote" type="text" name="note_meeting_place"
                                               id="note_meeting_place"
                                               value="<?php echo $this->note->note_meeting_place; ?>" />
                                    </td>    
                                </tr>
                                <tr>
                                    <td width="100" align="right" class="key">
                                        <legend for="note_sold_status">
                                            <?php echo JText::_('KALTURA_SOLD_STATUS'); ?>
                                        </legend>
                                    </td>
                                    <td>
                                        <select class="inputnote" name="note_sold_status"
                                                id="note_sold_status">
                                            <option value="0" <?php 
                                            echo ((JRequest::getVar('note_sold_status')==0)?'selected="selected"':""); ?>>
                                                <?php echo JText::_('KALTURA_UNSOLD'); ?>
                                            </option>
                                            <option value="1" <?php 
                                            echo ((JRequest::getVar('note_sold_status')==1)?'selected="selected"':""); ?>>
                                                <?php echo JText::_('KALTURA_PROCESS'); ?>
                                            </option>
                                            <option value="2" <?php 
                                            echo ((JRequest::getVar('note_sold_status')==2)?'selected="selected"':""); ?>>
                                                <?php echo JText::_('KALTURA_SOLD'); ?>
                                            </option>
                                        </select>
                                    </td>
                                </tr>
                                                           </tbody>
                        </table>
                    </fieldset>
                    
                    <fieldset class="desc_notes_ed">
                    
                                        <legend for="note_content">
                                            <?php echo JText::_('KALTURA_CONTENT'); ?>
                                        </legend>
                    
                                      
										<?php
											$editor =& JFactory::getEditor();
											$params = array('smilies' => '0',
													        'style' => '1',
													        'layer' => '0',
													        'table' => '0',
													        'clear_entities' => '0');
											echo $editor->display('note_content', 
											                      $this->note->note_content, 
											                      '600', '235', '40', '20', 
											                      false, $params);
										?>
								
                    </fieldset>
                    
                </td></tr>
                <tr><td>
                    <fieldset class="adminForm">
                        <div class="filterArea">
                            <div class="filterfield">
                                <label for="search"><?php echo JText::_('KALTURA_SEARCH'); ?></label>
                                <input type="text" name="search" id="search" 
                                       value="<?php echo JRequest::getVar('search'); ?>" />
                            </div>
                            <div class="filterfield">
                                <label for="partner"><?php echo JText::_('KALTURA_PUBLISHER'); ?></label>
                                <select name="partner" id="partner">
                                    <?php foreach ($this->instances as $instance) { ?>
                                        <option value="<?php echo $instance->userid; ?>"
                                                <?php if ($instance->userid==$this->partnerid) {
                                                          echo 'selected="selected"';
                                                          $iid = $instance->id;
                                                      } else echo ''; 
                                                ?>>
                                            <?php echo $instance->instance_name; ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>
                            <?php foreach ($this->ffields as $field) { ?>
                            <div class="filterfield">
                                <label for="<?php echo $field->field_name; ?>">
                                    <?php echo $field->field_label; ?>
                                </label>
                                <?php if ($field->field_type == 0) { ?>
                                    <input type="text" name="<?php echo $field->field_name; ?>"
                                           id="<?php echo $field->field_name; ?>" value="" />
                                <?php } else { ?>
                                    <select name="<?php echo $field->field_name; ?>" 
                                            id="<?php echo $field->field_name; ?>">
                                        <?php
                                            $field_values = 
                                                $this->fields_model->getFieldItems($field->id); ?>
                                                <option value="">
                                                    <?php echo JText::_('KALTURA_ALL'); ?>
                                                </option>
                                            <?php foreach ($field_values as $value) { ?>
                                                <option value="<?php echo $value->field_value; ?>"
                                                    <?php echo (($value->id==$this->partnerid)?'selected="selected"':''); ?>>
                                                    <?php echo $value->field_value; ?>
                                                </option>
                                            <?php }
                                        ?>
                                    </select>
                                <?php } ?>
                                </div>
                            <?php } ?>
                            <button id="fixsubmit"><?php echo JText::_('SUBMIT'); ?></button>
                        </div>
                      
                        <div class="editcell notesedit">
                            <table class="adminlist">
                                <thead>
                                    <tr>
                                        <th width="20">
                                            <input type="checkbox" name="toggle" value="" id="checkall" />
                                        </th>
                                        <th width="400">
                                            <?php echo JText::_('KALTURA_ENTRY_TITLE'); ?>
                                        </th>
                                        <th width="20">
                                            <?php echo JText::_('KALTURA_SOLD_STATUS'); ?>
                                        </th>
                                        <?php foreach($this->fields as $field) { ?>
                                            <th>
                                                <?php echo $field->field_label; ?>
                                            </th>
                                        <?php } ?>
                                    </tr>
                                </thead>
                                <tfoot><tr>
                                    <td colspan="<?php echo (3+count($this->fields)); ?>">
                                        <?php echo $this->pagination->getListFooter() ?>
                                    </td>
                                </tr></tfoot>
                                <tbody>
                                    <?php 
                                    $k = 0;
                                    $i = 0;
                                    foreach ($this->data as $entry) { ?>
                                        <tr>
                                            <td>
                                                <input type="checkbox" class="checkbox" 
                                                       id="c<?php echo $entry->id; ?>" />
                                            </td>
                                            <td>
                                                <?php echo $entry->kentry_name; ?>
                                            </td>
                                            <td>
                                                <div class="togglesoldstatus" 
                                                     title="toggle_<?php echo JText::_('TOGGLE_SOLD_STATUS'); ?>" 
                                                     id="sold_status_<?php echo $entry->id; ?>">
                                                    <?php if (isset($entry->kentry_sold_status)) { ?>
                                                        <?php if ($entry->kentry_sold_status == 0) { ?>
                                                            <img src="components/com_kaltura/assets/unsold.png" 
                                                                 alt="unsold" />
                                                        <?php } else if ($entry->kentry_sold_status == 1) { ?>
                                                            <img src="components/com_kaltura/assets/soldprocess.png" 
                                                                 alt="soldprocess" />
                                                        <?php } else { ?>
                                                            <img src="components/com_kaltura/assets/sold.png" 
                                                                 alt="sold" />
                                                        <?php } ?>
                                                    <? } else { ?>
                                                        <img src="components/com_kaltura/assets/warn.png" 
                                                             alt="undefined" />
                                                    <?php } ?>
                                                </div>
                                            </td>
                                            <?php foreach($this->fields as $field) { 
                                                $val = $this->entries_model->getFieldValue($entry->kentry_id, $field->id); ?>
                                                <td>
                                                    <?php echo (($val)?$val->value:""); ?>
                                                </td>
                                            <?php } ?>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="legend">
                        <div class="legend_items">
                        	<img src="components/com_kaltura/assets/unsold.png" alt="unsold">
                        	<?php echo JText::_('KALTURA_UNSOLD'); ?>
                        </div>
                        <div class="legend_items">
                        <img src="components/com_kaltura/assets/soldprocess.png" alt="soldprocess">
                        <?php echo JText::_('KALTURA_PROCESS'); ?>
                        </div>
                        
                        
                        <div class="legend_items">
                        <img src="components/com_kaltura/assets/sold.png" alt="sold">
                        <?php echo JText::_('KALTURA_SOLD'); ?>
                        </div>
                        
                        
                        </div>
                    </fieldset>
                </td>
            </tr>
        </table>
    </div>
    
    <input type="hidden" name="controller" id="controller" value="notes" />
    <input type="hidden" name="option" id="option" value="com_kaltura" />
    <input type="hidden" name="view" id="view" value="editnote" />
    <input type="hidden" name="task" id="task" value="editnote" />
    <input type="hidden" name="iid" id="iid" value="<?php echo $iid; ?>" />
    
    <input type="hidden" name="idlist" id="idlist" value="<?php echo $this->idlist; ?>" />
    
    <input type="hidden" name="note_id" id="note_id" value="<?php echo $this->note->note_id; ?>" />
</form>
  <div class="clear"></div>