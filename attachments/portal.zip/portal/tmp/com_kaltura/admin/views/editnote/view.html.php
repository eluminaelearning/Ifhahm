<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.view');

class KalturaViewEditnote extends JView
{
    function display($tpl=null) {
        $document =& JFactory::getDocument();
        $document->addScript('components'.DS.'com_kaltura'.DS.'assets'.DS.'notes.js');
    
        JToolBarHelper::title(JText::_('KALTURA_EDIT_NOTE'),'mainlogo');
        JToolBarHelper::save();
        JToolBarHelper::back(JText::_('BACK'), 'index.php?option=com_kaltura&task=notes');
        
        
        $model = $this->getModel();
        $fields_model = $this->getModel('fields');
        $entries_model = $this->getModel('localentries');
        $partners_model = $this->getModel('instances');
        
        $pagination = $entries_model->getPagination();
        $fields = $fields_model->getFields();
        $ffields = $fields_model->getFiltrableFields(true);
        $instances = $partners_model->getInstances();
        
        $cid = JRequest::getVar('cid');
        $model->setId($cid[0]);
        $note = $model->getNote();
        
        $partner_id = JRequest::getVar('partner');
        if (!$partner_id) $partner_id = $instances[0]->userid;
        
        if (JRequest::getVar('fromlist') && $note->note_id) {
            $entry_ids = $model->getRelatedEntries($note->note_id);
            $idlist = "";
            foreach ($entry_ids as $entry_id) {
                if ($idlist == "") $idlist .= $entry_id;
                else $idlist .= ",".$entry_id;
            }
        } else $idlist = JRequest::getVar('idlist');
        
        $entries_model->setPartnerId($partner_id);
        if (JRequest::getVar('search'))
            $entries_model->setSearch(JRequest::getVar('search'));
        foreach ($ffields as $filter) {
            if (JRequest::getVar($filter->field_name))
                $entries_model->setFilterField(JRequest::getVar($filter->field_name),
                                                                $filter->field_name);
        }
        $data = $entries_model->getData();
        
        $this->_initForm($note, $search);
    
        $this->assignRef('note', $note);
        $this->assignRef('pagination', $pagination);
        $this->assignRef('data', $data);
        $this->assignRef('fields', $fields);
        $this->assignRef('ffields', $ffields);
        $this->assignRef('instances', $instances);
        $this->assignRef('partnerid', $partner_id);
        $this->assignRef('fields_model', $fields_model);
        $this->assignRef('entries_model', $entries_model);
        $this->assignRef('idlist', $idlist);
    
        parent::display($tpl);
    }
    
    function _initForm($note, &$search) {
        if (JRequest::getVar('note_title'))
            $note->note_title = JRequest::getVar('note_title');
        if (JRequest::getVar('note_contact'))
            $note->note_contact = JRequest::getVar('note_contact');
        if (JRequest::getVar('note_phone'))
            $note->note_phone = JRequest::getVar('note_phone');
        if (JRequest::getVar('note_email'))
            $note->note_email = JRequest::getVar('note_email');
        if (JRequest::getVar('note_genre'))
            $note->note_genre = JRequest::getVar('note_genre');
        if (JRequest::getVar('note_time'))
            $note->note_time = JRequest::getVar('note_time');
        if (JRequest::getVar('note_meeting_place'))
            $note->note_meeting_place = JRequest::getVar('note_meeting_place');
        if (JRequest::getVar('note_content'))
            $note->note_content = JRequest::getVar('note_content');
    }
}
?>
