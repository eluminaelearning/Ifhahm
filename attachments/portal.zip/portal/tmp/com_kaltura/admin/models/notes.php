<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.model');
class KalturaModelNotes extends JModel
{
    var $_note;
    var $_data;
    var $_id;
    
    var $_pagination = null;
    var $_total = null;
    
    var $_query;
    
    function __construct() {
        parent::__construct();
        $mainframe = JFactory::getApplication();
        
        $limit = $mainframe->getUserStateFromRequest('global.list.limit',
            $mainframe->getCfg('list_limit'), 'int');
        $limitstart = JRequest::getVar('limitstart', 0, '', 'int');
        $limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
        $this->setState('limit', $limit);
        $this->setState('limitstart', $limitstart);
    }
    
    function setId($id) {
        $this->_id = $id;
        $this->_data = null;
        $this->_note = null;
    }
    
    function _buildQuery() {
        $query = 'select * from #__Kaltura_notes';
        $this->_query = $query;
        return $this->_query;
    }
    
    function getPagination() {
        if (empty($this->_pagination)) {
            jimport('joomla.html.pagination');
            $this->_pagination =
                new JPagination($this->getTotal(),
                                $this->getState('limitstart'),
                                $this->getState('limit'));
        }
        return $this->_pagination;
    }
    
    function getData() {
        $this->_buildQuery();
        
        if (empty($this->_data)) {
            $this->_data = 
                $this->_getList($this->_query, $this->getState('limitstart'),
                                $this->getState('limit'));
        }
        return $this->_data;
    }
    
    function getTotal() {
        $this->_buildQuery();
        if (empty($this->_total)) {
            $this->_total = $this->_getListCount($this->_query);
        }
        return $this->_total;
    }
    
    function delete($cid) {
        if (!$cid) return false;
        else {
            $table = $this->getTable();
            if (!$table->delete($cid)) return false;
            return true;
        }
    }
    
    function &getNote() {
        if ($this->_loadNote()) {
        } else $this->_initNote();
        
        return $this->_note;
    }
    
    function _loadNote() {
        if (empty($this->_note)) {
            $query = 'select * from #__Kaltura_notes where note_id='.$this->_id;
            $this->_db->setQuery($query);
            $this->_note = $this->_db->loadObject();
            
            // TODO: Relation
        }
    }
    
    function _initNote() {
        if (empty($this->_note)) {
            $note = new stdClass();
            $note->note_id = 0;
            $note->note_title = "";
            $note->note_content = "";
            $note->note_contact = "";
            $note->note_email = "";
            $note->note_phone = "";
            $note->note_time = "";
            $note->note_meeting_place = "";
            $note->note_genre = "";
            $this->_note = $note;
            return (boolean) $this->_note;
        }
        return true;
    }
    
    function store() {
        $row =& JTable::getInstance('notes', 'Table');
        
        $note_id = JRequest::getVar('note_id');
        $note_title = JRequest::getVar('note_title');
        $note_content = JRequest::getVar('note_content');
        $note_contact = JRequest::getVar('note_contact');
        $note_email = JRequest::getVar('note_email');
        $note_phone = JRequest::getVar('note_phone');
        $note_time = JRequest::getVar('note_time');
        $note_meeting_place = JRequest::getVar('note_meeting_place');
        $note_genre = JRequest::getVar('note_genre');
        
        if ($note_id) $row->set('note_id', $note_id);
        $row->set('note_title', $note_title);
        $row->set('note_content', $note_content);
        $row->set('note_contact', $note_contact);
        $row->set('note_email', $note_email);
        $row->set('note_phone', $note_phone);
        $row->set('note_time', $note_time);
        $row->set('note_meeting_place', $note_meeting_place);
        $row->set('note_genre', $note_genre);
        
        if (!$row->check()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		if (!$row->store()) {
		    echo $this->_db->getQuery();
			$this->setError($this->_db->getErrorMsg());
			return false;
		} else {
		    $entry_ids_string = JRequest::getVar('idlist');
		    $entry_ids = explode(",", $entry_ids_string);
            foreach ($entry_ids as $entry_id) {
                if (!$note_id) $note_id = $this->_db->insertid();
                $query = 'select count(*) from #__Kaltura_notes_entries where ';
                $query .= ' entry_id='.$entry_id.' and note_id='.$note_id;
                $this->_db->setQuery($query);
                $count = $this->_db->loadResult();
                if ($count == 0) {
                    $query = 'insert into #__Kaltura_notes_entries (note_id, entry_id)';
                    $query .= ' values ('.$note_id.', '.$entry_id.')';
                    $this->_db->setQuery($query);
                    $this->_db->query();
                }
                $query = 'update #__Kaltura_entry_cdata set kentry_sold_status='.
                    JRequest::getVar('note_sold_status').' where id='.$entry_id;
                $this->_db->setQuery($query);
                $this->_db->query();
            }
            $query = 'select entry_id from #__Kaltura_notes_entries where note_id='.$note_id;
            $this->_db->setQuery($query);
            $ids = $this->_db->loadResultArray();
            foreach ($ids as $local_id) {
                $found = false;
                foreach ($entry_ids as $entry_id) {
                    if ($local_id == $entry_id) {
                        $found = true;
                    }
                }
                if (!$found) {
                    $query = 'delete from #__Kaltura_notes_entries where note_id='.$note_id.' and entry_id='.$entry_id;
                    $this->_db->setQuery($query);
                    $this->_db->query();
                }
            }
        }
		return true;
    }
    
    function getRelatedEntries($note_id) {
        $query = 'select entry_id from #__Kaltura_notes_entries where note_id='.$note_id;
        $this->_db->setQuery($query);
        return $this->_db->loadResultArray();
    }
}
?>
