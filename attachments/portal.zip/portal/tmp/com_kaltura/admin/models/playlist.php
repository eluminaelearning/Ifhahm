<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');
jimport('joomla.html.pagination');

class KalturaModelPlaylist extends JModel
{
    var $_data;
    var $_pagination;
    var $_playlist;
    var $_total;
    
    var $_id;
    
    function __construct() {
        parent::__construct();
		$mainframe = JFactory::getApplication();
		$limit = $mainframe->getUserStateFromRequest('global.list.limit', 'limit', 
		    $mainframe->getCfg('list_limit'), 'int');
		$limitstart = JRequest::getVar('limitstart', 0, '', 'int');
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);
    }
    
    function setId($id) {
        $this->_id = $id;
    }
    
    function _buildQuery() {
        $this->_query = 'select * from #__Kaltura_playlist';
        return $this->_query;
    }
    
    function getPagination() {
        if (empty($this->_pagination)) {
            $this->_pagination = 
                new JPagination($this->getTotal(),
                                $this->getState('limitstart'),
                                $this->getState('limit'));
        }
        return $this->_pagination;
    }
    
    function getTotal() {
        if (empty($this->_total)) {
            $this->_buildQuery();
            $this->_total = $this->_getListCount($this->_query);
        }
        return $this->_total;
    }
    
    function getData() {
        if (empty($this->_data)) {
            $this->_buildQuery();
            $this->_data = $this->_getList($this->_query,
                                           $this->getState('limitstart'),
                                           $this->getState('limit'));
        }
        return $this->_data;
    }
    
    function delete()
    {
        if (!$this->_id) return false;
        else {
            $table = $this->_getTable();
            if (!$table->delete($this->_id)) {
                return false;
            } else return true;
        }
    }
    
    function getPlaylist() {
        if ($this->_loadPlaylist()) {
        } else $this->_initPlaylist();
        
        return $this->_playlist;
    }
    
    function _loadPlaylist() {
        $query = 'select * from #__Kaltura_playlist where id='.$this->_id;
        $this->_db->setQuery($query);
        $this->_playlist = $this->_db->loadObject();
    }
    
    function _initPlaylist() {
        if (empty($this->_playlist)) {
            $playlist = new stdClass();
            $playlist->id = 0;
            $playlist->kentry_id = null;
            $playlist->playlist_name = null;
            $playlist->playlist_plays = null;
            $playlist->playlist_description = null;
            $playlist->playlist_available_from = null;
            $playlist->playlist_publish = null;
            
            $this->_playlist = $playlist;
            return (boolean) $this->_playlist;
        }
        return true;
    }
    
    function store() {
        $row =& JTable::getInstance('playlist', 'Table');
        $id = JRequest::getVar('playlist_id');
        
    }
}
?>
