<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');
class KalturaModelExporttool extends JModel
{
    function __construct() {
        parent::__construct();
    }
    
    function getInstances() 
    {
        $query = 'SELECT * FROM #__Kaltura_instances';
        $this->_db->setQuery($query);
        return $this->_db->loadObjectList();
    }
    
    function getFields()
    {
    	$query  = 'SELECT * FROM #__Kaltura_fields WHERE field_type=1';
        $this->_db->setQuery($query);
        $fields = $this->_db->loadObjectList();
		
		$i = 0;
        foreach($fields as $f):
        	$fields[$i]->values = $this->getFieldValues($f->id);
        $i++;
        endforeach;
        
        return $fields;
        
    }
    function getLiveResults()
    {
    	$keywords = JRequest::getVar('keywords', '', 'POST');
    	$query = 'SELECT kentry_id,kentry_name,id FROM #__Kaltura_entry_cdata WHERE kentry_name LIKE "%'.$keywords.'%" ORDER BY kentry_name';
        $this->_db->setQuery($query);
        return $this->_db->loadAssocList();
    }
    
    function getFieldValues($field_id) {
        $query = 'select * from #__Kaltura_fields_values where field_id='.$field_id;
        $this->_db->setQuery($query);
        return $this->_db->loadObjectList();
    }
    

}
?>
