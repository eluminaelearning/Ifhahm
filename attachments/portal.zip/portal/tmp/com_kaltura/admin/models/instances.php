<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.model');
class KalturaModelinstances extends JModel
{
	var $_data;
	var $_pagination = null;
	var $_total = null;
	
	private static $instance = null;
	
	function __construct() {
		parent::__construct();
		$mainframe = JFactory::getApplication();
		$limit = $mainframe->getUserStateFromRequest('global.list.limit','limit',$mainframe->getCfg('list_limit'), 'int');
		$limitstart = JRequest::getVar('limitstart', 0, '', 'int');
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);
	}
	
	function setId($id) {
		$this->_id = $id;
		$this->_data = null;
	}
	function _buildQuery() {
		$query = 'SELECT * FROM #__Kaltura_instances';
		return $query;
	}
	function getPagination() {
		if (empty($this->_pagination)) {
		    jimport('joomla.html.pagination');
		    $this->_pagination = 
		        new JPagination($this->getTotal(),
  		                        $this->getState('limitstart'), 
  		                        $this->getState('limit'));
	}
		return $this->_pagination;
	}
	function getData() {
		if (empty($this->_data)) {
		    $query = $this->_buildQuery();
		    $query .= ' order by priority';
		    $this->_data = $this->_getList($query, $this->getState('limitstart'), 
		                                   $this->getState('limit'));
		}
		return $this->_data;
	}
	function getTotal() {
		if (empty($this->_total)) {
		    $query = $this->_buildQuery();
		    $this->_total = $this->_getListCount($query);
		}
		return $this->_total;
	}
	function delete($cid) {
		if (!$cid) return false;
		else {
			$query = 'SELECT userid FROM #__Kaltura_instances where id='.$cid;
			$this->_db->setQuery($query);
			$userid = $this->_db->loadResult();
			
			$query = 'DELETE from #__Kaltura_entry_cdata where kentry_partner_id ='.$userid;
            $this->_db->setQuery($query);
            $this->_db->query();
			
		   $table = $this->getTable();
		if (!$table->delete($cid)) {
		    return false;
		}
    		return true;
		}
	}
	function &getInstances()
	{
		if ($this->_loadInstances()) {
		} else $this->_initInstances();

		return $this->_instances;
	}
	
	function &getInstan() {
	    if ($this->_loadInstance()) {
		} else $this->_initInstances();

		return $this->_instances;
	}
	
	function _loadInstance()
	{
		if (empty($this->_instances))
		{
			$query = 'SELECT * FROM #__Kaltura_instances where id='.$this->_id;
			$this->_db->setQuery($query);
			$this->_instances = $this->_db->loadObject();
		}
	}

	function _loadInstances()
	{
		if (empty($this->_instances))
		{
			$query = 'SELECT * FROM #__Kaltura_instances';
			$this->_db->setQuery($query);
			$this->_instances = $this->_db->loadObjectList();
		}
	}

    function getObject() {
        $query = 'SELECT * FROM #__Kaltura_instances where id='.$this->_id;
        $this->_db->setQuery($query);
        return $this->_db->loadObject();
    }

	function _initInstances()
	{
		if (empty($this->_instances)) {
			$instances = new stdClass();
			$instances->id = 0;
			$instances->instance_name = null;
			$instances->desc = null;
			$instances->dbhost = null;
			$instances->dbuser = null;
			$instances->dbpasswd = null;
			$instances->userid = null;
			$instances->kalturaurl = null;
			$instances->secretkey = null;
			$instances->public = null;
			$this->_instances = $instances;
			return (boolean) $this->_instances;
		}
		return true;
	}
	function store() {
		$row =& JTable::getInstance('instances', 'Table');
		
		$id = JRequest::getString('instances_id');
	    $instance_name = JRequest::getString('instances_instance_name');
	    $desc = JRequest::getString('instances_desc');
	    $dbhost = JRequest::getString('instances_dbhost');
	    $dbuser = JRequest::getString('instances_dbuser');
	    $dbpasswd = JRequest::getString('instances_dbpasswd');
	    $userid = JRequest::getVar('partner_id');
	    $kalturaurl = JRequest::getVar('kaltura_url');
	    $secretkey = JRequest::getVar('secretkey');
	    $public = (JRequest::getVar('public')?1:0);

		if ($id) $row->set('id', $id);
			$row->set('instance_name', $instance_name);
			$row->set('desc', $desc);
			$row->set('dbhost', $dbhost);
			$row->set('dbuser', $dbuser);
			$row->set('dbpasswd', $dbpasswd);
			$row->set('userid', $userid);
			$row->set('kalturaurl', $kalturaurl);
			$row->set('secretkey', $secretkey);
			$row->set('public', $public);
		if (!$row->check()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		if (!$row->store()) {
		    echo $this->_db->getQuery();
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		echo $this->_db->getQuery();
	return true;
	}
	
	
}
?>
