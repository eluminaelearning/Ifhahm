<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');
class KalturaModelEntries extends JModel
{
    var $_data;
    var $_pagination;
    var $_ks;
    var $_client;
    var $_partner_id;
    
    var $_kalturapager;
    var $_kalturafilter = null;
    
    var $_instance_id;
    
    var $_fieldslist;
    var $_values;
    
    var $_edb;
    
    function __construct() 
    {
        parent::__construct();
		$mainframe = JFactory::getApplication();
		$limit = $mainframe->getUserStateFromRequest('global.list.limit','limit',$mainframe->getCfg('list_limit'), 'int');
		if($limit==0) $limit=100;
		
		$limitstart = JRequest::getVar('limitstart', 0, '', 'int');
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);
		
		$this->_kalturapager = new KalturaFilterPager();
		
		if ($limit > 0)
		    $this->_kalturapager->pageIndex = $limitstart / $limit;
	    $this->_kalturapager->pageSize = $limit;
		
		if (JRequest::getVar('freesearch')) {
		    $this->_kalturafilter = new KalturaBaseEntryFilter();
		    $this->_kalturafilter->searchTextMatchOr = 
		        JRequest::getVar('freesearch');
		}
		
		$iid = JRequest::getVar('iid');
		$query = 'select * from #__Kaltura_instances where id='.$iid;
		$this->_db->setQuery($query);
        $instance = $this->_db->loadObject();
		
		$partner_id = $instance->userid;
		$this->_partner_id = $partner_id;
		$config = new KalturaConfiguration($partner_id);
		$config->serviceUrl = $instance->kalturaurl;
		$this->_client = new KalturaClient($config);
		$secret = $instance->secretkey;
		$type = KalturaSessionType::ADMIN;
		
		$this->_ks = $this->_client->session->start($secret, null, $type, 
		                                            $partner_id, null, null);
		                                     
		$this->_client->setKs($this->_ks);
		
		$this->_instance_id = JRequest::getVar('iid');
		$this->_edb = ExternalDatabase::getDatabaseInstance($this->_instance_id);
    }
    
    function getPagination() {
		if (empty($this->_pagination)) {
		    jimport('joomla.html.pagination');
		    $this->_pagination = 
		        new JPagination($this->getTotal(),
  		                        $this->getState('limitstart'), 
  		                        $this->getState('limit'));
    	}
		return $this->_pagination;
	}
    
    function getFieldsList() {
        if (empty($this->_fieldslist)) {
            $query = 'select * from #__Kaltura_fields where field_temp=0  and field_visible=1';
            $this->_db->setQuery($query);
            $this->_fieldslist = $this->_db->loadObjectList();
        }
        return $this->_fieldslist;
    }
    
    function getFieldValues($field_id) {
        $query = 'select * from #__Kaltura_fields_values where field_id='.$field_id;
        $this->_db->setQuery($query);
        return $this->_db->loadObjectList();
    }
    
    function getTotal() {
        /*$this->getEntries();
        return $this->_data->totalCount;*/
        $query = 'select * from #__Kaltura_entry_cdata ';
        $query .= ' where kentry_status=2 and kentry_type <> 5';
        $query .= ' and kentry_partner_id='.$this->_partner_id;
        $query .= ' and kentry_name like "%'.JRequest::getVar('freesearch').'%"';
        $this->_db->setQuery($query);
        $this->_db->query();
        return $this->_db->getNumRows();
    }
    
    function getLocalEntries() {
        $query = 'select * from #__Kaltura_entry_cdata';
        $query .= ' where kentry_status <> 3 and ';
        $query .= 'kentry_visible=1';
        $this->_db->setQuery($query);
        return $this->_db->loadObject();
    }
    
    function getFilteredQuery()
    {
    //Build the query for custom filters
        if(count($this->dataCustFilter())>0):

            $filtdata = $this->dataCustFilter();

            $i = 0;
            foreach ($filtdata as $d):
                $filtdata[$i] = '"'.$d.'"';
            $i++;    
            endforeach;

            $ids = join(',',$filtdata); 
            $query = ' and a.kentry_id IN('.$ids.')';

        else:
            $query = '';
        endif;    

        return $query;

    }

    function dataCustFilter()
    {
    //Get in an array all the kentry ids that must be filtered
        $filters = $this->getAdminFiltrableFields();

        $query = 'SELECT distinct kentry_id FROM `#__Kaltura_entry_field_value`';
        $query .= 'WHERE';

        $i = 0;
        foreach ($filters as $filter) {
            $filter_val = JRequest::getVar($filter->field_name);
            if ($filter_val and ($filter_val != '')):
                if($i==0):
                    $query .= ' kentry_id IN (SELECT kentry_id FROM `#__Kaltura_entry_field_value` WHERE value = "'.$filter_val.'")';
                else:
                    $query .= ' AND kentry_id IN (SELECT kentry_id FROM `#__Kaltura_entry_field_value` WHERE value = "'.$filter_val.'")';
                endif;
            $i++;
            endif;
        }
        $this->_db->setQuery($query);
        $filtered = $this->_db->loadResultArray();

        return $filtered;

    }

    function getFilterNumber()
    {
    //Check number of filters without ALL
        $filters = $this->getAdminFiltrableFields();
        $i=0;
        foreach ($filters as $filter) {
            $filter_val = JRequest::getVar($filter->field_name);
                if ($filter_val and ($filter_val != 'ALL'))
                $i++;
        }
        return $i;
    }

    function checkDataFilters()
    {    
    //Check if there are results she using filters
        $go = true;    
        if($this->getFilterNumber()>0):
            if(count($this->dataCustFilter())==0):
                $go = false;
            endif;
        endif;

        return $go;
    }
    
    function getEntries() {
        
        $query = 'select a.* from #__Kaltura_entry_cdata a';
        $query .= ' left join #__Kaltura_entry_field_value b on a.kentry_id=b.kentry_id';
        
        $query .= ' where a.kentry_status=2 and a.kentry_type <> 5';
        $query .= ' and a.kentry_partner_id='.$this->_partner_id;
        $query .= ' and a.kentry_name like "%'.JRequest::getVar('freesearch').'%"';
        
        $query .= $this->getFilteredQuery();
        
        $query .= ' group by a.kentry_id order by a.priority';
        $query .= ' limit '.$this->getState('limitstart').', '.$this->getState('limit');
        
        $this->_db->setQuery($query);
        $this->_data = $this->_db->loadObjectList();
        
        /*foreach ($this->_data as &$entry) {
            $query = 'select * from #__Kaltura_entry_cdata ';
            $query .= 'where kentry_id="'.$entry->id.'"';
            
            $this->_db->setQuery($query);
            $obj = $this->_db->loadObject();
            
            if ($obj) {
                $entry->visible = $obj->kentry_visible;
                $entry->sold_status = $obj->kentry_sold_status;
                $entry->lid = $obj->id;
                $entry->priority = $obj->priority;
            }
        }*/
        return $this->_data;
    }
    
    function getValue($kentry_id, $field_id) {
        $query = 'select * from #__Kaltura_entry_field_value where ';
        $query .= 'kentry_id="'.$kentry_id.'" and field_id='.$field_id;
        $this->_db->setQuery($query);
        $value = $this->_db->loadObject();
        if ($value)
            return $value->value;
        else null;
    }
    
    function getValues($kentry_id) {
        $query = 'select * from #__Kaltura_entry_field_value where kentry_id="'.$kentry_id.'"';
        $this->_db->setQuery($query);
        $values = $this->_db->loadObjectList();
        
        $result = array();
        foreach($values as $val) {
            $result[$val->field_id] = $val->value;
        }
        
        return $result;
    }
    
    function setValue($kentry_id, $field_id, $value) {
        $query = 'select * from #__Kaltura_entry_field_value where ';
        $query .= 'kentry_id="'.$kentry_id.'" and field_id='.$field_id;
        
        $this->_db->setQuery($query);
        if (count($this->_db->loadObjectList()) > 0) {
            $query = 'update #__Kaltura_entry_field_value set value="'.$value.'"';
            $query .= ' where kentry_id="'.$kentry_id.'" and field_id='.$field_id;
        } else {
            $query = 'insert into #__Kaltura_entry_field_value (kentry_id, field_id, value)';
            $query .= ' values ("'.$kentry_id.'", '.$field_id.', "'.$value.'")';
        }
        $this->_db->setQuery($query);
        $this->_db->query();
        return $value;
    }
    
    function setDescription($entry_id, $value) {
        $query = 'update entry set description="'.$value.'" where id="'.$entry_id.'"';
        $edb =& ExternalDatabase::getDatabaseInstance($this->_instance_id);
        $edb->setQuery($query);
        $edb->query();
        
        $query = 'update #__Kaltura_entry_cdata ';
        $query .= 'set kentry_description="'.$value.'" ';
        $query .= 'where kentry_id="'.$entry_id.'"';
        $this->_db->setQuery($query);
        $this->_db->query();
       
        $value_new = $this->neat_trim($value, 12);
        
         return $value_new;
    }
    
    function neat_trim($str, $n, $delim='...') {
	   $len = strlen($str);
	   if ($len > $n) {
	       preg_match('/(.{' . $n . '}.*?)\b/', $str, $matches);
	       return rtrim($matches[1]) . $delim;
	   }
	   else {
	       return $str;
	   }
	}
    
    function setName($entry_id, $value) {
        $query = 'update entry set name="'.$value.'" where id="'.$entry_id.'"';
        $edb =& ExternalDatabase::getDatabaseInstance($this->_instance_id);
        $edb->setQuery($query);
        $edb->query();
        
        $query = 'update #__Kaltura_entry_cdata ';
        $query .= 'set kentry_name="'.$value.'" ';
        $query .= 'where kentry_id="'.$entry_id.'"';
        $this->_db->setQuery($query);
        $this->_db->query();
        return $value;
    }
    
    function sync($iid) {
        $edb =& ExternalDatabase::getDatabaseInstance($iid);
        
        $query = 'select * from #__Kaltura_instances where id='.$iid;
        $this->_db->setQuery($query);
        $instance = $this->_db->loadObject();
        
        // update remote data with local data
        $query = 'select * from #__Kaltura_entry_cdata';
        $this->_db->setQuery($query);
        $local_entries = $this->_db->loadObjectList();
        
        $modified = 0;
        
        // deleting entries
        foreach ($local_entries as $entry) {
            $query = 'select count(*) from entry where status=2 and type<>5 and id="'.$entry->kentry_id.'"';
            $edb->setQuery($query);
            $exists = $edb->loadResult();
            
            if (!$exists) {
                $query = 'delete from #__Kaltura_entry_cdata where kentry_id="'.$entry->kentry_id.'"';
                $this->_db->setQuery($query);
                $this->_db->query();
            }
        }
        
        // updating entries
        foreach ($local_entries as $entry) {
            $query = 'update entry set ';
            $query .= 'name="'.$entry->kentry_name.'", ';
            $query .= 'description="'.$entry->kentry_description.'", ';
            $query .= 'where id="'.$entry->kentry_id.'"';
            
            $edb->setQuery($query);
            $edb->query();
            $modified++;
        }
        
        // populate entries
        $edb->setQuery('select * from entry where status=2 and type<>5 and partner_id='.$instance->userid);
        $entries = $edb->loadObjectList();
        
        $inserted = 0;
        
        foreach ($entries as $entry) {
            $query = 'select count(*) from #__Kaltura_entry_cdata';
            $query .= ' where kentry_id="'.$entry->id.'"';
            $this->_db->setQuery($query);
            
            if ($this->_db->loadResult() == 0) {
                $query = 'insert into #__Kaltura_entry_cdata(kentry_id, ';
                $query .= 'kentry_name, kentry_type, kentry_media_type, ';
                $query .= 'kentry_data, kentry_thumbnail, kentry_views, ';
                $query .= 'kentry_votes, kentry_status, kentry_source, ';
                $query .= 'kentry_length_in_msecs, kentry_created_at, ';
                $query .= 'kentry_updated_at, kentry_partner_id, kentry_site_url, ';
                $query .= 'kentry_plays, kentry_description, kentry_media_date, ';
                $query .= 'kentry_moderation_status, kentry_moderation_count, ';
                $query .= 'kentry_modified_at, kentry_categories, ';
                $query .= 'kentry_categories_ids, kentry_start_date, ';
                $query .= 'kentry_end_date, kentry_available_from) values ("'.$entry->id.'", ';
                $query .= '"'.$entry->name.'", '.$entry->type.', '.$entry->media_type.', ';
                $query .= '"'.$entry->data.'", "'.$entry->thumbnail.'", ';
                $query .= $entry->views.', '.$entry->votes.', '.$entry->status.', ';
                $query .= '"'.$entry->source.'", '.$entry->length_in_msecs.', ';
                $query .= '"'.$entry->created_at.'", "'.$entry->updated_at.'", ';
                $query .= $entry->partner_id.', "'.$entry->site_url.'", ';
                $query .= $entry->plays.', "'.$entry->description.'", ';
                $query .= '"'.$entry->media_date.'", '.$entry->moderation_status.', ';
                $query .= $entry->moderation_count.', "'.$entry->modified_at.'", ';
                $query .= '"'.$entry->categories.'", "'.$entry->categories_ids.'", ';
                $query .= '"'.$entry->start_date.'", "'.$entry->end_date.'", ';
                $query .= '"'.$entry->available_from.'")';
                
                $this->_db->setQuery($query);
                $this->_db->query();
                $id = $this->_db->insertid();
                
                $this->_db->setQuery('select max(priority) from #__Kaltura_entry_cdata');
                $p = $this->_db->loadResult();
                
                $this->_db->setQuery('update #__Kaltura_entry_cdata set priority='.($p+1).' where id='.$id);
   
                $this->_db->query();
                
                $inserted++;
            }
        }
        
        return $modified + ($inserted*100000);
    }
    
    function toggleVisible($entry_id) {
        $query = 'select * from #__Kaltura_entry_cdata where kentry_id="'.$entry_id.'"';
        $this->_db->setQuery($query);
        $entry = $this->_db->loadObject();
        
        if ($entry) {
            if ($entry->kentry_visible == 1) {
                $query = 'update #__Kaltura_entry_cdata set kentry_visible=0 where kentry_id="'.$entry_id.'"';
            } else
                $query = 'update #__Kaltura_entry_cdata set kentry_visible=1 where kentry_id="'.$entry_id.'"';
            $this->_db->setQuery($query);
            $this->_db->query();
            return !($entry->kentry_visible);
        }
    }
    
    function toggleSoldStatus($entry_id) {
        $query = 'select * from #__Kaltura_entry_cdata where id="'.$entry_id.'"';
        $this->_db->setQuery($query);
        $entry = $this->_db->loadObject();
        
        if ($entry) {
            if ($entry->kentry_sold_status == 1) {
                $query = 'update #__Kaltura_entry_cdata set kentry_sold_status=2 where id="'.$entry_id.'"';
                $entry->kentry_sold_status = 2;
            } else if ($entry->kentry_sold_status == 2) {
                $query = 'update #__Kaltura_entry_cdata set kentry_sold_status=0 where id="'.$entry_id.'"';
                $entry->kentry_sold_status = 0;
            } else {
                $query = 'update #__Kaltura_entry_cdata set kentry_sold_status=1 where id="'.$entry_id.'"';
                $entry->kentry_sold_status = 1;
            }
            $this->_db->setQuery($query);
            $this->_db->query();
            return $entry->kentry_sold_status;
        }
        return 'zurraspa';
    }
    
    function delete($id) {
        $query = 'select kentry_id from #__Kaltura_entry_cdata where id='.$id;
        $this->_db->setQuery($query);
        $kentry_id = $this->_db->loadResult();
    
        $query = 'delete from #__Kaltura_entry_cdata where id='.$id;
        $this->_db->setQuery($query);
        $this->_db->query();
        
        $query = 'delete from #__Kaltura_entry_field_value where kentry_id='.$id;
        $this->_db->setQuery($query);
        $this->_db->query();
        
        return true;
    }
    
    function getAdminFiltrableFields() {
        $query = 'select * from #__Kaltura_fields where field_adm_filtrable=1';
        $this->_db->setQuery($query);
        return $this->_db->loadObjectList();
    }
    
    function getFilterValues($filter_id) {
        $query = 'select * from #__Kaltura_fields_values where field_id='.$filter_id;
        $query .= ' order by field_order';
        $this->_db->setQuery($query);
        return $this->_db->loadObjectList();
    }
}
?>
