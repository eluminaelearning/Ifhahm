<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');
jimport('joomla.html.pagination');
class KalturaModelLocalentries extends JModel
{
    var $_id;
    var $_partner_id;
    var $_search;
    var $_filters = array();
    
    var $_entry;
    var $_data;
    
    var $_pagination;
    var $_total;
    
    var $_query;

    function __construct() {
        parent::__construct();
        $mainframe = JFactory::getApplication();
        
        $limit = $mainframe->getUserStateFromRequest('global.list.limit',
            $mainframe->getCfg('list_limit'), 'int');
        $limitstart = JRequest::getVar('limitstart', 0, '', 'int');
        $limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
        $this->setState('limit', $limit);
        $this->setState('limitstart', $limitstart);
    }
    
    function setId($id) {
        $this->_id = $id;
    }
    
    function _buildQuery() {
        $this->_query = 'select a.* from #__Kaltura_entry_cdata a';
        $this->_query .= ' left join #__Kaltura_entry_field_value b';
        $this->_query .= ' on a.kentry_id=b.kentry_id left join ';
        $this->_query .= '#__Kaltura_fields c on c.id=b.field_id';
        return $this->_query;
    }
    
    function getPagination() {
        if (empty($this->_pagination)) {
            $this->_pagination = 
                new JPagination($this->getTotal(),
                                $this->getState('limitstart'),
                                $this->getState('limit'));
        }
        return $this->_pagination;
    }
    
    function setPartnerId($partner_id) {
        $this->_partner_id = $partner_id;
    }
    
    function setSearch($search) {
        $this->_search = $search;
    }
    
    function setFilterField($filter, $filter_name) {
        $this->_filters[] = array('filter' => $filter, 
                                  'filter_name' => $filter_name);
    }
    
    function _buildFilter() {
        $this->_query .= ' where 1=1';
        $this->_query .= ' and a.kentry_status <> 3 and a.kentry_status >= 0';
        $this->_query .= ' and a.kentry_type <> 5';
        if ($this->_partner_id) {
            $this->_query .= ' and a.kentry_partner_id='.$this->_partner_id;
        }
        if ($this->_search) {
            $this->_query .= ' and a.kentry_name like "%'.$this->_search.'%"';
        }
        foreach ($this->_filters as $filter) {
            $this->_query .= ' and c.field_name="'.$filter['filter_name'].'"';
            $this->_query .= ' and b.value="'.$filter['filter'].'"';
        }
    }
    
    function getData() {
        $this->_buildQuery();
        $this->_buildFilter();
        $this->_query .= ' group by id';
        
        if (empty($this->_data)) {
            $this->_data =
                $this->_getList($this->_query, $this->getState('limitstart'),
                                $this->getState('limit'));
        }
        return $this->_data;
    }
    
    function getTotal() {
        $this->_buildQuery();
        $this->_buildFilter();
        
        if (empty($this->_total)) {
            $this->_total = $this->_getListCount($this->_query);
        }
        return $this->_total;
    }
    
    function getFieldValue($entry_id, $field_id) {
        $query = 'select * from #__Kaltura_entry_field_value ';
        $query .= 'where kentry_id="'.$entry_id.'" and field_id='.$field_id;
        $this->_db->setQuery($query);
        return $this->_db->loadObject();
    }
}
?>
