$.noConflict();
// Code that uses other library's $ can follow here.
jQuery.noConflict();
     
   // Use jQuery via jQuery(...)
jQuery(document).ready(function(){


function show_spinner()
{
	  jQuery("#content #loading").html('<div id="spinner"></div>');
	  jQuery('#spinner').fadeIn('fast', function() {
        
      });
}

function hide_spinner()
{
	
	  jQuery('#spinner').fadeOut('fast', function() {
        
      });
}


jQuery('#searchextra').submit(function() {
  return false;
});


jQuery('a#clearextra').click(function() {
  
  jQuery('ul#add').fadeOut('slow', function() {
        jQuery("ul#add").empty();
    });
  
});


jQuery('.allselector').click(function() {
	var id = jQuery(this).attr("id");
	//jQuery("option#selector"+id).attr("selected","selected");
	jQuery("option#selector"+id).attr('selected', false);

});


jQuery("#searchextra").click(function(){
	
	var keywords =  jQuery(".keywords").val();
	if(keywords.length==0){
		alert("Write some words");
	}
	else{

		var request = jQuery.ajax({
		  url: baseurl+"index.php?option=com_kaltura&controller=exporttool&task=livesearch&format=raw",
		  type: "POST",
		  data: {keywords : keywords},
		  dataType: 'json',
		  beforeSend: function(){
     			show_spinner();
   		  }
		});
		
		request.done(function(data) {
		  hide_spinner();
		  jQuery('ul#add').fadeIn('slow');
		  jQuery("ul#add").empty();
		  if(data==''){
		  	jQuery("ul#add").append("<li>No results</li>");
		  }
		  jQuery.each(data, function(){
		  	var exists = jQuery('input#'+this.id).length; 
			  	if(exists==0){
						jQuery("ul#add").append('<li id="'+this.id+'"><div class="tit_en">'+this.kentry_name+'</div><div class="act_en"><a href="javascript:void(0);" id="'+this.id+'" title="'+this.kentry_name+'" class="include_en">Include</a><a href="javascript:void(0);" id="'+this.id+'" title="'+this.kentry_name+'" class="notinclude_en">Exclude</a></div></li>');
				}		
		  });
		 
		 
		 
		 jQuery('a.include_en').click(function() {
  
			  var id = jQuery(this).attr("id");
			  var title = jQuery(this).attr("title");
			 
			  jQuery('li#'+id).fadeOut('fast', function() {
			  	jQuery("ul#added").append('<li id="'+id+'"><a href="javascript:void(0);" class="delete_en" id="'+id+'">'+title+'<input type="hidden" name="added[]" value="'+id+'" id="'+id+'"></a></li>');
			  	
			  		jQuery('.delete_en').click(function() {
			  			var id_option = jQuery(this).attr("id");
			  			jQuery(this).fadeOut('slow', function() {
        					jQuery(this).remove();
        					jQuery('li#'+id).fadeOut('slow');
    					});
    					
			  		});
			  	
			  });
			  
			});
			
			
		 jQuery('a.notinclude_en').click(function() {
  			 var id = jQuery(this).attr("id");
			 var title = jQuery(this).attr("title");
			 
  			 jQuery('li#'+id).fadeOut('slow', function() {
		     	jQuery("ul#deleted").append('<li id="'+id+'"><a href="javascript:void(0);" class="delete_en" id="'+id+'">'+title+'<input type="hidden" name="deleted[]" value="'+id+'" id="'+id+'"></a></li>');
		     	
		     	jQuery('.delete_en').click(function() {
			  			var id_option = jQuery(this).attr("id");
			  			jQuery(this).fadeOut('slow', function() {
        					jQuery(this).remove();
        					jQuery('li#'+id).fadeOut('slow');
    					});
    					
			  		});
		     	
		     	
		     });
  			 
			  
			  
			  
			});
		 
		 
		 
		});
		
		request.fail(function(jqXHR, textStatus) {
		  hide_spinner();
		  alert( "Request failed: " + textStatus );
		  
		});
	}
	return false;
	
});






});