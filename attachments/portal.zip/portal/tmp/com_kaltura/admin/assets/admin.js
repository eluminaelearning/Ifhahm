/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
window.addEvent('domready', function() {



    if ($('syncstatus')) {
        var slider = new Fx.Slide('warningarea');
        if ($('syncstatus').getProperty('value')) {
            slider.hide();
        } else slider.show();
    }

    if ($('editlistform')) {
        var listslide = new Fx.Slide('editlistform');
        listslide.hide();
    }
    
    if ($('submitsearch')) {
        $('submitsearch').addEvent('click', function() {
            document.adminForm.submit();
        });
    }
    
    if ($('submitclean')) {
        $('submitclean').addEvent('click', function() {
            $$('.filterselector').setProperty('value', '');
            $$('.filtertext').setProperty('value', '');
            $('freesearch').setProperty('value', '');
            document.adminForm.submit();
        });
    }
    
    if ($('publisherselector')) {
        $('publisherselector').addEvent('change', function() {
            $('iid').setProperty('value', this.getProperty('value'));
            document.adminForm.submit();
        })
    }

    $$('.editbutton').addEvent('click', function(event) {
        var id = this.getProperty('id');
        var field_id = 'field_' + id.substr(11);
        if ($(field_id).getProperty('class') == 'visiblefield') {
            $(field_id).removeClass('visiblefield');
            $(field_id).addClass('field');
        } else {
            $(field_id).removeClass('field');
            $$('.visiblefield').addClass('field');
            $$('.visiblefield').removeClass('visiblefield');
            $(field_id).addClass('visiblefield');
        }
    });
    
    $$('.close_button').addEvent('click', function() {
    	var id = this.getProperty('id');
        var field_id = 'field_' + id.substr(11);
        	$(field_id).removeClass('visiblefield');
            $(field_id).addClass('field');
        
    });
    
    
    $$('.send').addEvent('click', function() {
        var id = this.getProperty('id');
        var field_id = 'field_' + id.substr(5);
        var value = $('input_'+id.substr(5)).getProperty('value');
        
        var url = 'index.php?option=com_kaltura&controller=contenteditor&task=update&tmpl=component';
        new Request({
            url: url,
            method: 'post',
            data: {
                'iid': $('iid').getProperty('value'),
                'value': value,
                'entryid': id.substr(5, 10),
                'fieldid': id.substr(16)
            },
            onSuccess: function(data) {
                $('label_'+id.substr(5)).innerHTML = data;
                
            }
        }).send();
        
        $(field_id).removeClass('visiblefield');
        $(field_id).addClass('field');
    });
    
    $$('.togglevisible').addEvent('click', function() {
        var id = this.getProperty('id').substr(8);
        var hid = this.getProperty('id');
        var iid = $('iid').getProperty('value');
        
        var url = 'index.php?option=com_kaltura&controller=contenteditor&task=toggleVisible&format=raw';
        new Request({
            url: url,
            method: 'post',
            data: {
                'entryid': id,
                'iid': iid
            },
            onSuccess: function(data) {
                $(hid).innerHTML = data;
            }
        }).send();
    });
    
    $$('.togglesoldstatus').addEvent('click', function() {
        var id = this.getProperty('id').substr(12);
        var hid = this.getProperty('id');
        
        var url = 'index.php?option=com_kaltura&controller=contenteditor&task=toggleSoldStatus&format=raw';
        new Request({
            url: url,
            method: 'post',
            data: {
                'entryid': id,
                'iid': $('iid').getProperty('value')
            },
            onSuccess: function(data) {
                $(hid).innerHTML = data;
            }
        }).send();
    });
    
    if ($('add-button')) {
        $('add-button').addEvent('click', function() {
            var val = $('list_item').getProperty('value');
            addValue(val);
        });
        
        $('delete-button').addEvent('click', function() {
            var selectedid = $('selecteditemid').getProperty('value');
            removeValue(selectedid);
        });
        
        $('field_type').addEvent('change', function() {
            var val = this.getProperty('value');
            if (val == 1) listslide.slideIn();
            else listslide.slideOut();
        });
        
        $('savebutton').addEvent('click', function() {
        	$$('.rowtable').removeClass('selectedRow');
            var id = $('selectedval').getProperty('value');
            var fname = $('field_name').getProperty('value');
            var fkey = $('field_key').getProperty('value');
            var ftype = $('field_type').getProperty('value');
            var fvisible = $('field_visible').getProperty('checked');
            var ffiltrable = $('field_filtrable').getProperty('checked');
            var fafiltrable = $('field_adm_filtrable').getProperty('checked');
            
            var url = 'index.php?option=com_kaltura&controller=fieldsmanager&task=saveitem&tmpl=component';
            new Request({
                url: url,
                method: 'post',
                data: {
                    'id': id,
                    'fname': fname,
                    'fkey': fkey,
                    'ftype': ftype,
                    'fvisible': fvisible,
                    'ffiltrable': ffiltrable,
                    'fafiltrable': fafiltrable
                },
                onSuccess: function(data) {
                    $('debug').innerHTML = data;
                    $('field_list').innerHTML = '';
                    $('selectedval').setProperty('value', 0);
                    $('field_name').setProperty('value', '');
                    $('field_key').setProperty('value', '');
                    $('field_type').setProperty('value', 0);
                    window.location.reload(true);
                }
            }).send();
            
        });
        
        $('cancelbutton').addEvent('click', function() {
            $('field_list').innerHTML = '';
            $$('.rowtable').removeClass('selectedRow');
            $('selectedval').setProperty('value', 0);
            $('field_name').setProperty('value', '');
            $('field_key').setProperty('value', '');
            $('field_type').setProperty('value', 0);
        });
        
        $('newbutton').addEvent('click', function() {
            $('field_list').innerHTML = '';
            $$('.rowtable').removeClass('selectedRow');
            $('selectedval').setProperty('value', 0);
            $('field_name').setProperty('value', '');
            $('field_key').setProperty('value', '');
            $('field_type').setProperty('value', 0);
        });
        
        $('deletebutton').addEvent('click', function() {
            var id = $('selectedval').getProperty('value');
            var url = 'index.php?option=com_kaltura&controller=fieldsmanager&task=removefield';
            
            new Request({
                url: url,
                method: 'post',
                data: {
                    'id': id
                },
                onSuccess: function() {
                    window.location.reload(true);
                }
            }).send();
        });
        
        $$('.selectablefield').addEvent('click', function() {
            $$('.rowtable').removeClass('selectedRow');
           
            
            var id = this.getProperty('id').substr(6);
            $('row'+id).addClass('selectedRow');
             
             
            var url = 'index.php?option=com_kaltura&controller=fieldsmanager&task=getitem&format=raw';
            
            new Request.JSON({
                url: url,
                method: 'post',
                data: {
                    'id': id
                },
                onSuccess: function(field) {
                    var label = field.field_label;
                    var key = field.field_name;
                    var id = field.id;
                    var type = field.field_type;
                    var visible = field.field_visible;
                    var filtrable = field.field_filtrable;
                    var admfiltrable = field.field_adm_filtrable;
                    
                    $('field_name').setProperty('value', label);
                    $('field_key').setProperty('value', key);
                    $('selectedval').setProperty('value', id);
                    $('field_type').setProperty('value', type);
                    if (visible == 1) 
                        $('field_visible').setProperty('checked', 'checked');
                    else $('field_visible').setProperty('checked', '');
                    if (visible == 1) 
                        $('field_filtrable').setProperty('checked', 'checked');
                    else $('field_filtrable').setProperty('checked', '');
                    if (visible == 1) 
                        $('field_adm_filtrable').setProperty('checked', 'checked');
                    else $('field_adm_filtrable').setProperty('checked', '');
                    
                    if (type == 1) { // 1 is list type
                        var url = 'index.php?option=com_kaltura&controller=fieldsmanager&task=getFieldValues&tmpl=component';
                        var id = $('selectedval').getProperty('value');
                        
                        new Request({
                            url: url,
                            method: 'post',
                            data: {
                                'id': id
                            },
                            onSuccess: function(data) {
                                loadFieldList(data);
                                listslide.slideIn();
                            }
                        }).send();
                    } else {
                        listslide.slideOut();
                        $('field_list').innerHTML = '';
                    }
                }
            }).send();
        });
        
        function loadFieldList(data) {
            var a = $('field_list');
            a.innerHTML = data;
            changeSelId($('eventid').getProperty('value'));
            $$('.selectable').addEvent('click', selectItemHandler);
            var url = 'index.php?option=com_kaltura&controller=fieldsmanager&task=changeOrder&tmpl=component';
            
            // loading go-up and go-down events
            $$('.go_up').addEvent('click', function() {
                var id = this.getProperty('id').substr(3);
                var field_id = $('selectedval').getProperty('value');
                
                new Request({
                    url: url,
                    method: 'post',
                    data: {
                        'id': id,
                        'field_id': field_id,
                        'go_up': 0
                    },
                    onSuccess: function(data) {
                        loadFieldList(data)
                    }
                }).send();
            });
            
            $$('.go_down').addEvent('click', function() {
                var id = this.getProperty('id').substr(5);
                var field_id = $('selectedval').getProperty('value');
                
                new Request({
                    url: url,
                    method: 'post',
                    data: {
                        'id': id,
                        'field_id': field_id,
                        'go_up': 1
                    },
                    onSuccess: function(data) {
                        loadFieldList(data)
                    }
                }).send();
            });
        }
        
        function addValue(value) {
            var id = $('selectedval').getProperty('value');
            var url = 'index.php?option=com_kaltura&controller=fieldsmanager&task=additem&tmpl=component';
            new Request({
                url: url,
                method: 'post',
                data: {
                    'id': id,
                    'value': value
                },
                onSuccess: function(data) {
                    loadFieldList(data);
                }
            }).send();
        }
        
        function selectItemHandler() {
            $$('.selectable').removeClass('selected');
            this.addClass('selected');
            var id = this.getProperty('id').substr(5);
            $('selecteditemid').setProperty('value', id);
        }
        
        function removeValue(value) {
            var id = $('selectedval').getProperty('value');
            var url = 'index.php?option=com_kaltura&controller=fieldsmanager&task=removeitem&tmpl=component';
            new Request({
                url: url,
                method: 'post',
                data: {
                    'id': id,
                    'value': value
                },
                onSuccess: function(data) {
                    loadFieldList(data);
                }
            }).send();
        }
        
        function changeSelId(id) {
            $('selectedval').setProperty('value', id);
        }
    }
});
