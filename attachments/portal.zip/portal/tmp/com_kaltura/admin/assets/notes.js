/**
 *   Kaltura Browser - components/com_kaltura/assets/notes.js
 *   Author: Juan Dapena Paz (jdapena.paz@gmail.com)
 *   Copyright (C) 2012 Juan Dapena Paz
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
window.addEvent('domready', function() {
    initChecks();
    
    function initChecks() {
        var idlist = $('idlist').getProperty('value');
        var idarray = idlist.split(",");
        
        for (i=0; i < idarray.length; i++) {
            if ($("c" + idarray[i])) {
                $("c" + idarray[i]).setProperty('checked', 'checked');
            }
        }
    }

    $$('.checkbox').addEvent('change', function() {
        var id = this.getProperty('id').substr(1);
        var idlist = $('idlist').getProperty('value');
        
        if (this.getProperty('value') == "on") {
            if (idlist == "") {
                idlist += id;
            } else idlist += "," + id;
        } else {
            var idarray = idlist.split(",");
            idlist = "";
            for (i=0; i < idarray.length; i++) {
                el = idarray[i];
                if (el != id) {
                    if (idlist == "") idlist += el;
                    else idlist += "," + el;
                }
            }
        }
        $('idlist').setProperty('value', idlist);
    });
    
    $('fixsubmit').addEvent('click', function() {
        $('adminForm').submit();
    });
});
