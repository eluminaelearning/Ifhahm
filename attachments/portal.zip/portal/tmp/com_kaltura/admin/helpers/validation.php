<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');

class ValidationHelper {
    public static function isValid() 
    {
       
       $params = &JComponentHelper::getParams( 'com_kaltura' );
       $licensevalid = $params->get( 'licensevalid');
       $datevalid = $params->get( 'validdate','' );
	   $date =& JFactory::getDate($datevalid);
	   $df_form = strtotime($date);
	   
	   $date =& JFactory::getDate();
	   $datenow = $date->toFormat();
	   $datenow_form = strtotime($datenow);
	   
	   if($licensevalid!=1):
	   	return false;  
	   
	   else:
	   
		   if($datenow_form > $df_form):
		   	return false;
		   
		   else:
		   	return true;
		   	
		   endif;
	   
	   endif;

    }
	
	public static function singlePartner()
	{
		$database = & JFactory::getDBO();
		$query = "SELECT count(*) FROM `#__Kaltura_instances`";
		$database->setQuery( $query );
		$instances = $database->loadResult();

		
		if(!self::isValid()):
		
			if($instances>=1):
				return false;
			else:		
				return true;
			
			endif;
			
		else:
			return true;
		endif;
	}
	
	public static function fieldManager()
	{
		$database = & JFactory::getDBO();
		$query = "SELECT count(*) FROM `#__Kaltura_fields`";
		$database->setQuery( $query );
		$instances = $database->loadResult();

		
		if(!self::isValid()):
		
			if($instances>=2):
				return false;
			else:		
				return true;
			
			endif;
			
		else:
			return true;
		endif;
			
			
		
	}
    
}
?>
