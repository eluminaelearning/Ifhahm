<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controller');

class KalturaController extends JController {
	function __construct() {
		if(JRequest::getCmd('view') == '') {
			JRequest::setVar('view', 'default');
		}
		$this->item_type = 'Default';
		parent::__construct();
	}

	function instances() {
		/*JRequest::setVar('view', 'instances');
		parent::display();*/
		$model =& $this->getModel('instances');
		
		$view =& $this->getView('instances', 'html');
		$view->setModel($model, true);
		
		$view->display();
	}

    function contentselector() {
        $model =& $this->getModel('instances');
        
        $view =& $this->getView('contentselector', 'html');
        $view->setModel($model, true);
        
        $view->display();
    }
    
    function contenteditor() {
        JRequest::setVar('view', 'contenteditor');
        parent::display();
    }
    
    function fieldsmanager() {
        $model =& $this->getModel('fields');
        
        $view =& $this->getView('fieldsmanager', 'html');
        $view->setModel($model, true);
        
        $view->display();
    }
    
    function configuration() {
        $model =& $this->getModel('configuration');
        
        $view =& $this->getView('configuration', 'html');
        $view->setModel($model, true);
        
        $view->display();
    }
    
    function exporttool()
    {
    	if(!ValidationHelper::isValid())
			$this->setRedirect('index.php?option=com_kaltura&task=validate', JText::_( 'CANNOTEXPORT' ), 'error');
			
			
    	$model =& $this->getModel('exporttool');
        $view =& $this->getView('exporttool', 'html');
        $view->setModel($model, true);
        
        $view->display();
    }
    
    function save() {
        $model =& $this->getModel('configuration');
        
        $configuration = new stdClass();
        $configuration->remote_sync = (JRequest::getVar('sync_field')?1:0);
        $configuration->details_freehtml = 
            JRequest::getVar('details_freehtml', '', 'post', 'string',
                             JREQUEST_ALLOWHTML);
        
        $model->setConfiguration($configuration); // <- this thing is a bullshit
        
        $view =& $this->getView('configuration', 'html');
        $view->setModel($model, true);
        
        $view->display();
    }
    
    function notes() {
    
    	if(!ValidationHelper::isValid())
			$this->setRedirect('index.php?option=com_kaltura&task=validate', JText::_( 'CANNOTNOTES' ), 'error');
    
        $model =& $this->getModel('notes');
        $view =& $this->getView('notes', 'html');
        $view->setModel($model, true);
        $view->display();
    }
    function validate() {  	
    	ValidationHelper::singlePartner();
    	
    	
        $view =& $this->getView('validate', 'html');
        $view->display();
    }
}
?>
