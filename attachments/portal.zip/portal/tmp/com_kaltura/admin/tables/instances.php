<?php
/**
 *   kajoo
 *   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
 *   Copyright (C) 2012
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');

class TableInstances extends JTable
{
	var $id = null;
	var $instance_name = null;
	var $desc = null;
	var $dbhost = null;
	var $dbuser = null;
	var $dbpasswd = null;
	var $userid = null;
	var $kalturaurl = null;
	var $secretkey = null;

	function __construct(&$db) {
		parent::__construct('#__Kaltura_instances', 'id', $db);
	}

	function check() {
		// TODO: implement entity check system
		return true;
	}
}
?>
