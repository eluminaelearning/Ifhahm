-- -----------------------------------------------------
--   Kajoo
--   Authors: Juan Dapena Paz (juan@bittingbits.com), Miguel Puig (miguel@freebandtech.com)
--   Copyright (C) 2012
--
--   This program is free software: you can redistribute it and/or modify
--   it under the terms of the GNU General Public License as published by
--   the Free Software Foundation, either version 3 of the License, or
--   (at your option) any later version.
--
--   This program is distributed in the hope that it will be useful,
--   but WITHOUT ANY WARRANTY, without even the implied warranty of
--   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--   GNU General Public License for more details.
--
--   You should have received a copy of the GNU General Public License
--   along with this program.  If not, see <http://www.gnu.org/licenses/>.
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Table `mydb`.`instances`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `#__Kaltura_instances` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `instance_name` VARCHAR(255) NOT NULL,
  `desc` TEXT NOT NULL,
  `dbhost` VARCHAR(255) NOT NULL,
  `dbuser` VARCHAR(255) NOT NULL,
  `dbpasswd` VARCHAR(255) NOT NULL,
  `kalturaurl` VARCHAR(255) NOT NULL,
  `userid` INT NOT NULL,
  `secretkey` VARCHAR(255) NOT NULL,
  `public` TINYINT(1) NOT NULL DEFAULT TRUE,
  `priority` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`) )
ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `#__Kaltura_fields` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `profile_id` INT NOT NULL,
    `field_name` VARCHAR(255) NOT NULL,
    `field_label` VARCHAR(255) NOT NULL,
    `field_type` INT NOT NULL,
    `field_xpath` VARCHAR(255) NOT NULL,
    `field_temp` TINYINT(1) NOT NULL DEFAULT 1,
    `field_visible` TINYINT(1) NOT NULL DEFAULT 1,
    `field_adm_filtrable` TINYINT(1) NOT NULL DEFAULT 1,
    `field_filtrable` TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `#__Kaltura_fields_values` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `field_id` INT NOT NULL,
    `field_value` VARCHAR(255) NOT NULL,
    `field_order` INT NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `#__Kaltura_entry_field_value` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `kentry_id` VARCHAR(255) NOT NULL,
    `field_id` INT NOT NULL,
    `value` TEXT,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `#__Kaltura_entry_cdata` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `priority` INT NOT NULL DEFAULT 0,
    `kentry_id` VARCHAR(255) NOT NULL,
    `kentry_visible` TINYINT(1) NOT NULL DEFAULT 1,
    `kentry_sold_status` SMALLINT(2) NOT NULL DEFAULT 0,
    `kentry_name` VARCHAR(60),
    `kentry_type` SMALLINT(6),
    `kentry_media_type` SMALLINT(6),
    `kentry_data` VARCHAR(48),
    `kentry_thumbnail` VARCHAR(48),
    `kentry_views` INT(11),
    `kentry_votes` INT(11),
    `kentry_status` INT(11),
    `kentry_source` VARCHAR(1048),
    `kentry_length_in_msecs` INT(11),
    `kentry_created_at` DATETIME,
    `kentry_updated_at` DATETIME,
    `kentry_partner_id` INT(11),
    `kentry_site_url` VARCHAR(256),
    `kentry_plays` INT(11),
    `kentry_description` TEXT,
    `kentry_media_date` DATETIME,
    `kentry_moderation_status` INT(11),
    `kentry_moderation_count` INT(11),
    `kentry_modified_at` DATETIME,
    `kentry_categories` VARCHAR(4096),
    `kentry_categories_ids` VARCHAR(1024),
    `kentry_start_date` DATETIME,
    `kentry_end_date` DATETIME,
    `kentry_available_from` DATETIME,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `#__Kaltura_playlist` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `kentry_id` VARCHAR(255) NOT NULL,
    `playlist_name` VARCHAR(255) NOT NULL,
    `playlist_plays` INT(11),
    `playlist_description` TEXT,
    `playlist_available_from` DATETIME,
    `playlist_publish` TINYINT(1),
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `#__Kaltura_playlist_entry` (
    `playlist_id` INT NOT NULL,
    `entry_id` INT NOT NULL,
    PRIMARY KEY (`playlist_id`, `entry_id`),
    INDEX `fk_kaltura_playlist_entry_playlist` (`playlist_id`),
    INDEX `fk_kaltura_playlist_entry_entry` (`entry_id`),
    CONSTRAINT `fk_kaltura_playlist_entry_playlist`
        FOREIGN KEY (`playlist_id`)
        REFERENCES `#__Kaltura_playlist` (`id`)
        ON DELETE CASCADE
        ON UPDATE NO ACTION,
    CONSTRAINT `fk_kaltura_playlist_entry_entry`
        FOREIGN KEY (`entry_id`)
        REFERENCES `#__Kaltura_entry_cdata` (`id`)
        ON DELETE CASCADE
        ON UPDATE NO ACTION
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `#__Kaltura_notes` (
    `note_id` INT NOT NULL AUTO_INCREMENT,
    `note_title` VARCHAR(255) NOT NULL,
    `note_content` TEXT NOT NULL,
    `note_contact` VARCHAR(255) NOT NULL,
    `note_email` VARCHAR(255) NOT NULL,
    `note_phone` VARCHAR(255) NOT NULL,
    `note_time` DATETIME NOT NULL,
    `note_meeting_place` VARCHAR(255) NOT NULL,
    `note_genre` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`note_id`)
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS `#__Kaltura_notes_entries` (
    `note_id` INT NOT NULL,
    `entry_id` INT NOT NULL,
    PRIMARY KEY (`note_id`)
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS `#__Kaltura_configuration` (
    `remote_sync` TINYINT(1) NOT NULL DEFAULT 0,
    `details_freehtml` TEXT NOT NULL
) ENGINE=InnoDB;

DELETE FROM `#__Kaltura_configuration`;
INSERT INTO `#__Kaltura_configuration` (`remote_sync`, `details_freehtml`)
VALUES (0, '');
