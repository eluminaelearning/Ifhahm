<?php
// ensure this file is being included by a parent file
if ( ! ( defined( '_VALID_CB' ) || defined( '_JEXEC' ) || defined( '_VALID_MOS' ) ) ) { die( 'Direct Access to this location is not allowed.' ); }

include_once( JPATH_ROOT . DS . 'plugins' . DS . 'user' . DS . 'joomdlehooks'.DS. 'joomdlehooks.php' );

// Register CB callbacks - Frontend
$_PLUGINS->registerFunction( 'onAfterUserRegistration', 'newUser','joomdlehookscb' );
$_PLUGINS->registerFunction( 'onAfterUserUpdate', 'updateUser','joomdlehookscb' );
$_PLUGINS->registerFunction( 'onAfterUserAvatarUpdate', 'updateUser','joomdlehookscb' );

// Register CB callbacks - Backend
$_PLUGINS->registerFunction( 'onAfterUpdateUser', 'updateUser','joomdlehookscb' );
$_PLUGINS->registerFunction( 'onAfterNewUser', 'newUser','joomdlehookscb' );
$_PLUGINS->registerFunction( 'onAfterDeleteUser', 'deleteUser','joomdlehookscb' );

// Include our language file (if exists!)
$defaultLanguage = 'english';
//$languagePrefix = $GLOBALS['mosConfig_absolute_path'] . '/components/com_comprofiler/plugin/user/plug_cbvmsync/';
$defaultLanguageFile = 'lang/'.$defaultLanguage.'.php';
include( $defaultLanguageFile );




class joomdlehookscb extends cbPluginHandler{
	
        /**
        * Constructor
        */      
        function joomdlehookscb() {
        }

        /**
        * Syncs the CB fields to Moodle
        * @param object row
        * @param object rowExtras
        * @returns mixed : 
        */
        function updateUser($row, $rowExtras) {
        	global $_CB_database , $_REQUEST;
        	
		$a = (array) $row;
		plgUserJoomdlehooks::onUserAfterSave ($a, 0, true, '');
        }

        function newUser($row, $rowExtras) {
        	global $_CB_database , $_REQUEST;
        	
		$user = (array) $row;
		plgUserJoomdlehooks::onUserAfterSave ($user, 1, true, '');
        }
        
        function deleteUser($row, $rowExtras) {
        	global $_CB_database , $_REQUEST;
        	
		$user = (array) $row;
		plgUserJoomdlehooks::onUserAfterDelete ($user, 1);
        }
        
}

// Install function
function plug_joomdlehookscb_install() {
        return _JOOMDLECB_INSTALL;  
}

// Uninstall function
function plug_joomdlehooks_uninstall() {
        return _JOOMDLECB_UNINSTALL;        
}

?>
