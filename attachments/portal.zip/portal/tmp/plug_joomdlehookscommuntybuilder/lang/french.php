<?php

DEFINE( '_JOOMDLECB_INSTALL' , 'Joomdlehooks CB plugin installé avec succes.' );
DEFINE( '_JOOMDLECB_UNINSTALL' , 'Joomdlehooks CB plugin desinstallé avec succes.' );

DEFINE( '_JOOMDLECB_ADMIN_OPTIONS' , 'Admin Options' );

?>
