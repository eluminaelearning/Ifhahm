<?php

DEFINE( '_JOOMDLECB_INSTALL' , 'Joomdlehooks CB plugin successfully installed.' );
DEFINE( '_JOOMDLECB_UNINSTALL' , 'Joomdlehooks CB plugin successfully uninstalled.' );

DEFINE( '_JOOMDLECB_ADMIN_OPTIONS' , 'Admin Options' );

?>
