﻿<?php

DEFINE( '_JOOMDLECB_INSTALL' , 'Joomdlehooks CB Plugin erfolgreich installiert.' );
DEFINE( '_JOOMDLECB_UNINSTALL' , 'Joomdlehooks CB Plugin erfolgreich installiert.' );

DEFINE( '_JOOMDLECB_ADMIN_OPTIONS' , 'Admin-Optionen' );

?>
