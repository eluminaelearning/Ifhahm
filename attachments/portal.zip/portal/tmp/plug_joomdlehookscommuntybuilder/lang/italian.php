<?php

DEFINE( '_JOOMDLECB_INSTALL' , 'Plugin Joomdlehooks CB installato correttamente.' );
DEFINE( '_JOOMDLECB_UNINSTALL' , 'Plugin Joomdlehooks CB rimosso correttamente.' );

DEFINE( '_JOOMDLECB_ADMIN_OPTIONS' , 'Opzioni di amministrazione' );

?>
