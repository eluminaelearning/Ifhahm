<?php

DEFINE( '_JOOMDLECB_INSTALL' , 'Joomdlehooks CB plugin instalado correctamente.' );
DEFINE( '_JOOMDLECB_UNINSTALL' , 'Joomdlehooks CB plugin desinstalado correctamente.' );

DEFINE( '_JOOMDLECB_ADMIN_OPTIONS' , 'Opciones Admin' );

?>

