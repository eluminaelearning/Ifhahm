<?php
$string['pluginname'] = 'Course overview';
