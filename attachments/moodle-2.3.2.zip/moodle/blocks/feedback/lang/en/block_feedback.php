<?php

$string['pluginname'] = 'Feedback';
$string['feedback'] = 'Feedback';
$string['missing_feedback_module'] = 'This blocks relies on the Feedback activity module, but that module is not present!';
