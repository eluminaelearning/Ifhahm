<?php

$string['completionprogressdetails'] = 'Completion progress details';
$string['criteriagroup'] = 'Criteria group';
$string['firstofsecond'] = '{$a->first} of {$a->second}';
$string['pluginname'] = 'Course completion status';
$string['requirement'] = 'Requirement';
$string['returntocourse'] = 'Return to course';
