<?php
//
// Optional course format configuration file
//
// This file contains any specific configuration settings for the
// social format.
//
// The default blocks layout for this course format:
    $format['defaultblocks'] = ':news_items,recent_activity,calendar_upcoming';


